#!/usr/bin/env python3
"""DARKSSH - automatic, adaptive Ubuntu + SSHX workspace server.

The host is treated as untrusted infrastructure. DARKSSH detects the host
platform, package manager and namespace capabilities at runtime, repairs or
creates its Ubuntu base, installs a workspace-local SSHX client, and chooses
an isolation mode that the host can actually support.

Important: no Linux application can guarantee kernel-level isolation inside
an arbitrary VPS/container. If the host blocks user/network namespaces or
ptrace, DARKSSH falls back to PRoot filesystem isolation and reports the
reduced capability in /api/health instead of pretending it has stronger
isolation.
"""
import concurrent.futures
import json
import os
import platform
import re
import secrets
import shutil
import signal
import stat
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP = Path(__file__).resolve().parent
DATA = APP / "data"
SESSIONS = DATA / "sessions"
IMAGES = DATA / "images"
CFG = APP / "config.json"
STATEFILE = DATA / "state.json"
BASE = DATA / "ubuntu-base"
BASE_NEW = DATA / "ubuntu-base.new"
LOCAL_BIN = APP / "bin"
PROOT_LOCAL = LOCAL_BIN / "proot"
SLIRP_LOCAL = LOCAL_BIN / "slirp4netns"

for p in (SESSIONS, IMAGES, LOCAL_BIN, DATA):
    p.mkdir(parents=True, exist_ok=True)

DEFAULT_CFG = {
    "host": "0.0.0.0",
    "port": 5000,
    "idle_minutes": 60,
    "max_sessions": 25,
    "api_key": "",
}

# ---------------------------------------------------------------------------
# Config loading — environment variables always override file values, so the
# same Docker image / unpacked zip can be reconfigured without editing files.
# ---------------------------------------------------------------------------
def _coerce_int(name, default, minimum=None, maximum=None):
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        v = int(raw)
    except ValueError:
        log(f"Invalid int for {name}={raw!r}; using default {default}")
        return default
    if minimum is not None and v < minimum:
        return minimum
    if maximum is not None and v > maximum:
        return maximum
    return v


def load_config():
    cfg = dict(DEFAULT_CFG)
    try:
        loaded = json.loads(CFG.read_text())
        if isinstance(loaded, dict):
            cfg.update(loaded)
    except FileNotFoundError:
        pass
    except Exception as e:
        log(f"config.json unreadable ({e}); using defaults")
    # Environment overrides — always win, never persisted unless we choose to.
    if os.environ.get("DARKSSH_HOST"):
        cfg["host"] = os.environ["DARKSSH_HOST"]
    cfg["port"] = _coerce_int("DARKSSH_PORT", cfg.get("port", 5000), 1, 65535)
    cfg["idle_minutes"] = _coerce_int("DARKSSH_IDLE_MINUTES", cfg.get("idle_minutes", 60), 1, 24 * 60)
    cfg["max_sessions"] = _coerce_int("DARKSSH_MAX_SESSIONS", cfg.get("max_sessions", 25), 1, 1000)
    if not cfg.get("api_key"):
        cfg["api_key"] = secrets.token_urlsafe(32)
        try:
            CFG.write_text(json.dumps(cfg, indent=2))
        except Exception as e:
            log(f"Could not persist generated API key: {e}")
    return cfg


CFGDATA = load_config()

STATE = {"sessions": {}}
try:
    loaded = json.loads(STATEFILE.read_text())
    if isinstance(loaded, dict) and isinstance(loaded.get("sessions"), dict):
        STATE.update(loaded)
except Exception:
    pass

PROCS = {}
NETPROCS = {}
LOCK = threading.RLock()
CREATE_POOL = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="darkssh-create")
READY_EVENTS = {}
URLRE = re.compile(r"https://sshx\.io/s/[^\s\r\n]+")
SHUTDOWN = threading.Event()


def log(msg):
    print("[DARKSSH] " + str(msg), flush=True)


def save():
    tmp = STATEFILE.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(STATE, indent=2))
        os.replace(tmp, STATEFILE)
    except Exception as e:
        log(f"save() failed: {e}")


def have(name):
    return shutil.which(name) is not None


def run(cmd, *, timeout=120, check=False, env=None, capture=False, cwd=None):
    return subprocess.run(
        cmd,
        timeout=timeout,
        check=check,
        env=env,
        cwd=cwd,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
        text=True if capture else False,
    )


def root_runner():
    """Return the prefix list used to elevate to root, or [] if already root.

    Returns None if elevation is required but unavailable — callers should
    treat this as 'skip the install' rather than spam sudo password prompts.
    """
    if os.geteuid() == 0:
        return []
    for x in ("sudo", "doas", "su"):
        if have(x):
            return [x]
    return None


# ---------------------------------------------------------------------------
# Host detection
# ---------------------------------------------------------------------------
def detect_host():
    info = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                info[k] = v.strip().strip('"')
    except Exception:
        pass
    return {
        "os": info.get("PRETTY_NAME") or info.get("NAME") or platform.system(),
        "id": info.get("ID", "unknown"),
        "version": info.get("VERSION_ID", ""),
        "arch": platform.machine().lower(),
        "python": platform.python_version(),
        "kernel": platform.release(),
        "container": detect_container(),
        "root": os.geteuid() == 0,
        "sudo": have("sudo") or have("doas"),
    }


def detect_container():
    try:
        text = Path("/proc/1/cgroup").read_text(errors="ignore").lower()
        if any(x in text for x in ("docker", "kubepods", "containerd", "podman", "lxc")):
            return True
        if Path("/.dockerenv").exists() or Path("/run/.containerenv").exists():
            return True
    except Exception:
        pass
    return False


def package_manager():
    for name in ("apt-get", "apk", "dnf", "yum", "pacman", "zypper", "pkg", "xbps-install", "swupd", "eopkg"):
        if have(name):
            return name
    return None


def install_host_packages(extra=None):
    """Best-effort host bootstrap. Returns the list of tools actually available
    after the attempt, so callers can decide what to fall back to."""
    pm = package_manager()
    available = {}
    for tool in ("python3", "curl", "wget", "tar", "gzip", "proot", "slirp4netns", "unshare", "ca-certificates"):
        available[tool] = have(tool)
    if not pm:
        log("No recognised package manager; using whatever is already on the host")
        return available
    prefix = root_runner()
    if prefix is None and os.geteuid() != 0:
        log("No root/sudo/doas available; cannot install host packages automatically")
        return available

    update_cmds = {
        "apt-get": ["apt-get", "update", "-qq"],
        "apk": ["apk", "update"],
        "dnf": ["dnf", "makecache", "-q"],
        "yum": ["yum", "makecache", "-q"],
        "pacman": ["pacman", "-Sy", "--noconfirm"],
        "zypper": ["zypper", "--non-interactive", "refresh"],
        "pkg": ["pkg", "update", "-f"],
        "xbps-install": ["xbps-install", "-S"],
        "swupd": ["swupd", "update"],
        "eopkg": ["eopkg", "update-repo"],
    }
    install_cmds = {
        "apt-get": lambda pkgs: ["apt-get", "install", "-y", "--no-install-recommends"] + pkgs,
        "apk": lambda pkgs: ["apk", "add", "--no-cache"] + pkgs,
        "dnf": lambda pkgs: ["dnf", "install", "-y"] + pkgs,
        "yum": lambda pkgs: ["yum", "install", "-y"] + pkgs,
        "pacman": lambda pkgs: ["pacman", "-S", "--noconfirm"] + pkgs,
        "zypper": lambda pkgs: ["zypper", "--non-interactive", "install", "--no-recommends"] + pkgs,
        "pkg": lambda pkgs: ["pkg", "install", "-y"] + pkgs,
        "xbps-install": lambda pkgs: ["xbps-install", "-y"] + pkgs,
        "swupd": lambda pkgs: ["swupd", "bundle-add"] + pkgs,
        "eopkg": lambda pkgs: ["eopkg", "install", "-y"] + pkgs,
    }
    package_sets = {
        "apt-get": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "apk": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "dnf": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "yum": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot"],
        "pacman": ["python", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "zypper": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot"],
        "pkg": ["python", "curl", "wget", "tar", "gzip", "proot"],
        "xbps-install": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot"],
        "swupd": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "proot"],
        "eopkg": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "proot"],
    }
    pkgs = list(package_sets.get(pm, []))
    if extra:
        pkgs += [p for p in extra if p not in pkgs]

    # update
    try:
        cp = run(prefix + update_cmds[pm], timeout=180, capture=True)
        if cp.returncode != 0:
            log(f"{pm} update failed (continuing): {(cp.stderr or '').strip()[:300]}")
    except Exception as e:
        log(f"{pm} update exception: {e}")
    # install
    try:
        cp = run(prefix + install_cmds[pm](pkgs), timeout=900, capture=True)
        if cp.returncode != 0:
            log(f"{pm} install partial failure: {(cp.stderr or '').strip()[:500]}")
    except subprocess.TimeoutExpired:
        log(f"{pm} install timed out")
    except Exception as e:
        log(f"{pm} install exception: {e}")
    # re-check
    for tool in list(available):
        available[tool] = have(tool)
    return available


# ---------------------------------------------------------------------------
# Architecture + Ubuntu URLs (with mirror fallback so URLs never rot)
# ---------------------------------------------------------------------------
def arch_name():
    m = platform.machine().lower()
    return {
        "x86_64": "amd64", "amd64": "amd64",
        "aarch64": "arm64", "arm64": "arm64",
        "armv7l": "armhf", "armv7": "armhf", "armv6l": "armhf",
        "ppc64le": "ppc64el", "ppc64el": "ppc64el",
        "s390x": "s390x",
        "riscv64": "riscv64",
    }.get(m)


# Mirrors we try in order. The version is filled in dynamically — we scrape
# the directory listing of each LTS series to find the latest point release,
# so URLs never rot when Ubuntu publishes a new point release.
UBUNTU_SERIES = ["24.04", "22.04"]
UBUNTU_MIRRORS = [
    "https://cdimage.ubuntu.com/ubuntu-base/releases/{v}/release/ubuntu-base-{v}-base-{a}.tar.gz",
    "https://mirror.hetzner.com/ubuntu/ubuntu-base/releases/{v}/release/ubuntu-base-{v}-base-{a}.tar.gz",
    "https://mirror.leaseweb.com/ubuntu-base/releases/{v}/release/ubuntu-base-{v}-base-{a}.tar.gz",
    "https://ftp.ubuntu.com/ubuntu-base/releases/{v}/release/ubuntu-base-{v}-base-{a}.tar.gz",
]
UBUNTU_INDEX_URLS = [
    "https://cdimage.ubuntu.com/ubuntu-base/releases/{series}/release/",
    "https://mirror.hetzner.com/ubuntu/ubuntu-base/releases/{series}/release/",
]


def _http_get_text(url, timeout=15):
    if have("curl"):
        cp = run(["curl", "-fsL", "--max-time", str(timeout), "-A", "DARKSSH/3", url], timeout=timeout + 5, capture=True)
        if cp.returncode == 0:
            return cp.stdout
    if have("wget"):
        cp = run(["wget", "-qO-", "--timeout=" + str(timeout), url], timeout=timeout + 5, capture=True)
        if cp.returncode == 0:
            return cp.stdout
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "DARKSSH/3"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="ignore")
    except Exception:
        return ""


def _discover_latest_point_release(series, arch):
    """Scrape the cdimage directory listing for the latest point release of
    the given LTS series. Returns the version string (e.g. "24.04.4") or None.
    Falls back to known-good versions if scraping fails."""
    pattern = re.compile(rf'href="ubuntu-base-({re.escape(series)}\.\d+)-base-{re.escape(arch)}\.tar\.gz"')
    for index_url in UBUNTU_INDEX_URLS:
        html = _http_get_text(index_url.format(series=series))
        if not html:
            continue
        matches = pattern.findall(html)
        if matches:
            # Pick the highest point release.
            matches.sort(key=lambda v: [int(x) for x in v.split(".")])
            return matches[-1]
    return None


# Hardcoded fallback versions — used only if directory scraping fails (e.g.
# no network, mirror offline). Updated 2026-09 to known-good values.
FALLBACK_VERSIONS = ["24.04.4", "24.04.3", "22.04.5", "22.04.4"]


def ubuntu_urls():
    """Return ordered list of URLs to try. Discovers the latest point release
    per LTS series dynamically, with hardcoded fallbacks."""
    a = arch_name()
    if not a:
        return []
    out = []
    seen = set()
    for series in UBUNTU_SERIES:
        v = _discover_latest_point_release(series, a)
        if v:
            versions = [v]
        else:
            log(f"Directory scrape failed for {series}; using hardcoded fallback list")
            versions = [x for x in FALLBACK_VERSIONS if x.startswith(series + ".")]
        for ver in versions:
            for m in UBUNTU_MIRRORS:
                url = m.format(v=ver, a=a)
                if url not in seen:
                    out.append(url)
                    seen.add(url)
    # Append all fallbacks as a last resort.
    for v in FALLBACK_VERSIONS:
        for m in UBUNTU_MIRRORS:
            url = m.format(v=v, a=a)
            if url not in seen:
                out.append(url)
                seen.add(url)
    return out


# ---------------------------------------------------------------------------
# Download with multiple tool fallbacks + size validation
# ---------------------------------------------------------------------------
def fetch(url, out, min_bytes=1, attempts=3, max_time=600):
    """Download with curl/wget/urllib fallback and atomic replacement.

    max_time is the per-attempt timeout in seconds. For small files (keyrings,
    static binaries) pass a much smaller value so we fail fast."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    part = out.with_name(out.name + ".part")
    last = None
    for attempt in range(1, attempts + 1):
        part.unlink(missing_ok=True)
        try:
            if have("curl"):
                cp = run(["curl", "-fL", "--retry", "2", "--connect-timeout", "15", "--max-time", str(max_time), "-A", "DARKSSH/3", "-o", str(part), url], timeout=max_time + 30, capture=True)
                if cp.returncode != 0:
                    raise RuntimeError((cp.stderr or "curl failed").strip()[:300])
            elif have("wget"):
                cp = run(["wget", "-q", "--timeout=20", "--tries=2", "-O", str(part), url], timeout=max_time + 30, capture=True)
                if cp.returncode != 0:
                    raise RuntimeError((cp.stderr or "wget failed").strip()[:300])
            else:
                req = urllib.request.Request(url, headers={"User-Agent": "DARKSSH/3"})
                with urllib.request.urlopen(req, timeout=min(60, max_time)) as r, open(part, "wb") as f:
                    while True:
                        b = r.read(1024 * 1024)
                        if not b:
                            break
                        f.write(b)
            if not part.exists() or part.stat().st_size < min_bytes:
                raise RuntimeError(f"download too small ({part.stat().st_size if part.exists() else 0} bytes)")
            os.replace(part, out)
            return
        except Exception as e:
            last = e
            log(f"download attempt {attempt}/{attempts} failed for {url}: {e}")
            time.sleep(min(attempt, 5))
    raise RuntimeError(f"download failed: {url}: {last}")


def fetch_first(urls, out, min_bytes=1):
    last = None
    for u in urls:
        try:
            fetch(u, out, min_bytes=min_bytes)
            return
        except Exception as e:
            last = e
    raise RuntimeError(f"all {len(urls)} download mirrors failed: {last}")


# ---------------------------------------------------------------------------
# Preflight checks
# ---------------------------------------------------------------------------
def preflight():
    """Return list of warnings. Stops mysterious failures on tiny VPS."""
    warns = []
    try:
        du = os.statvfs(DATA)
        free_mb = (du.f_bavail * du.f_frsize) // (1024 * 1024)
        if free_mb < 600:
            warns.append(f"low disk space: {free_mb} MB free in {DATA} (need ~600 MB for Ubuntu base)")
    except Exception:
        pass
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    mb = int(line.split()[1]) // 1024
                    if mb < 256:
                        warns.append(f"low memory: {mb} MB available (need ~256 MB)")
                    break
    except Exception:
        pass
    return warns


# ---------------------------------------------------------------------------
# Ubuntu base management
# ---------------------------------------------------------------------------
def migrate_base():
    """Use the user's existing ubuntu-base.new if it is complete."""
    if (BASE / "bin/sh").exists():
        return
    if (BASE_NEW / "bin/sh").exists():
        log("Found existing ubuntu-base.new; promoting it to ubuntu-base")
        shutil.rmtree(BASE, ignore_errors=True)
        os.replace(BASE_NEW, BASE)


def repair_sources(root):
    root = Path(root)
    files = [root / "etc/apt/sources.list"]
    sd = root / "etc/apt/sources.list.d"
    if sd.exists():
        files += list(sd.glob("*.list")) + list(sd.glob("*.sources"))
    replacements = {
        "http://archive.ubuntu.com/ubuntu": "https://archive.ubuntu.com/ubuntu",
        "http://security.ubuntu.com/ubuntu": "https://security.ubuntu.com/ubuntu",
        "http://ports.ubuntu.com/ubuntu-ports": "https://ports.ubuntu.com/ubuntu-ports",
        "http://security.ubuntu.com/ubuntu-ports": "https://ports.ubuntu.com/ubuntu-ports",
    }
    for f in files:
        if not f.exists():
            continue
        try:
            s = f.read_text()
            for a, b in replacements.items():
                s = s.replace(a, b)
            f.write_text(s)
        except Exception:
            pass


def seed_keyring(root):
    root = Path(root)
    candidates = [
        Path("/usr/share/keyrings/ubuntu-archive-keyring.gpg"),
        Path("/etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg"),
        root / "usr/share/keyrings/ubuntu-archive-keyring.gpg",
    ]
    dest = root / "usr/share/keyrings/ubuntu-archive-keyring.gpg"
    trusted = root / "etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg"
    dest.parent.mkdir(parents=True, exist_ok=True)
    trusted.parent.mkdir(parents=True, exist_ok=True)
    for src in candidates:
        try:
            if src.exists() and src.stat().st_size > 1000:
                shutil.copy2(src, dest)
                shutil.copy2(src, trusted)
                return
        except Exception:
            pass
    urls = [
        "https://archive.ubuntu.com/ubuntu/project/ubuntu-archive-keyring.gpg",
        "https://mirror.hetzner.com/ubuntu/ubuntu/project/ubuntu-archive-keyring.gpg",
        "https://ftp.ubuntu.com/ubuntu/project/ubuntu-archive-keyring.gpg",
    ]
    last = None
    for url in urls:
        try:
            # Keyring is ~10KB; 60s is plenty.
            fetch(url, dest, min_bytes=10000, attempts=2, max_time=60)
            shutil.copy2(dest, trusted)
            return
        except Exception as e:
            last = e
            log(f"keyring fetch failed from {url}: {e}")
    raise RuntimeError("Unable to obtain the official Ubuntu archive keyring from any mirror. Last error: " + str(last))


# ---------------------------------------------------------------------------
# PRoot — returns None when no usable binary exists (was a silent bug before)
# ---------------------------------------------------------------------------
def proot_binary():
    """Return path to a usable proot binary, or None."""
    p = shutil.which("proot")
    if p:
        return p
    if PROOT_LOCAL.exists() and os.access(PROOT_LOCAL, os.X_OK) and PROOT_LOCAL.stat().st_size > 50000:
        return str(PROOT_LOCAL)
    return None


def pcmd(root, command):
    """Safe PRoot command: never bind the host /proc or /sys. Only binds /dev
    nodes that actually exist on the host — avoids failures on minimal
    containers, Termux, and chrooted hosts."""
    root = str(root)
    pb = proot_binary()
    if not pb:
        raise RuntimeError("PRoot binary is not available")
    cmd = [pb, "-0", "-r", root]
    # Bind only what actually exists on the host.
    for host_path, guest_path in (
        ("/dev/null", "/dev/null"),
        ("/dev/zero", "/dev/zero"),
        ("/dev/random", "/dev/random"),
        ("/dev/urandom", "/dev/urandom"),
        ("/dev/tty", "/dev/tty"),
        ("/dev/pts", "/dev/pts"),
        ("/etc/resolv.conf", "/etc/resolv.conf"),
        ("/etc/hosts", "/etc/hosts"),
    ):
        if Path(host_path).exists():
            cmd += ["-b", f"{host_path}:{guest_path}"]
    cmd += ["-w", "/root", "/bin/sh", "-lc", command]
    return cmd


def ensure_proot():
    pb = proot_binary()
    if pb:
        return True
    install_host_packages()
    if proot_binary():
        return True
    # Static x86_64 fallback from the official PRepo.
    if platform.machine().lower() in ("x86_64", "amd64"):
        try:
            fetch("https://proot.gitlab.io/proot/bin/proot", PROOT_LOCAL, min_bytes=100000, attempts=2, max_time=120)
            PROOT_LOCAL.chmod(0o755)
            return proot_binary() is not None
        except Exception as e:
            log("Static PRoot download failed: " + str(e))
    return False


# ---------------------------------------------------------------------------
# Slirp4netns — same pattern as proot: download static binary if missing
# ---------------------------------------------------------------------------
def slirp_binary():
    p = shutil.which("slirp4netns")
    if p:
        return p
    if SLIRP_LOCAL.exists() and os.access(SLIRP_LOCAL, os.X_OK) and SLIRP_LOCAL.stat().st_size > 50000:
        return str(SLIRP_LOCAL)
    return None


def ensure_slirp():
    if slirp_binary():
        return True
    install_host_packages()
    if slirp_binary():
        return True
    # Static binaries published by the upstream container project.
    if platform.machine().lower() in ("x86_64", "amd64"):
        try:
            fetch("https://github.com/rootless-containers/slirp4netns/releases/download/v1.3.1/slirp4netns-x86_64", SLIRP_LOCAL, min_bytes=100000, attempts=2, max_time=120)
            SLIRP_LOCAL.chmod(0o755)
            return slirp_binary() is not None
        except Exception as e:
            log("Static slirp4netns download failed: " + str(e))
    return False


def test_user_namespace():
    if not have("unshare"):
        return False
    try:
        cp = run(["unshare", "-Urn", "--", "/bin/true"], timeout=10, capture=True)
        return cp.returncode == 0
    except Exception:
        return False


def capabilities():
    netns = test_user_namespace()
    slirp = ensure_slirp() if netns else False
    return {
        "proot": proot_binary() is not None,
        "user_network_namespace": netns,
        "slirp4netns": slirp_binary() is not None,
        "private_network": bool(netns and slirp),
        "mode": "namespace+slirp" if netns and slirp else "proot-fallback",
    }


CAPS = None


def ensure_base(progress_cb=None):
    global CAPS
    migrate_base()
    if not (BASE / "bin/sh").exists():
        urls = ubuntu_urls()
        if not urls:
            raise RuntimeError("Unsupported CPU architecture for Ubuntu base: " + platform.machine())
        # Determine the actual version we successfully fetched by checking the
        # local filename after the first mirror that works.
        arc = None
        last_err = None
        tried = 0
        total = len(urls)
        for url in urls:
            tried += 1
            try:
                # Parse version from URL
                m = re.search(r"ubuntu-base-([\d.]+)-base-", url)
                ver = m.group(1) if m else "unknown"
                arc = IMAGES / f"ubuntu-{ver}-{arch_name()}.tar.gz"
                if not arc.exists():
                    host = urlparse(url).hostname
                    msg = f"Downloading Ubuntu {ver} base ({tried}/{total} via {host})"
                    log(msg)
                    if progress_cb:
                        progress_cb(8, "downloading", msg)
                    fetch(url, arc, min_bytes=1024 * 1024)
                else:
                    log(f"Using cached Ubuntu {ver} base at {arc.name}")
                break
            except Exception as e:
                last_err = e
                log(f"Mirror {tried}/{total} failed: {e}")
                continue
        if not arc or not arc.exists():
            raise RuntimeError(f"All {total} Ubuntu mirrors failed. Last error: {last_err}")
        if run(["tar", "-tzf", str(arc)], timeout=120).returncode != 0:
            arc.unlink(missing_ok=True)
            raise RuntimeError("Ubuntu archive validation failed (corrupt download)")
        shutil.rmtree(BASE_NEW, ignore_errors=True)
        BASE_NEW.mkdir(parents=True, exist_ok=True)
        cp = run(["tar", "-xzf", str(arc), "-C", str(BASE_NEW)], timeout=600, capture=True)
        if cp.returncode != 0:
            shutil.rmtree(BASE_NEW, ignore_errors=True)
            raise RuntimeError("Ubuntu extraction failed: " + (cp.stderr or ""))
        if not (BASE_NEW / "bin/sh").exists():
            raise RuntimeError("Ubuntu rootfs incomplete")
        os.replace(BASE_NEW, BASE)

    for p in ("proc", "sys", "dev", "dev/pts", "run", "tmp", "workspace"):
        (BASE / p).mkdir(parents=True, exist_ok=True)
    try:
        (BASE / "tmp").chmod(0o1777)
    except Exception:
        pass
    # /etc/resolv.conf may be a symlink (systemd-resolved, NetworkManager).
    # Resolve the link on the host, then write the target's contents directly
    # into the base so the workspace always has working DNS.
    try:
        src = Path("/etc/resolv.conf").resolve()
        if src.exists() and src.is_file():
            (BASE / "etc/resolv.conf").unlink(missing_ok=True)
            (BASE / "etc/resolv.conf").write_text(src.read_text())
        else:
            # sensible default
            (BASE / "etc/resolv.conf").write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
    except Exception as e:
        log(f"resolv.conf copy failed: {e}")
    (BASE / "etc/hostname").write_text("darkssh-ubuntu\n")
    seed_keyring(BASE)
    repair_sources(BASE)

    apt_cmd = "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y --no-install-recommends ca-certificates curl"
    cp = run(pcmd(BASE, apt_cmd), timeout=900, capture=True)
    if cp.returncode != 0:
        msg = (cp.stdout or "") + "\n" + (cp.stderr or "")
        raise RuntimeError("Ubuntu base APT repair failed:\n" + msg[-5000:])

    sshx = BASE / "usr/local/bin/sshx"
    sshx.parent.mkdir(parents=True, exist_ok=True)
    if not sshx.exists() or not os.access(sshx, os.X_OK):
        cmd = "set -eu; cd /usr/local/bin; rm -f sshx; curl -fsSL https://sshx.io/get | sh -s download; test -x ./sshx"
        cp = run(pcmd(BASE, cmd), timeout=180, capture=True)
        if cp.returncode != 0:
            raise RuntimeError("SSHX installation failed:\n" + ((cp.stdout or "") + "\n" + (cp.stderr or ""))[-5000:])
    try:
        sshx.chmod(0o755)
    except Exception:
        pass
    check = run(pcmd(BASE, "/usr/local/bin/sshx --version"), timeout=30, capture=True)
    if check.returncode != 0:
        raise RuntimeError("Workspace SSHX verification failed: " + ((check.stdout or "") + (check.stderr or ""))[-1000:])

    # Best-effort hardening — remove guest-side network diagnostic tools so a
    # malicious workspace can't easily enumerate the host network.
    harden = r'''set +e
for f in /usr/bin/ss /usr/sbin/ss /usr/bin/netstat /usr/bin/lsof /usr/bin/nmap /usr/sbin/tcpdump /usr/sbin/iptables /usr/sbin/ip6tables /usr/bin/ip /usr/sbin/ip; do rm -f "$f"; done
for n in ss netstat lsof nmap tcpdump iptables ip6tables ip; do printf '#!/bin/sh\necho "command unavailable in DARKSSH workspace" >&2\nexit 127\n' > "/usr/local/bin/$n"; chmod 755 "/usr/local/bin/$n"; done
'''
    run(pcmd(BASE, harden), timeout=120, check=False)
    CAPS = capabilities()


def clone(dst):
    tmp = dst.with_name(dst.name + ".new")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    a = subprocess.Popen(["tar", "-C", str(BASE), "-cf", "-", "."], stdout=subprocess.PIPE)
    b = subprocess.Popen(["tar", "-C", str(tmp), "-xf", "-"], stdin=a.stdout)
    a.stdout.close()
    brc = b.wait()
    arc = a.wait()
    if brc != 0 or arc != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Workspace clone failed")
    os.replace(tmp, dst)
    (dst / "etc/hosts").write_text("127.0.0.1 localhost\n::1 localhost\n")
    (dst / "etc/hostname").write_text("darkssh-" + dst.parent.name[:12] + "\n")


# ---------------------------------------------------------------------------
# Session management
# ---------------------------------------------------------------------------
def set_progress(sid, percent, stage, message=""):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r.update(progress=max(0, min(100, int(percent))), stage=stage, message=message, last_activity=time.time())
            save()


def create_request(name):
    with LOCK:
        active = sum(r.get("status") in ("queued", "starting", "running") for r in STATE["sessions"].values())
        if active >= int(CFGDATA.get("max_sessions", 25)):
            raise RuntimeError("Maximum sessions reached")
        sid = secrets.token_hex(8)
        owner = secrets.token_urlsafe(32)
        rec = {
            "id": sid,
            "name": (name or "workspace-" + sid[:6])[:80],
            "status": "queued",
            "progress": 1,
            "stage": "queued",
            "message": "Queued for workspace worker",
            "sshx_url": None,
            "created_at": time.time(),
            "last_activity": time.time(),
            "ended_at": None,
            "error": None,
            "owner_token": owner,
        }
        STATE["sessions"][sid] = rec
        READY_EVENTS[sid] = threading.Event()
        save()
    CREATE_POOL.submit(build_session, sid)
    return rec.copy()


def namespace_command(root, command):
    """Return (Popen args, slirp-needed).

    namespace+slirp mode gives the guest a private network namespace. If the
    host blocks user/network namespaces, we deliberately fall back to PRoot
    without binding the host /proc or /sys.
    """
    base = pcmd(root, command)
    if CAPS and CAPS.get("private_network"):
        # -U user, -r remount, -n net, -p fork, -f mount-fs;
        # --kill-child ensures the whole namespace tree dies when unshare exits.
        return ["unshare", "-Urnpf", "--mount-proc=/proc", "--kill-child=SIGKILL", "--"] + base, True
    return base, False


def start_slirp(target_pid):
    """Attach slirp4netns to an already-running process that lives inside a
    private network namespace. The PID must be the in-namespace child, not the
    unshare parent — slirp uses /proc/<pid>/ns/net to find the netns."""
    sb = slirp_binary()
    if not sb or not (CAPS and CAPS.get("private_network")):
        return None
    try:
        p = subprocess.Popen(
            [sb, "--configure", "--mtu=65520", str(target_pid), "tap0"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        time.sleep(0.5)
        if p.poll() is not None:
            log("slirp4netns exited immediately")
            return None
        return p
    except Exception as e:
        log("slirp4netns failed; continuing with host-network fallback: " + str(e))
        return None


def build_session(sid):
    try:
        set_progress(sid, 5, "checking", "Detecting host OS, architecture and isolation capabilities")
        if not ensure_proot():
            raise RuntimeError("PRoot is unavailable and could not be installed automatically")
        ensure_base(progress_cb=lambda pct, stage, msg: set_progress(sid, pct, stage, msg))
        set_progress(sid, 20, "base-ready", "Ubuntu base verified and SSHX installed automatically")
        with LOCK:
            if sid not in STATE["sessions"]:
                return
            STATE["sessions"][sid].update(status="starting", stage="workspace")
            save()
        root = SESSIONS / sid / "rootfs"
        root.parent.mkdir(parents=True, exist_ok=True)
        set_progress(sid, 30, "copying", "Creating a private workspace filesystem")
        clone(root)
        set_progress(sid, 55, "isolating", "Selecting the strongest isolation supported by this host")
        cmd = """set -eu
export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
cd /root
exec /usr/local/bin/sshx run
"""
        args, needs_slirp = namespace_command(root, cmd)
        set_progress(sid, 65, "starting", "Launching SSHX")
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, start_new_session=True)
        with LOCK:
            PROCS[sid] = p
            STATE["sessions"][sid]["pid"] = p.pid
            STATE["sessions"][sid]["isolation"] = "private-network" if needs_slirp else "proot-filesystem"
            save()
        if needs_slirp:
            # When unshare forks, the PID we see is the unshare parent.
            # slirp4netns needs the *child* PID inside the namespace. We use
            # /proc/<pid>/task to find the single child that is actually
            # running sshx.
            child_pid = _find_namespace_child(p.pid)
            sp = start_slirp(child_pid) if child_pid else None
            if sp:
                NETPROCS[sid] = sp
                set_progress(sid, 70, "network", "Private network namespace configured")
            else:
                set_progress(sid, 70, "network-fallback", "Host blocks private networking; using filesystem-isolated fallback")
        else:
            set_progress(sid, 70, "network-fallback", "Private network namespace unavailable on this host; using filesystem-isolated fallback")
        set_progress(sid, 75, "sshx", "SSHX is running; waiting for its access URL")
        threading.Thread(target=watch, args=(sid, p), daemon=True).start()
    except Exception as e:
        log(sid + ": FAILED: " + str(e))
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                r.update(status="error", progress=100, stage="error", message="Creation failed", error=str(e), ended_at=time.time())
                save()
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
        PROCS.pop(sid, None)


def _find_namespace_child(parent_pid):
    """Find the in-namespace child PID of an unshare parent.

    unshare forks; the parent we hold is unshare itself, the child is the
    process actually running inside the new namespace. slirp4netns must be
    given the child PID so it can attach to /proc/<child>/ns/net."""
    try:
        # Walk /proc/<parent>/task/<parent>/children — works on Linux ≥3.x
        # if CONFIG_PROC_CHILDREN is enabled. Otherwise fall back to scanning
        # all tasks for one whose children list contains a non-self PID.
        children_path = Path(f"/proc/{parent_pid}/task/{parent_pid}/children")
        if children_path.exists():
            ids = children_path.read_text().split()
            if ids:
                return int(ids[0])
        # Fallback: look for any process whose PPID is parent_pid
        for entry in Path("/proc").iterdir():
            if not entry.name.isdigit():
                continue
            try:
                stat = (entry / "stat").read_text().split()
                # stat[3] is ppid
                if int(stat[3]) == parent_pid:
                    return int(entry.name)
            except Exception:
                continue
    except Exception:
        pass
    return None


def watch(sid, p):
    rc = 1
    try:
        for line in p.stdout:
            line = line.strip()
            if line:
                log(sid + ": " + line)
            m = URLRE.search(line)
            if m:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    if r:
                        url = m.group(0).rstrip(".,);]")
                        r.update(status="running", progress=100, stage="ready", message="SSHX session is ready", sshx_url=url, last_activity=time.time())
                        save()
                ev = READY_EVENTS.get(sid)
                if ev:
                    ev.set()
        rc = p.wait()
    except Exception as e:
        log(sid + ": watcher: " + str(e))
    finally:
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and r.get("status") != "deleted":
                r["status"] = "stopped" if rc == 0 else "error"
                r["ended_at"] = time.time()
                if rc and not r.get("error"):
                    r["error"] = f"SSHX exited with code {rc}"
                save()
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
            PROCS.pop(sid, None)
        sp = NETPROCS.pop(sid, None)
        if sp and sp.poll() is None:
            try:
                sp.terminate()
            except Exception:
                pass


def _kill_proc(p):
    """Kill a process and all its descendants, then reap it."""
    if p.poll() is not None:
        return
    try:
        os.killpg(p.pid, signal.SIGTERM)
    except Exception:
        try:
            p.terminate()
        except Exception:
            pass
    try:
        p.wait(5)
    except Exception:
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass


def delete(sid):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if not r:
            return False
        p = PROCS.get(sid)
    if p:
        _kill_proc(p)
    with LOCK:
        sp = NETPROCS.pop(sid, None)
    if sp and sp.poll() is None:
        try:
            sp.terminate()
        except Exception:
            pass
    shutil.rmtree(SESSIONS / sid, ignore_errors=True)
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r["status"] = "deleted"
            r["ended_at"] = time.time()
            save()
        ev = READY_EVENTS.get(sid)
        if ev:
            ev.set()
        PROCS.pop(sid, None)
    return True


def public(r, secret=False):
    fields = ("id", "name", "status", "progress", "stage", "message", "sshx_url", "created_at", "last_activity", "ended_at", "error", "isolation")
    out = {k: r.get(k) for k in fields}
    if secret:
        out["owner_token"] = r.get("owner_token")
    return out


def authorized(headers, sid=None, allow_api=True):
    auth = headers.get("Authorization", "")
    if allow_api and CFGDATA.get("api_key") and auth.startswith("Bearer "):
        try:
            if secrets.compare_digest(auth[7:], CFGDATA["api_key"]):
                return "api"
        except Exception:
            pass
    if sid:
        token = headers.get("X-Session-Token", "")
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and token and secrets.compare_digest(token, r.get("owner_token", "")):
                return "owner"
    return None


def janitor():
    while not SHUTDOWN.is_set():
        if SHUTDOWN.wait(15):
            break
        now = time.time()
        limit = max(60, int(CFGDATA.get("idle_minutes", 60)) * 60)
        with LOCK:
            ids = [sid for sid, r in STATE["sessions"].items() if r.get("status") in ("queued", "starting", "running") and now - r.get("last_activity", now) >= limit]
        for sid in ids:
            log("Idle timeout: " + sid)
            delete(sid)


# ---------------------------------------------------------------------------
# HTTP layer
# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "DARKSSH/3"

    def log_message(self, *args):
        pass

    def sendj(self, code, obj):
        b = json.dumps(obj, separators=(",", ":")).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n > 65536:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Session-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"):
            f = APP / "static" / "index.html"
            if not f.exists():
                f = APP / "index.html"
            try:
                b = f.read_bytes()
            except Exception:
                b = b"<h1>DARKSSH</h1><p>UI not installed.</p>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)
            return
        if p == "/api/health":
            global CAPS
            if CAPS is None:
                CAPS = capabilities()
            return self.sendj(200, {
                "ok": True,
                "service": "DARKSSH",
                "version": "3",
                "ubuntu": "24.04",
                "host": detect_host(),
                "capabilities": CAPS,
                "auth": "enabled" if CFGDATA.get("api_key") else "disabled",
                "warnings": preflight(),
            })
        if p == "/api/sessions":
            mode = authorized(self.headers)
            if mode != "api":
                return self.sendj(401, {"error": "API key required"})
            with LOCK:
                return self.sendj(200, {"sessions": [public(r) for r in STATE["sessions"].values()]})
        if p.startswith("/api/sessions/"):
            sid = p.rsplit("/", 1)[-1]
            mode = authorized(self.headers, sid)
            if not mode:
                return self.sendj(401, {"error": "API key or session token required"})
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.sendj(404, {"error": "session not found"})
                return self.sendj(200, {"session": public(r)})
        self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        p = parsed.path
        if p == "/api/sessions":
            if authorized(self.headers) != "api":
                return self.sendj(401, {"error": "API key required"})
            try:
                d = self.body()
            except Exception as e:
                return self.sendj(400, {"error": str(e)})
            try:
                rec = create_request(str(d.get("name", "")))
                qs = parse_qs(parsed.query)
                async_mode = qs.get("wait", ["true"])[0].lower() == "false" or qs.get("async", ["0"])[0] == "1"
                if async_mode:
                    return self.sendj(202, {"ok": True, "ready": False, "session": public(rec, secret=True)})
                ev = READY_EVENTS[rec["id"]]
                if not ev.wait(300):
                    with LOCK:
                        current = STATE["sessions"].get(rec["id"], rec)
                    return self.sendj(504, {"ok": False, "ready": False, "error": "Timed out waiting for SSHX URL", "session": public(current, secret=True)})
                with LOCK:
                    final = STATE["sessions"].get(rec["id"])
                if not final:
                    return self.sendj(404, {"ok": False, "error": "session disappeared"})
                if final.get("sshx_url"):
                    return self.sendj(200, {"ok": True, "ready": True, "session": public(final, secret=True)})
                return self.sendj(502, {"ok": False, "ready": False, "error": final.get("error") or "SSHX exited before producing a URL", "session": public(final, secret=True)})
            except Exception as e:
                log("create: " + str(e))
                return self.sendj(500, {"error": str(e)})
        if p.startswith("/api/sessions/") and p.endswith("/heartbeat"):
            sid = p.split("/")[-2]
            if not authorized(self.headers, sid):
                return self.sendj(401, {"error": "API key or session token required"})
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.sendj(404, {"error": "session not found"})
                r["last_activity"] = time.time()
                save()
            return self.sendj(200, {"ok": True})
        self.send_error(404)

    def do_DELETE(self):
        p = urlparse(self.path).path
        if p.startswith("/api/sessions/"):
            sid = p.rsplit("/", 1)[-1]
            if not authorized(self.headers, sid):
                return self.sendj(401, {"error": "API key or session token required"})
            ok = delete(sid)
            return self.sendj(200 if ok else 404, {"ok": ok})
        self.send_error(404)


# ---------------------------------------------------------------------------
# Graceful shutdown — kill all child processes (sshx, slirp, proot, unshare)
# ---------------------------------------------------------------------------
def shutdown(*_):
    log("Shutdown signal received; cleaning up all sessions")
    SHUTDOWN.set()
    with LOCK:
        sids = list(STATE["sessions"].keys())
    for sid in sids:
        delete(sid)
    try:
        CREATE_POOL.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
    log("All sessions terminated. Exiting.")
    os._exit(0)


def main():
    global CAPS
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    CAPS = capabilities()
    log("Host: " + json.dumps(detect_host(), separators=(",", ":")))
    log("Capabilities: " + json.dumps(CAPS, separators=(",", ":")))
    for w in preflight():
        log("PREFLIGHT WARNING: " + w)
    log("API key authentication ENABLED")
    log("API URL: http://0.0.0.0:" + str(int(CFGDATA["port"])))
    log("API KEY: " + CFGDATA["api_key"])
    threading.Thread(target=janitor, daemon=True).start()
    try:
        ThreadingHTTPServer((CFGDATA["host"], int(CFGDATA["port"])), Handler).serve_forever()
    except KeyboardInterrupt:
        shutdown()


if __name__ == "__main__":
    main()
