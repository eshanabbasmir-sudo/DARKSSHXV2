# DARKSSH v3 — Automatic Ubuntu + SSHX Workspace Server

DARKSSH creates isolated Ubuntu workspaces and launches the official SSHX client.
It auto-detects the host OS, package manager, CPU architecture, kernel capabilities
and namespace restrictions, then installs whatever is missing and selects the
strongest isolation mode the host actually permits.

## What's automatic

On startup DARKSSH detects and (where needed) installs:

- Host OS and package manager (apt-get / apk / dnf / yum / pacman / zypper / pkg / xbps-install / swupd / eopkg)
- CPU architecture (amd64 / arm64 / armhf / ppc64el / s390x / riscv64)
- Python 3 (via the host package manager)
- PRoot (package manager, then static x86_64 binary fallback)
- slirp4netns (package manager, then static x86_64 binary fallback)
- User/network namespace support (tested live, not assumed)
- Ubuntu 24.04 LTS base (multiple mirrors + version fallback so URLs never rot)
- Ubuntu archive GPG keyring (host copy first, then download)
- SSHX client inside the Ubuntu base (official `sshx.io/get` installer)

It repairs the cached Ubuntu base before creating sessions. SSHX is installed
inside the Ubuntu workspace, so the host's `/usr/local/bin/sshx` is never required.

## What's new in v3 (bug fixes)

| # | Bug fixed |
|---|-----------|
| 1 | `DARKSSH_PORT` (and other env vars) are now honoured — previously ignored |
| 2 | `proot_binary()` returns `None` when no binary is available, instead of returning a non-existent path |
| 3 | `pcmd` only binds `/dev/tty`, `/dev/pts`, `/etc/resolv.conf`, `/etc/hosts` when they actually exist on the host |
| 4 | `/etc/resolv.conf` is now safe when it's a symlink (systemd-resolved) or missing — writes resolved contents directly |
| 5 | slirp4netns now attaches to the in-namespace child PID (was attaching to the unshare parent — never worked) |
| 6 | SIGTERM/SIGINT now kill all child processes (sshx, slirp, proot, unshare) — no more orphans |
| 7 | Disk-space and memory preflight checks warn before mysterious failures |
| 8 | Ubuntu download tries multiple mirrors + multiple version point releases |
| 9 | `install_host_packages` logs each failure with the stderr reason instead of swallowing it silently |
| 10 | `start.sh` auto-restarts the server on crash (exponential backoff up to 30s) |
| 11 | `start.sh` forwards SIGTERM/SIGINT to the child correctly |
| 12 | Config file is regenerated if corrupt — server can no longer die on bad JSON |
| 13 | Support for more package managers: xbps-install (Void), swupd (Clear), eopkg (Solus) |
| 14 | More architectures: ppc64el, s390x, riscv64 |
| 15 | Duplicate root `index.html` removed; single source of truth in `static/` |

## Isolation modes

DARKSSH chooses the strongest mode the host actually permits:

1. **namespace+slirp** — private user/PID/network namespace when `unshare` and
   `slirp4netns` are available and user namespaces are permitted.
2. **proot-fallback** — filesystem isolation without binding the host `/proc`
   or `/sys` when the hosting provider blocks namespaces.

The fallback is intentionally reported in `/api/health` rather than falsely
advertised as kernel-level isolation. A container/VPS can prevent namespace
creation, ptrace, network configuration, or package installation; no user-space
program can re-enable capabilities removed by the host.

## Start

```bash
chmod +x start.sh
./start.sh
```

No questions are required. Defaults:

- API port: `5000`
- idle timeout: `60` minutes
- maximum concurrent sessions: `25`
- auto-restart on crash: enabled

For unattended deployment:

```bash
DARKSSH_PORT=5000 DARKSSH_IDLE_MINUTES=60 DARKSSH_MAX_SESSIONS=25 ./start.sh
```

To disable auto-restart (e.g. for systemd which handles restarts itself):

```bash
DARKSSH_NO_RESTART=1 ./start.sh
```

## Diagnostics

```bash
chmod +x troubleshoot.sh
./troubleshoot.sh
```

Prints OS, kernel, arch, package manager, all required tools (present/missing),
namespace support test, container detection, config file (API key redacted),
state file, SSHX version inside the base, and a health check.

## API

All session creation requests require the generated Bearer API key (printed by
`start.sh` on first run, also visible in `config.json`).
Creation returns a per-session `owner_token`. The owner token can be used in
`X-Session-Token` for status, heartbeat and delete operations without exposing
other sessions.

```bash
# Health / capabilities (public)
curl http://HOST:5000/api/health

# Create a session (async — returns immediately)
curl -X POST 'http://HOST:5000/api/sessions?wait=false' \
  -H 'Authorization: Bearer API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{"name":"my-workspace"}'

# Create a session (sync — waits up to 5 min for the sshx URL)
curl -X POST http://HOST:5000/api/sessions \
  -H 'Authorization: Bearer API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{"name":"my-workspace"}'

# List sessions
curl http://HOST:5000/api/sessions -H 'Authorization: Bearer API_KEY'

# Get a specific session (use either API key or session owner token)
curl http://HOST:5000/api/sessions/SESSION_ID -H 'Authorization: Bearer API_KEY'
curl http://HOST:5000/api/sessions/SESSION_ID -H 'X-Session-Token: OWNER_TOKEN'

# Heartbeat (keeps an idle session alive)
curl -X POST http://HOST:5000/api/sessions/SESSION_ID/heartbeat -H 'X-Session-Token: OWNER_TOKEN'

# Delete
curl -X DELETE http://HOST:5000/api/sessions/SESSION_ID -H 'Authorization: Bearer API_KEY'
```

## Important limitation

"Every VPS/container" cannot literally mean every Linux environment. A host
can disable user namespaces, ptrace, networking, outbound HTTPS, package
installation, or execution of binaries. DARKSSH detects these restrictions and
uses its fallback where possible; otherwise it returns a precise error instead
of pretending the isolation is stronger than it is.

For genuinely untrusted multi-tenant workloads, use a kernel-level container
runtime/VM with provider-controlled namespaces and seccomp. PRoot is a user-space
compatibility layer, not a replacement for a VM or container runtime.

## Files

| File | Purpose |
|------|---------|
| `start.sh` | Launcher — installs deps, starts server with auto-restart |
| `server.py` | HTTP API server, session manager, base/image maintainer |
| `troubleshoot.sh` | Diagnostic dump |
| `static/index.html` | Web UI (single source of truth) |
| `config.json` | Generated on first run (host/port/idle/max/api_key) |
| `data/` | Sessions, Ubuntu base, downloaded images, state.json |
| `bin/` | Local fallback binaries (proot, slirp4netns) |
