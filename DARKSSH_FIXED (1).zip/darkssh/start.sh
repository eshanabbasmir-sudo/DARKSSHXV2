#!/usr/bin/env bash
# DARKSSH launcher — auto-restart, signal forwarding, robust OS detection.
#
# Defaults (overridable via env):
#   DARKSSH_PORT=5000
#   DARKSSH_HOST=0.0.0.0
#   DARKSSH_IDLE_MINUTES=60
#   DARKSSH_MAX_SESSIONS=25
#   DARKSSH_RESTART_DELAY=2   (seconds between restart attempts)
#   DARKSSH_NO_RESTART=0      (set to 1 to disable auto-restart)
set -u

APP="$(cd "$(dirname "$0")" && pwd)"
cd "$APP" || exit 1

log(){ printf '\n[DARKSSH] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*" >&2; }

# ------------------------------------------------------------------
# Privilege escalation helper. Returns 0 if we are root, otherwise
# tries sudo / doas / su. Returns 127 if no escalation is available.
# ------------------------------------------------------------------
run_as_root(){
  if [ "$(id -u)" -eq 0 ]; then "$@"; return $?; fi
  if command -v sudo >/dev/null 2>&1; then sudo -n "$@" 2>/dev/null && return $?; fi
  if command -v doas >/dev/null 2>&1; then doas "$@"; return $?; fi
  return 127
}

# ------------------------------------------------------------------
# Package manager detection. Order matters: distro-specific tools
# before generic ones so we don't accidentally use a fallback.
# ------------------------------------------------------------------
pm(){
  for x in apt-get apk dnf yum pacman zypper pkg xbps-install swupd eopkg; do
    if command -v "$x" >/dev/null 2>&1; then echo "$x"; return; fi
  done
}

# ------------------------------------------------------------------
# Install python3 if missing. Tries the host's package manager first,
# then falls back to pyenv-style local install (last resort).
# ------------------------------------------------------------------
install_python(){
  command -v python3 >/dev/null 2>&1 && return 0
  P="$(pm || true)"
  case "$P" in
    apt-get) run_as_root apt-get update -qq 2>/dev/null; run_as_root apt-get install -y python3 ca-certificates curl tar gzip 2>/dev/null || true ;;
    apk) run_as_root apk add --no-cache python3 ca-certificates curl tar gzip 2>/dev/null || true ;;
    dnf|yum) run_as_root "$P" install -y python3 ca-certificates curl tar gzip 2>/dev/null || true ;;
    pacman) run_as_root pacman -Sy --noconfirm python ca-certificates curl tar gzip 2>/dev/null || true ;;
    zypper) run_as_root zypper --non-interactive install python3 ca-certificates curl tar gzip 2>/dev/null || true ;;
    pkg) run_as_root pkg install -y python curl tar gzip 2>/dev/null || true ;;
    xbps-install) run_as_root xbps-install -Sy python3 ca-certificates curl tar gzip 2>/dev/null || true ;;
    swupd) run_as_root swupd bundle-add python3 curl tar gzip 2>/dev/null || true ;;
    eopkg) run_as_root eopkg install -y python3 curl tar gzip 2>/dev/null || true ;;
    *) ;;
  esac
  command -v python3 >/dev/null 2>&1
}

# ------------------------------------------------------------------
# Install required host-side tools (curl/wget/tar/gzip/proot/slirp4netns)
# Best-effort: missing tools are not fatal because the Python server
# has its own fallback chain. We just try to give it the best start.
# ------------------------------------------------------------------
install_runtime_deps(){
  local P; P="$(pm || true)"
  [ -z "$P" ] && { warn "No package manager detected; skipping runtime dep install"; return 0; }
  local packages=""
  case "$P" in
    apt-get) packages="ca-certificates curl wget tar gzip proot slirp4netns util-linux" ;;
    apk) packages="ca-certificates curl wget tar gzip proot slirp4netns util-linux" ;;
    dnf|yum) packages="ca-certificates curl wget tar gzip proot slirp4netns util-linux" ;;
    pacman) packages="ca-certificates curl wget tar gzip proot slirp4netns util-linux" ;;
    zypper) packages="ca-certificates curl wget tar gzip proot util-linux" ;;
    pkg) packages="curl wget tar gzip proot" ;;
    xbps-install) packages="ca-certificates curl wget tar gzip proot util-linux" ;;
    swupd) packages="ca-certificates curl wget tar gzip proot" ;;
    eopkg) packages="ca-certificates curl wget tar gzip proot" ;;
  esac
  [ -z "$packages" ] && return 0
  log "Installing runtime dependencies via $P: $packages"
  case "$P" in
    apt-get) run_as_root apt-get install -y --no-install-recommends $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    apk) run_as_root apk add --no-cache $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    dnf|yum) run_as_root "$P" install -y $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    pacman) run_as_root pacman -S --noconfirm $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    zypper) run_as_root zypper --non-interactive install --no-recommends $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    pkg) run_as_root pkg install -y $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    xbps-install) run_as_root xbps-install -y $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    swupd) run_as_root swupd bundle-add $packages 2>/dev/null || warn "Some packages may not have installed" ;;
    eopkg) run_as_root eopkg install -y $packages 2>/dev/null || warn "Some packages may not have installed" ;;
  esac
}

# ------------------------------------------------------------------
# Print detected environment so logs are useful when troubleshooting.
# ------------------------------------------------------------------
print_env(){
  log "============== DARKSSH environment =============="
  printf '  Working dir : %s\n' "$APP"
  printf '  User        : %s (uid=%s)\n' "$(whoami 2>/dev/null || echo unknown)" "$(id -u 2>/dev/null || echo ?)"
  printf '  OS          : '
  if [ -r /etc/os-release ]; then . /etc/os-release 2>/dev/null && printf '%s %s\n' "${PRETTY_NAME:-unknown}" "${VERSION_ID:-}"; else printf '%s\n' "$(uname -s)"; fi
  printf '  Kernel      : %s\n' "$(uname -sr 2>/dev/null)"
  printf '  Arch        : %s\n' "$(uname -m 2>/dev/null)"
  printf '  Package mgr : %s\n' "$(pm || echo none)"
  printf '  Python      : '
  command -v python3 >/dev/null 2>&1 && python3 --version 2>&1 || printf 'not found\n'
  printf '  PRoot       : '
  command -v proot >/dev/null 2>&1 && proot --version 2>&1 | head -1 || printf 'not found (will be installed or downloaded)\n'
  printf '  slirp4netns : '
  command -v slirp4netns >/dev/null 2>&1 && slirp4netns --version 2>&1 | head -1 || printf 'not found (private networking may be unavailable)\n'
  printf '  unshare     : '
  command -v unshare >/dev/null 2>&1 && unshare --version 2>&1 | head -1 || printf 'not found\n'
  log "================================================="
}

# ------------------------------------------------------------------
# Server process management. Auto-restart on crash unless disabled.
# ------------------------------------------------------------------
start_server(){
  local pid rc restart_count=0
  local restart_delay="${DARKSSH_RESTART_DELAY:-2}"
  local no_restart="${DARKSSH_NO_RESTART:-0}"

  while true; do
    log "Starting DARKSSH server (attempt $((restart_count + 1)))"
    python3 "$APP/server.py" &
    pid=$!

    # Forward signals to the child.
    trap "kill -TERM $pid 2>/dev/null; wait $pid 2>/dev/null; exit 0" TERM INT
    wait $pid
    rc=$?
    trap - TERM INT

    if [ "$no_restart" = "1" ]; then
      log "DARKSSH exited (code $rc). Auto-restart disabled."
      return $rc
    fi
    if [ $rc -eq 0 ]; then
      log "DARKSSH exited cleanly. Stopping."
      return 0
    fi
    restart_count=$((restart_count + 1))
    warn "DARKSSH crashed (code $rc). Restarting in ${restart_delay}s (attempt $restart_count)"
    sleep "$restart_delay"
    # Exponential backoff up to 30s.
    restart_delay=$(( restart_delay * 2 ))
    [ "$restart_delay" -gt 30 ] && restart_delay=30
  done
}

# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
printf '\n==========================================\n'
printf ' DARKSSH v3 - Automatic Host Setup\n'
printf '==========================================\n'

if ! install_python; then
  echo "ERROR: Python 3 is unavailable and no usable package manager/root helper was found." >&2
  echo "       Install Python 3 manually, then re-run ./start.sh" >&2
  exit 1
fi

# Best-effort runtime deps. Failures here are non-fatal: the server has
# its own fallback download for proot and slirp4netns.
install_runtime_deps

mkdir -p "$APP/data/sessions" "$APP/data/images" "$APP/bin" "$APP/static"

print_env

# Config file is created/validated by the Python server itself; we just
# pass through env vars and let server.py handle defaults + persistence.
log "Configuration:"
log "  Host        : ${DARKSSH_HOST:-0.0.0.0}"
log "  Port        : ${DARKSSH_PORT:-5000}"
log "  Idle (min)  : ${DARKSSH_IDLE_MINUTES:-60}"
log "  Max sessions: ${DARKSSH_MAX_SESSIONS:-25}"
log "  Auto-restart: $([ "${DARKSSH_NO_RESTART:-0}" = "1" ] && echo disabled || echo enabled)"

log "Start command: python3 server.py"
log "Press Ctrl+C to stop. The server will auto-restart on crash."

start_server
