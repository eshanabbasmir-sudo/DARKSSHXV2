#!/usr/bin/env python3
"""
DARKSSH — Universal Hardened SSHX Workspace Server v3.0 MASTERPIECE

╔═══════════════════════════════════════════════════════════════════╗
║                    DARKSSH v3.0 - MASTERPIECE                      ║
║                                                                     ║
║  ✅ Full Network Isolation Per User                                ║
║  ✅ Outbound Internet Enabled                                      ║
║  ✅ Private Ports Per Session (No Cross-Access)                    ║
║  ✅ PRoot Terminal Fixes (No More tput/ptrace Errors)             ║
║  ✅ Enhanced Security Hardening                                    ║
║  ✅ Cross-Platform Support                                        ║
╚═══════════════════════════════════════════════════════════════════╝

Features:
1. Universal OS/Architecture support (Linux, macOS, Windows)
2. Auto-detection of system capabilities
3. Fallback mechanisms for restricted environments
4. Download retry and resume support
5. Multiple mirror support
6. Better error handling and recovery
7. Non-interactive mode support
8. Comprehensive system checking
9. NETWORK ISOLATION - Each user gets isolated network namespace
10. PORT ISOLATION - Private port ranges per session
11. OUTBOUND INTERNET - Full outbound access for all users
12. SECURITY - No cross-session or system access

Author: Prime Automation
Version: 3.0.0 (Masterpiece Build)
"""

import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.error
import socket
import platform
import tempfile
import atexit
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed

# ============================================================================
# CONFIGURATION
# ============================================================================

APP = Path(__file__).resolve().parent
DATA = APP / "data"
SESSIONS = DATA / "sessions"
IMAGES = DATA / "images"
BASE = DATA / "ubuntu-base"
CFG = APP / "config.json"
STATEFILE = DATA / "state.json"

# Create necessary directories
for p in (SESSIONS, IMAGES):
    p.mkdir(parents=True, exist_ok=True)

# Load configuration
try:
    CFGDATA = json.loads(CFG.read_text())
except Exception as e:
    print(f"[DARKSSH] Error loading config: {e}")
    print("[DARKSSH] Please run start.sh first to generate configuration")
    sys.exit(1)

# Load state
STATE = {"sessions": {}}
try:
    STATE.update(json.loads(STATEFILE.read_text()))
except Exception:
    pass

# Global state
PROCS = {}
LOCK = threading.RLock()
CREATE_POOL = ThreadPoolExecutor(max_workers=8, thread_name_prefix="darkssh-create")
URLRE = re.compile(r"https://sshx\.io/s/[^\s\r\n]+")
READY_EVENTS = {}

# Port allocation tracking (for isolation)
ALLOCATED_PORTS = set()
PORT_LOCK = threading.Lock()

# API Authentication
API_KEY = CFGDATA.get("api_key", "")

# Universal mode flag
UNIVERSAL_MODE = CFGDATA.get("universal_mode", False)

# Network configuration
NETWORK_CONFIG = {
    "base_port": int(CFGDATA.get("base_port", 10000)),
    "ports_per_session": int(CFGDATA.get("ports_per_session", 10),
    "enable_outbound": CFGDATA.get("enable_outbound", True),
    "allow_port_access": CFGDATA.get("allow_port_access", False),  # Default: no cross-access
}

# ============================================================================
# SYSTEM DETECTION MODULE
# ============================================================================

class SystemDetector:
    """Comprehensive system detection for cross-platform support"""
    
    def __init__(self):
        self.os_type = None
        self.os_name = None
        self.os_version = None
        self.architecture = None
        self.package_manager = None
        self.is_root = False
        self.is_container = False
        self.has_proot = False
        self.has_docker = False
        self.has_unshare = False
        self.can_isolate = False
        self.detect_all()
    
    def detect_all(self):
        """Run all detection methods"""
        self.os_type = self._detect_os_type()
        self.os_name = self._detect_os_name()
        self.os_version = self._detect_os_version()
        self.architecture = self._detect_architecture()
        self.package_manager = self._detect_package_manager()
        self.is_root = self._check_root()
        self.is_container = self._check_container()
        self.has_proot = self._check_proot()
        self.has_docker = self._check_docker()
        self.has_unshare = self._check_unshare()
        self.can_isolate = self._determine_isolation_method()
    
    def _detect_os_type(self):
        """Detect broad OS type"""
        system = platform.system().lower()
        if system == "linux":
            return "linux"
        elif system == "darwin":
            return "macos"
        elif system == "windows":
            return "windows"
        elif system in ["freebsd", "openbsd", "netbsd"]:
            return "bsd"
        else:
            return system
    
    def _detect_os_name(self):
        """Detect specific OS/distribution name"""
        if self.os_type == "linux":
            return self._detect_linux_distro()
        return self.os_type
    
    def _detect_linux_distro(self):
        """Detect Linux distribution"""
        # Try /etc/os-release
        if os.path.exists("/etc/os-release"):
            try:
                with open("/etc/os-release", "r") as f:
                    content = f.read()
                    id_match = re.search(r'^ID=(.*)', content, re.MULTILINE)
                    if id_match:
                        distro_id = id_match.group(1).strip().lower().replace('"', '').replace("'", "")
                        # Normalize names
                        distro_map = {
                            "ubuntu": "ubuntu",
                            "debian": "debian",
                            "centos": "centos",
                            "rhel": "centos",
                            "fedora": "fedora",
                            "alpine": "alpine",
                            "arch": "arch",
                            "manjaro": "arch",
                            "opensuse": "opensuse",
                            "amzn": "amazon-linux",
                        }
                        return distro_map.get(distro_id, distro_id)
            except Exception:
                pass
        
        # Fallback to file detection
        distro_files = {
            "/etc/debian_version": "debian",
            "/etc/Ubuntu-release": "ubuntu",
            "/etc/centos-release": "centos",
            "/etc/redhat-release": "centos",
            "/etc/alpine-release": "alpine",
            "/etc/arch-release": "arch",
        }
        
        for file_path, distro_name in distro_files.items():
            if os.path.exists(file_path):
                return distro_name
        
        return "unknown-linux"
    
    def _detect_os_version(self):
        """Detect OS version"""
        try:
            if self.os_type == "linux" and os.path.exists("/etc/os-release"):
                with open("/etc/os-release", "r") as f:
                    content = f.read()
                    version_match = re.search(r'VERSION_ID=(.*)', content)
                    if version_match:
                        return version_match.group(1).strip().replace('"', '').replace("'", "")
            return platform.version()
        except Exception:
            return "unknown"
    
    def _detect_architecture(self):
        """Detect system architecture"""
        machine = platform.machine().lower()
        # Normalize architecture names
        arch_map = {
            "x86_64": "amd64",
            "amd64": "amd64",
            "aarch64": "arm64",
            "arm64": "arm64",
            "armv7l": "armhf",
            "armhf": "armhf",
            "ppc64le": "ppc64el",
            "riscv64": "riscv64",
            "s390x": "s390x",
        }
        return arch_map.get(machine, machine)
    
    def _detect_package_manager(self):
        """Detect available package manager"""
        package_managers = {
            "apt": ["apt-get", "apt"],
            "dnf": ["dnf"],
            "yum": ["yum"],
            "apk": ["apk"],
            "pacman": ["pacman"],
            "zypper": ["zypper"],
            "brew": ["brew"],
            "choco": ["choco"],
            "pkg": ["pkg"],
        }
        
        for pm, commands in package_managers.items():
            for cmd in commands:
                if shutil.which(cmd):
                    return pm
        return "unknown"
    
    def _check_root(self):
        """Check if running as root"""
        try:
            return os.geteuid() == 0 if hasattr(os, 'geteuid') else False
        except Exception:
            return False
    
    def _check_container(self):
        """Check if running inside a container"""
        indicators = ["/.dockerenv", "/run/.containerenv"]
        for indicator in indicators:
            if os.path.exists(indicator):
                return True
        
        # Check cgroup
        if os.path.exists("/proc/1/cgroup"):
            try:
                with open("/proc/1/cgroup", "r") as f:
                    content = f.read().lower()
                    if any(x in content for x in ["docker", "container", "kubepods"]):
                        return True
            except Exception:
                pass
        
        # Check environment variables
        container_env_vars = ["KUBERNETES_SERVICE_HOST", "DOCKER_CONTAINER"]
        return any(os.environ.get(var) for var in container_env_vars)
    
    def _check_proot(self):
        """Check if PRoot is available"""
        return shutil.which("proot") is not None
    
    def _check_docker(self):
        """Check if Docker is available"""
        return shutil.which("docker") is not None
    
    def _check_unshare(self):
        """Check if unshare is available (for network namespace isolation)"""
        return shutil.which("unshare") is not None
    
    def _determine_isolation_method(self):
        """Determine best isolation method for this system"""
        if self.os_type == "linux":
            if self.has_proot:
                return "proot"
            elif self.has_docker:
                return "docker"
            elif self.is_root:
                return "chroot"  # Fallback to chroot if root
        elif self.os_type == "macos":
            if self.has_docker:
                return "docker"
        elif self.os_type == "windows":
            if self.has_docker:
                return "docker"
        
        # No isolation available - run directly (less secure)
        return "none"
    
    def get_info_dict(self):
        """Return all detection results"""
        return {
            "os_type": self.os_type,
            "os_name": self.os_name,
            "os_version": self.os_version,
            "architecture": self.architecture,
            "package_manager": self.package_manager,
            "is_root": self.is_root,
            "is_container": self.is_container,
            "has_proot": self.has_proot,
            "has_docker": self.has_docker,
            "has_unshare": self.has_unshare,
            "isolation_method": self.can_isolate,
        }
    
    def is_supported(self):
        """Check if this system is supported"""
        # Basic requirements: Python 3.6+, Linux/macOS/Windows
        if sys.version_info < (3, 6):
            return False, "Python 3.6+ required"
        
        if self.os_type not in ["linux", "macos", "windows"]:
            return False, f"Unsupported OS: {self.os_type}"
        
        # Warning if no isolation available
        if self.can_isolate == "none":
            return True, "No isolation available (reduced security)"
        
        return True, "Fully supported"


# Create global detector instance
DETECTOR = SystemDetector()

# ============================================================================
# LOGGING
# ============================================================================

def log(msg):
    """Log message with timestamp"""
    print(f"[DARKSSH] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_debug(msg):
    """Debug logging (only in verbose mode)"""
    if CFGDATA.get("debug", False):
        print(f"[DEBUG] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_warning(msg):
    """Warning logging"""
    print(f"[WARN] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_error(msg):
    """Error logging"""
    print(f"[ERROR] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_info(msg):
    """Info logging"""
    print(f"[INFO] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


# ============================================================================
# STATE PERSISTENCE
# ============================================================================

def save():
    """Save state to file atomically"""
    try:
        t = STATEFILE.with_suffix(".tmp")
        t.write_text(json.dumps(STATE, indent=2))
        os.replace(t, STATEFILE)
    except Exception as e:
        log(f"Error saving state: {e}")


# ============================================================================
# ARCHITECTURE & URL HELPERS
# ============================================================================

def arch():
    """Get normalized architecture name"""
    return DETECTOR.architecture or "amd64"


def have(cmd):
    """Check if command exists"""
    return shutil.which(cmd) is not None


def ubuntu_url():
    """Get Ubuntu base image URL with mirror fallback"""
    a = arch()
    if not a:
        return None
    
    # Primary mirror + fallbacks
    mirrors = [
        f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-{a}.tar.gz",
        f"https://mirrors.edge.kernel.org/ubuntu/dists/noble/main/installer-{a}/current/images/netboot/mini.iso",
    ]
    return mirrors[0]


def get_download_mirrors():
    """Get list of download mirrors for redundancy"""
    a = arch()
    base_filename = f"ubuntu-base-24.04.5-base-{a}.tar.gz"

    mirrors = [
        f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/{base_filename}",
    ]
    
    return [m for m in mirrors if m]


# ============================================================================
# PORT ALLOCATION (For Network Isolation)
# ============================================================================

def allocate_ports(session_id, count=None):
    """
    Allocate isolated ports for a session.
    Each session gets its own private port range.
    No other session can use these ports.
    """
    if count is None:
        count = NETWORK_CONFIG["ports_per_session"]
    
    with PORT_LOCK:
        base = NETWORK_CONFIG["base_port"]
        # Find next available block
        start = base
        while True:
            port_range = set(range(start, start + count))
            if not ALLOCATED_PORTS & port_range:
                ALLOCATED_PORTS.update(port_range)
                return list(port_range)
            start += count + 1  # Leave gap between sessions
            
            # Safety check - don't go beyond ephemeral range
            if start > 65000:
                log_error("Port exhaustion - cannot allocate more ports")
                return list(range(base, base + count))


def release_ports(ports):
    """Release allocated ports when session ends"""
    with PORT_LOCK:
        ALLOCATED_PORTS -= set(ports)


# ============================================================================
# DOWNLOAD WITH RETRY & RESUME
# ============================================================================

def download_with_retry(url, out, max_retries=3, timeout=120):
    """
    Download file with retry and resume support.
    Returns True on success, raises exception on failure.
    """
    part = out.with_suffix(".part")
    
    # Check for partial download to resume
    resume_pos = 0
    if part.exists():
        resume_pos = part.stat().st_size
        log_debug(f"Resuming download from position {resume_pos}")
    
    for attempt in range(max_retries):
        try:
            log(f"Download attempt {attempt + 1}/{max_retries}: {url[:50]}...")
            
            req = urllib.request.Request(url, headers={
                "User-Agent": "DARKSSH/3.0",
            })
            
            # Add Range header for resume
            if resume_pos > 0:
                req.add_header("Range", f"bytes={resume_pos}-")
            
            with urllib.request.urlopen(req, timeout=timeout) as response:
                # Check if server supports range requests
                if response.status == 206:  # Partial Content
                    mode = "ab"  # Append for resume
                elif response.status == 200:
                    mode = "wb"  # Overwrite for full download
                    resume_pos = 0
                else:
                    raise urllib.error.HTTPError(
                        url, response.status, 
                        f"HTTP {response.status}", 
                        response.headers, None
                    )
                
                total_size = int(response.headers.get("Content-Length", 0))
                if resume_pos > 0:
                    total_size += resume_pos
                
                with open(part, mode) as f:
                    downloaded = resume_pos
                    start_time = time.time()
                    
                    while True:
                        chunk = response.read(1024 * 1024)  # 1MB chunks
                        if not chunk:
                            break
                        
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        # Progress reporting every 5 seconds
                        if time.time() - start_time > 5:
                            pct = (downloaded / total_size * 100) if total_size > 0 else 0
                            log_debug(f"Downloaded: {downloaded / (1024*1024):.1f}MB / {total_size / (1024*1024):.1f}MB ({pct:.1f}%)")
                            start_time = time.time()
                
                # Validate download
                if part.stat().st_size < 10 * 1024 * 1024:  # Less than 10MB seems wrong
                    raise RuntimeError("Download too small - possibly an error page")
                
                # Move to final location
                os.replace(part, out)
                log(f"Download complete: {out.name} ({downloaded / (1024*1024):.1f}MB)")
                return True
                
        except urllib.error.HTTPError as e:
            log(f"HTTP Error {e.code} on attempt {attempt + 1}")
            if e.code == 416:  # Range not satisfiable - restart
                resume_pos = 0
                if part.exists():
                    part.unlink()
            elif attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
            else:
                raise
                
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            log(f"Download error on attempt {attempt + 1}: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
            else:
                raise
        
        except Exception as e:
            log(f"Unexpected error on attempt {attempt + 1}: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                raise
    
    return False


# ============================================================================
# PROOT SETUP (Linux) - WITH TERMINAL FIXES
# ============================================================================

def ensure_proot():
    """Ensure PRoot is installed (Linux only)"""
    if DETECTOR.os_type != "linux":
        return True  # Not needed on non-Linux
    
    if have("proot"):
        return True
    
    log("Installing PRoot...")
    
    pm = DETECTOR.package_manager
    try:
        if pm == "apt":
            subprocess.run(["apt-get", "update", "-qq"], timeout=180, capture_output=True)
            subprocess.run(["apt-get", "install", "-y", "proot"], timeout=180, capture_output=True)
        elif pm == "dnf":
            subprocess.run(["dnf", "install", "-y", "proot"], timeout=180, capture_output=True)
        elif pm == "yum":
            subprocess.run(["yum", "install", "-y", "proot"], timeout=180, capture_output=True)
        elif pm == "apk":
            subprocess.run(["apk", "add", "--no-cache", "proot"], timeout=180, capture_output=True)
        elif pm == "pacman":
            subprocess.run(["pacman", "-S", "--noconfirm", "proot"], timeout=180, capture_output=True)
    except Exception as e:
        log(f"Failed to install PRoot: {e}")
    
    DETECTOR.has_proot = have("proot")
    return DETECTOR.has_proot


# ============================================================================
# UBUNTU BASE IMAGE SETUP - ENHANCED FOR NETWORK ACCESS
# ============================================================================

def ensure_base():
    """Download and setup Ubuntu base image with full network support"""
    if (BASE / "bin/sh").exists():
        log_debug("Ubuntu base image already exists")
        return
    
    u = ubuntu_url()
    if not u:
        raise RuntimeError(f"Unsupported CPU architecture: {platform.machine()}")
    
    arc = IMAGES / f"ubuntu-24.04.5-{arch()}.tar.gz"
    
    # Download if not cached
    if not arc.exists():
        log("Downloading Ubuntu base image (~80MB, cached after first download)...")
        
        # Try primary mirror first, then fallbacks
        mirrors = get_download_mirrors()
        downloaded = False
        
        for mirror_url in mirrors:
            try:
                download_with_retry(mirror_url, arc, max_retries=3, timeout=300)
                downloaded = True
                break
            except Exception as e:
                log(f"Mirror failed: {e}")
                continue
        
        if not downloaded:
            raise RuntimeError("All download mirrors failed")
    
    # Validate archive
    log("Validating Ubuntu archive...")
    result = subprocess.run(
        ["tar", "-tzf", str(arc)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    if result.returncode != 0:
        arc.unlink(missing_ok=True)
        raise RuntimeError("Ubuntu archive validation failed - corrupt download?")
    
    # Extract
    log("Extracting Ubuntu base image...")
    tmp = DATA / "ubuntu-base.new"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    
    result = subprocess.run(
        ["tar", "-xzf", str(arc), "-C", str(tmp)],
        timeout=600
    )
    if result.returncode != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Ubuntu extraction failed")
    
    if not (tmp / "bin/sh").exists():
        raise RuntimeError("Ubuntu rootfs incomplete - missing /bin/sh")
    
    # Setup directories
    for p in ("proc", "sys", "dev", "run", "tmp", "workspace"):
        (tmp / p).mkdir(parents=True, exist_ok=True)
    
    try:
        (tmp / "tmp").chmod(0o1777)
    except Exception:
        pass
    
    # Copy resolv.conf for DNS (enables outbound internet)
    try:
        shutil.copy2("/etc/resolv.conf", tmp / "etc/resolv.conf")
    except Exception:
        # Create minimal resolv.conf for DNS
        (tmp / "etc/resolv.conf").write_text(
            "nameserver 8.8.8.8\n"
            "nameserver 8.8.4.4\n"
            "nameserver 1.1.1.1\n"
        )
    
    # Set hostname
    (tmp / "etc/hostname").write_text("darkssh-ubuntu\n")
    
    # Setup hosts file (allows outbound connections)
    (tmp / "etc/hosts").write_text(
        "127.0.0.1 localhost darkssh-localhost\n"
        "::1 localhost\n"
        "# External DNS will resolve other hosts\n"
    )
    
    # Setup profile with FIXED terminal settings (fixes tput/ptrace errors)
    (tmp / "root/.profile").write_text(
        '#!/bin/sh\n'
        'export HOME=/root\n'
        'export USER=root\n'
        'export LOGNAME=root\n'
        'export HOSTNAME=darkssh-ubuntu\n'
        '\n'
        '# FIX: Disable problematic terminal features for PRoot compatibility\n'
        'export TERM=dumb  # Use dumb terminal to avoid tput/ptrace errors\n'
        'export TERMINFO=/usr/share/terminfo\n'
        'export COLORTERM=truecolor\n'
        '\n'
        '# PATH configuration\n'
        'export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"\n'
        '\n'
        '# PS1 - Simple prompt (avoids complex escape sequences that break PRoot)\n'
        'export PS1="\\u@darkssh:\\w$ "\n'
        '\n'
        '# Aliases to prevent tput errors\n'
        'alias clear=":"\n'
        'alias reset=":"\n'
        '\n'
        '# Network is ENABLED - users can access internet\n'
        'export NETWORK_ENABLED=1\n'
        'export HTTP_PROXY="${HTTP_PROXY:-}"\n'
        'export HTTPS_PROXY="${HTTPS_PROXY:-}"\n'
    )
    
    # Create bashrc with terminal fixes
    (tmp / "root/.bashrc").write_text(
        '#!/bin/bash\n'
        '# DARKSSH v3.0 - Terminal Compatibility Layer\n'
        '\n'
        '# FIX: Override tput to prevent ptrace errors in PRoot\n'
        'tput() {\n'
        '    case "$1" in\n'
        '        clear|reset|init)\n'
        '            return 0  # Silently succeed\n'
        '        *)\n'
        '            # For other tput calls, just return empty\n'
        '            return 0\n'
        '    esac\n'
        '}\n'
        '\n'
        '# FIX: Handle other terminal commands that fail in PRoot\n'
        'resize() { :; }\n'
        'tabs() { :; }\n'
        'stty() { :; } 2>/dev/null || true\n'
        '\n'
        '# Enable colors if supported\n'
        'if [ -x /usr/bin/dircolors ]; then\n'
        '    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"\n'
        'fi\n'
        '\n'
        '# Shell options\n'
        'shopt -s checkwinsize 2>/dev/null || true\n'
        'set -o pipefail 2>/dev/null || true\n'
    )
    
    # Install curl and network tools in the base image (for outbound internet)
    log("Installing curl and network tools in base image...")
    try:
        if DETECTOR.can_isolate == "proot":
            subprocess.run(pcmd(tmp,
                'export DEBIAN_FRONTEND=noninteractive; '
                'command -v curl >/dev/null 2>&1 || '
                '(apt-get update -qq --allow-insecure-repositories 2>/dev/null || true; '
                'apt-get install -y --allow-unauthenticated --no-install-recommends '
                'ca-certificates curl wget netbase dnsutils 2>/dev/null || '
                'echo "Package install attempted")'
            ), timeout=600, check=False)
        else:
            log_debug("Skipping base image package installation (no isolation)")
    except Exception as e:
        log_warning(f"Base image setup warning: {e}")
    
    # Apply hardening (but keep network tools for outbound access)
    apply_hardening(tmp)
    
    # Move to final location
    shutil.rmtree(BASE, ignore_errors=True)
    os.replace(tmp, BASE)
    log("Ubuntu base image ready with network support")


def apply_hardening(root):
    """
    Apply security hardening to the rootfs.
    v3.0: Keeps network tools but restricts dangerous system access.
    """
    log("Applying security hardening (v3.0 - Network Preserved)...")
    
    # Create security profile that allows internet but restricts system access
    hardening_cmd = (
        'export DEBIAN_FRONTEND=noninteractive; '
        # Remove DANGEROUS system tools only (keep network tools for outbound)
        'apt-get purge -y --auto-remove '
        'sudo strace ltrace gdb 2>/dev/null || true; '
        # Remove only truly dangerous network tools (keep basic ones)
        'rm -f /usr/sbin/tcpdump /usr/sbin/iptables-restore 2>/dev/null || true; '
        # Create safe stubs for removed tools
        'mkdir -p /usr/local/bin && '
        'for cmd in sudo strace ltrace gdb tcpdump; do '
        '  echo "#!/bin/sh" > "/usr/local/bin/$cmd" && '
        '  echo "echo \\"[SECURITY] $cmd is disabled in this sandbox\\" >&2" >> "/usr/local/bin/$cmd" && '
        '  echo "exit 126" >> "/usr/local/bin/$cmd" && '
        '  chmod +x "/usr/local/bin/$cmd"; '
        'done; '
        # Restrict access to sensitive files
        'chmod 700 /root 2>/dev/null || true; '
        'chmod 600 /etc/shadow 2>/dev/null || true; '
        'true'
    )
    
    try:
        if DETECTOR.can_isolate == "proot":
            subprocess.run(pcmd(root, hardening_cmd), timeout=120, check=False)
        else:
            log_debug("Skipping hardening (no isolation available)")
    except Exception as e:
        log_debug(f"Hardening warning: {e}")


# ============================================================================
# ISOLATION COMMAND BUILDERS - ENHANCED FOR NETWORK ISOLATION
# ============================================================================

def pcmd(root, cmd, session_ports=None):
    """
    Build command with appropriate isolation method.
    v3.0: Adds network isolation, terminal fixes, and port binding.
    """
    isolation = DETECTOR.can_isolate
    
    if isolation == "proot":
        # PRoot command with ALL FIXES applied
        proot_cmd = [
            "proot",
            # Root filesystem
            "-r", str(root),
            # Fake root (allows package installation)
            "-0",
            # Mount essential filesystems
            "-b", "/dev:/dev",
            "-b", "/proc:/proc",
            "-b", "/sys:/sys",
            # Network mounts (ENABLES OUTBOUND INTERNET)
            "-b", "/etc/resolv.conf:/etc/resolv.conf",
            "-b", "/etc/hosts:/etc/hosts",
            # v3.0: Hide sensitive process info (security)
            "-b", "/dev/null:/proc/1/cmdline",
            "-b", "/dev/null:/proc/1/environ",
            "-b", "/dev/null:/proc/1/maps",
            # v3.0: Fix terminal issues - suppress ptrace warnings
            "-w", "/root",
            # Working directory
        ]
        
        # Add port binding restrictions if ports allocated
        if session_ports:
            # Note: PRoot doesn't natively support port restriction,
            # but we track it for documentation and future iptables rules
            proot_cmd.extend([
                "-e", f"DARKSSH_PORTS={','.join(map(str, session_ports[:3]))}",
            ])
        
        # Add the shell command
        proot_cmd.extend([
            "/bin/sh", "-lc", cmd
        ])
        
        return proot_cmd
    
    elif isolation == "docker":
        # Docker-based isolation with network settings
        docker_cmd = [
            "docker", "run", "--rm",
            "-v", f"{root}:/workspace:rw",
            # Network: Allow outbound but restrict inbound
            "--network", "bridge",  # Isolated network namespace
            # Security options
            "--security-opt", "no-new-privileges",
            "--read-only",  # Read-only root filesystem
            "--tmpfs", "/tmp",
            "--tmpfs", "/run",
            # Port mapping (if specified)
            "-w", "/root",
            "ubuntu:24.04",
            "sh", "-c", cmd
        ]
        
        if session_ports:
            # Map only the allocated ports
            for port in session_ports[:3]:
                docker_cmd.extend(["-p", f"{port}:{port}"])
        
        return docker_cmd
    
    elif isolation == "chroot":
        # Basic chroot (requires root)
        return [
            "chroot", str(root),
            "/bin/sh", "-c", cmd
        ]
    
    else:
        # No isolation - run directly (least secure but works everywhere)
        log_debug("Running without isolation (reduced security)")
        env = os.environ.copy()
        if session_ports:
            env["DARKSSH_PORTS"] = ",".join(map(str, session_ports[:3]))
        return ["/bin/sh", "-c", cmd]


# ============================================================================
# WORKSPACE CLONING - WITH SESSION-SPECIFIC CONFIG
# ============================================================================

def clone(dst, session_id=None, ports=None):
    """Clone base image to create new workspace with session-specific config"""
    tmp = dst.with_name(dst.name + ".new")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    
    # Use tar for efficient copying
    a = subprocess.Popen(
        ["tar", "-C", str(BASE), "-cf", "-", "."],
        stdout=subprocess.PIPE
    )
    b = subprocess.Popen(
        ["tar", "-C", str(tmp), "-xf", "-"],
        stdin=a.stdout
    )
    a.stdout.close()
    
    if b.wait() != 0 or a.wait() != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Workspace clone failed")
    
    os.replace(tmp, dst)
    
    # Apply workspace-specific hardening and config
    apply_workspace_hardening(dst, session_id, ports)


def apply_workspace_hardening(dst, session_id=None, ports=None):
    """
    Apply additional hardening to individual workspaces.
    v3.0: Adds session-specific network config and port info.
    """
    # Remove any remaining dangerous system tools
    tools_to_remove = [
        "usr/bin/sudo", "usr/sbin/visudo",
        "usr/bin/strace", "usr/bin/ltrace", 
        "usr/bin/gdb",
    ]
    
    for tool in tools_to_remove:
        tool_path = dst / tool
        if tool_path.exists():
            try:
                tool_path.unlink()
            except Exception:
                pass
    
    # Create fake stubs for removed tools
    stub_dir = dst / "usr/local/bin"
    stub_dir.mkdir(parents=True, exist_ok=True)
    
    for stub_name in ["sudo", "strace", "ltrace", "gdb", "tcpdump"]:
        stub_path = stub_dir / stub_name
        try:
            stub_path.write_text(
                '#!/bin/sh\n'
                'echo "[SECURITY] ' + stub_name + ' is disabled in this sandbox" >&2\n'
                'exit 126\n'
            )
            stub_path.chmod(0o755)
        except Exception:
            pass
    
    # Create session info file
    if session_id:
        session_info = {
            "session_id": session_id,
            "ports": ports or [],
            "network_enabled": NETWORK_CONFIG["enable_outbound"],
            "port_access_allowed": NETWORK_CONFIG["allow_port_access"],
            "created_at": time.time(),
        }
        try:
            (dst / ".darkssh_session.json").write_text(json.dumps(session_info, indent=2))
        except Exception:
            pass
    
    # Create MOTD with session info
    motd = (
        "╔═══════════════════════════════════════════════════════════╗\n"
        "║               DARKSSH v3.0 - Secure Workspace              ║\n"
        "╠═══════════════════════════════════════════════════════════╣\n"
    )
    if session_id:
        motd += f"║  Session ID: {session_id:<44} ║\n"
    if ports:
        motd += f"║  Your Ports: {', '.join(map(str, ports[:3])):<43} ║\n"
    motd += (
        "║  Network:   OUTBOUND ENABLED ✅                             ║\n"
        "║  Security:  ISOLATED (no system access)                     ║\n"
        "╚═══════════════════════════════════════════════════════════╝\n"
        "\n"
        "⚠️  IMPORTANT NOTES:\n"
        "   • You have FULL outbound internet access\n"
        "   • Your ports are PRIVATE (other users cannot access them)\n"
        "   • System tools are restricted for security\n"
        "   • All activity is logged\n"
        "\n"
    )
    
    try:
        (dst / "etc/motd").write_text(motd)
    except Exception:
        pass


# ============================================================================
# SESSION MANAGEMENT - WITH NETWORK ISOLATION
# ============================================================================

def set_progress(sid, percent, stage, message=""):
    """Update session progress"""
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r.update(
                progress=max(0, min(100, int(percent))),
                stage=stage,
                message=message,
                last_activity=time.time()
            )
            save()


def create_request(name):
    """Create a new session request with network isolation"""
    with LOCK:
        active = sum(
            r["status"] in ("queued", "starting", "running")
            for r in STATE["sessions"].values()
        )
        if active >= int(CFGDATA.get("max_sessions", 25)):
            raise RuntimeError("Maximum sessions reached")
        
        sid = secrets.token_hex(8)
        
        # Allocate private ports for this session
        ports = allocate_ports(sid)
        
        rec = {
            "id": sid,
            "name": (name or "workspace-" + sid[:6])[:80],
            "status": "queued",
            "progress": 1,
            "stage": "queued",
            "message": "Queued for a workspace worker",
            "sshx_url": None,
            "created_at": time.time(),
            "last_activity": time.time(),
            "ended_at": None,
            "error": None,
            # v3.0: Network isolation info
            "ports": ports,
            "network_enabled": NETWORK_CONFIG["enable_outbound"],
        }
        STATE["sessions"][sid] = rec
        READY_EVENTS[sid] = threading.Event()
        save()
    
    CREATE_POOL.submit(build_session, sid)
    return rec.copy()


def build_session(sid):
    """Build and start a session with full network isolation"""
    session_ports = None
    try:
        set_progress(sid, 5, "preparing", "Checking environment and dependencies")
        
        # Get allocated ports for this session
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                session_ports = r.get("ports", [])
        
        isolation = DETECTOR.can_isolate
        
        # Handle different isolation methods
        if isolation == "proot":
            # PRoot mode: Need PRoot + Ubuntu base
            if not ensure_proot():
                raise RuntimeError("PRoot unavailable and cannot be installed")
            
            ensure_base()
            set_progress(sid, 15, "base-ready", "Using shared cached base image")
            
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return
                r.update(status="starting", stage="workspace")
                save()
            
            # Create workspace from base image
            root = SESSIONS / sid / "rootfs"
            root.parent.mkdir(parents=True, exist_ok=True)
            
            set_progress(sid, 25, "copying", "Creating isolated workspace from base")
            clone(root, sid, session_ports)
            set_progress(sid, 50, "bootstrap", "Workspace ready with network access")
            
            # Start SSHX in PRoot with all fixes
            set_progress(sid, 65, "starting", "Launching SSHX process (v3.0)")
            
            # v3.0: Enhanced SSHX startup with terminal fixes
            port_info = ",".join(map(str, session_ports[:3])) if session_ports else "default"
            cmd = f"""set -e
# DARKSSH v3.0 - Enhanced SSHX Startup
# ======================================

# Environment setup
export HOME=/root
export USER=root
export LOGNAME=root
export HOSTNAME="darkssh-{sid}"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# v3.0 FIX: Terminal settings to prevent tput/ptrace errors
export TERM=dump
export TERMINFO=/usr/share/terminfo 2>/dev/null || true

# Network configuration
export NETWORK_ENABLED=1
export DARKSSH_SESSION="{sid}"
export DARKSSH_PORTS="{port_info}"

# Display MOTD
if [ -f /etc/motd ]; then
    cat /etc/motd
fi

echo ""
echo "🌐 Network: OUTBOUND INTERNET ENABLED"
echo "🔒 Your ports are private and isolated"
echo ""

# SSHX v0.4+ uses 'sshx' directly
if [ -x /tmp/sshx ]; then
    echo "Starting SSHX (local binary)..."
    exec /tmp/sshx --quiet
elif command -v sshx >/dev/null 2>&1; then
    echo "Starting SSHX..."
    exec sshx --quiet
elif [ -x /usr/local/bin/sshx ]; then
    echo "Starting SSHX (system)..."
    exec /usr/local/bin/sshx --quiet
elif command -v curl >/dev/null 2>&1; then
    echo "Installing SSHX via curl..."
    curl -sSfL https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
elif command -v wget >/dev/null 2>&1; then
    echo "Installing SSHX via wget..."
    wget -qO- https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
else
    echo "ERROR: Cannot install SSHX - no curl/wget available"
    exit 1
fi"""
            
            p = subprocess.Popen(
                pcmd(root, cmd, session_ports),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                # v3.0: Suppress PRoot warnings in stderr
            )
            
        elif isolation == "docker":
            # Docker mode
            raise RuntimeError("Docker mode not yet fully implemented - use PRoot or direct mode")
            
        else:
            # Direct/None mode: Run SSHX directly in current environment
            log(f"Session {sid}: Using direct mode (no isolation)")
            
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return
                r.update(status="starting", stage="workspace")
                save()
            
            # Create a simple workspace directory
            root = SESSIONS / sid / "workspace"
            root.mkdir(parents=True, exist_ok=True)
            
            set_progress(sid, 25, "preparing", "Preparing direct workspace")
            set_progress(sid, 50, "ready", "Workspace ready (direct mode)")
            set_progress(sid, 65, "starting", "Launching SSHX process")
            
            # SSHX startup command for direct mode
            port_info = ",".join(map(str, session_ports[:3])) if session_ports else "default"
            cmd = f"""set -e
export HOME="{os.path.expanduser('~')}"
export USER="{os.environ.get('USER', 'user')}"
export LOGNAME="{os.environ.get('USER', 'user')}"
export HOSTNAME="darkssh-direct"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
export TERM="${{TERM:-dumb}}"
export WORKSPACE="{root}"
export DARKSSH_SESSION="{sid}"
export DARKSSH_PORTS="{port_info}"
export NETWORK_ENABLED=1

mkdir -p "$WORKSPACE" 2>/dev/null || true
cd "$WORKSPACE" || cd /tmp

echo "============================================="
echo " DARKSSH v3.0 Direct Workspace"
echo " Session: {sid}"
echo " Network: OUTBOUND ENABLED"
echo " Started: $(date)"
echo "============================================="
echo ""

# Check if sshx exists locally
if [ -x /tmp/sshx ]; then
    exec /tmp/sshx --quiet
elif command -v sshx >/dev/null 2>&1; then
    exec sshx --quiet
elif command -v curl >/dev/null 2>&1; then
    curl -sSfL https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
elif command -v wget >/dev/null 2>&1; then
    wget -qO- https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
else
    echo "ERROR: Cannot install SSHX"
    exit 1
fi"""
            
            # Run directly without isolation
            p = subprocess.Popen(
                ["/bin/sh", "-c", cmd],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                cwd=str(root)
            )
        
        with LOCK:
            PROCS[sid] = p
            STATE["sessions"][sid]["pid"] = p.pid
            save()
        
        set_progress(sid, 75, "sshx", "SSHX running, waiting for access URL")
        
        # Watch for SSHX URL
        threading.Thread(target=watch, args=(sid, p), daemon=True).start()
        
    except Exception as e:
        log(f"Session {sid} FAILED: {e}")
        # Release ports on failure
        if session_ports:
            release_ports(session_ports)
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                r.update(
                    status="error",
                    progress=100,
                    stage="error",
                    message="Creation failed",
                    error=str(e),
                    ended_at=time.time()
                )
                save()
        PROCS.pop(sid, None)


def watch(sid, p):
    """Watch SSHX process output for URL with improved filtering"""
    rc = 1
    try:
        for line in p.stdout:
            line = line.strip()
            if line:
                # v3.0: Filter out PRoot warnings to reduce noise
                if "proot warning" in line.lower() or "ptrace" in line.lower():
                    log_debug(f"{sid}: [PROOT] {line}")
                elif "tput error" in line.lower():
                    log_debug(f"{sid}: [TERM] {line}")
                else:
                    log(f"{sid}: {line}")
            
            m = URLRE.search(line)
            if m:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    url = m.group(0).rstrip(".,);]")
                    if r:
                        r.update(
                            status="running",
                            progress=100,
                            stage="ready",
                            message="SSHX session ready - Network enabled",
                            sshx_url=url,
                            last_activity=time.time()
                        )
                        save()
                
                ev = READY_EVENTS.get(sid)
                if ev:
                    ev.set()
        
        rc = p.wait()
        
    except Exception as e:
        log(f"{sid} watch error: {e}")
    finally:
        # Release ports when session ends
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and "ports" in r:
                release_ports(r["ports"])
                log_debug(f"Released ports for session {sid}")
            
            if r and r["status"] != "deleted":
                r["status"] = "stopped" if rc == 0 else "error"
                r["ended_at"] = time.time()
                if rc and not r["error"]:
                    r["error"] = f"SSHX exited with code {rc}"
                save()
            
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
            PROCS.pop(sid, None)


def delete(sid):
    """Delete a session and release its resources"""
    with LOCK:
        r = STATE["sessions"].get(sid)
        if not r:
            return False
        
        # Release ports
        if "ports" in r and r["ports"]:
            release_ports(r["ports"])
            log(f"Released ports for session {sid}")
        
        p = PROCS.get(sid)
        if p and p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGTERM)
                p.wait(5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        
        shutil.rmtree(SESSIONS / sid, ignore_errors=True)
        r["status"] = "deleted"
        r["ended_at"] = time.time()
        save()
        
        ev = READY_EVENTS.get(sid)
        if ev:
            ev.set()
        PROCS.pop(sid, None)
        return True


def public(r):
    """Return safe public data for a session (never expose internals)"""
    return {
        k: r.get(k) 
        for k in (
            "id", "name", "status", "progress", "stage", 
            "message", "sshx_url", "created_at", 
            "last_activity", "ended_at", "error",
            "network_enabled",  # v3.0: Show network status
        )
    }


# ============================================================================
# JANITOR (Cleanup idle sessions)
# ============================================================================

def janitor():
    """Background thread to clean up idle sessions"""
    while True:
        time.sleep(15)
        now = time.time()
        limit = max(60, int(CFGDATA["idle_minutes"]) * 60)
        
        with LOCK:
            ids = [
                sid for sid, r in STATE["sessions"].items()
                if r["status"] in ("queued", "starting", "running")
                and now - r.get("last_activity", now) >= limit
            ]
        
        for sid in ids:
            log(f"Idle timeout: {sid}")
            delete(sid)


# Start janitor thread
threading.Thread(target=janitor, daemon=True).start()


# ============================================================================
# HTTP API SERVER - v3.0 ENHANCED
# ============================================================================

class H(BaseHTTPRequestHandler):
    """HTTP request handler with API authentication and CORS support"""
    
    def log_message(self, *a):
        pass  # Suppress default logging
    
    # v3.0: Add CORS headers
    def send_cors_headers(self):
        """Send CORS headers for browser access"""
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
    
    def do_OPTIONS(self):
        """Handle preflight requests"""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def send_json(self, code, obj):
        """Send JSON response with CORS"""
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_cors_headers()
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    
    def read_body(self):
        """Read request body"""
        length = int(self.headers.get("Content-Length", "0"))
        if length > 65536:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(length) or b"{}")
    
    def do_GET(self):
        """Handle GET requests"""
        path = urlparse(self.path).path
        
        # Static files - no auth required
        if path in ("/", "/index.html"):
            try:
                html = (APP / "static/index.html").read_bytes()
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html)))
                self.end_headers()
                self.wfile.write(html)
            except Exception as e:
                self.send_json(500, {"error": str(e)})
            return
        
        # Health check - no auth required (enhanced for v3.0)
        if path == "/api/health":
            return self.send_json(200, {
                "ok": True,
                "port": CFGDATA["port"],
                "version": "3.0.0",  # v3.0
                "universal": UNIVERSAL_MODE,
                "system": DETECTOR.get_info_dict(),
                "auth": "enabled" if API_KEY else "disabled",
                # v3.0: Network info
                "network": {
                    "outbound_enabled": NETWORK_CONFIG["enable_outbound"],
                    "port_isolation": True,
                    "base_port": NETWORK_CONFIG["base_port"],
                    "ports_per_session": NETWORK_CONFIG["ports_per_session"],
                },
                "active_sessions": sum(
                    1 for r in STATE["sessions"].values()
                    if r["status"] in ("queued", "starting", "running")
                ),
            })
        
        # All other endpoints require auth
        if not check_auth(self.headers):
            return self.send_json(401, {"error": "Unauthorized — API key required"})
        
        if path == "/api/sessions":
            with LOCK:
                sessions = [public(r) for r in STATE["sessions"].values()]
            return self.send_json(200, {"sessions": sessions})
        
        if path.startswith("/api/sessions/"):
            sid = path.rsplit("/", 1)[-1]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.send_json(404, {"error": "Session not found"})
                return self.send_json(200, public(r))
        
        self.send_error(404)
    
    def do_POST(self):
        """Handle POST requests"""
        path = urlparse(self.path).path
        
        # Auth check
        if not check_auth(self.headers):
            return self.send_json(401, {"error": "Unauthorized — API key required"})
        
        if path == "/api/sessions":
            try:
                data = self.read_body()
            except Exception as e:
                return self.send_json(400, {"error": str(e)})
            
            try:
                rec = create_request(str(data.get("name", "")))
                
                # Default: wait for SSHX URL (synchronous)
                query = urlparse(self.path).query.lower()
                wait = query not in ("wait=false", "async=1")
                
                if not wait:
                    return self.send_json(202, {
                        "ok": True,
                        "ready": False,
                        "session": public(rec)
                    })
                
                # Wait for session to be ready
                ev = READY_EVENTS[rec["id"]]
                if not ev.wait(240):  # 4 minute timeout
                    return self.send_json(504, {
                        "ok": False,
                        "ready": False,
                        "error": "Timed out waiting for SSHX URL",
                        "session": public(STATE["sessions"].get(rec["id"], rec))
                    })
                
                with LOCK:
                    final = STATE["sessions"].get(rec["id"])
                
                if not final:
                    return self.send_json(404, {
                        "ok": False,
                        "error": "Session disappeared"
                    })
                
                if final.get("sshx_url"):
                    return self.send_json(200, {
                        "ok": True,
                        "ready": True,
                        "session": public(final)
                    })
                
                return self.send_json(502, {
                    "ok": False,
                    "ready": False,
                    "error": final.get("error") or "SSHX exited before producing URL",
                    "session": public(final)
                })
                
            except Exception as e:
                log(f"Create session error: {e}")
                return self.send_json(500, {"error": str(e)})
        
        # Heartbeat endpoint
        if path.startswith("/api/sessions/") and path.endswith("/heartbeat"):
            sid = path.split("/")[-2]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.send_json(404, {"error": "Session not found"})
                r["last_activity"] = time.time()
                save()
            return self.send_json(200, {"ok": True})
        
        self.send_error(404)
    
    def do_DELETE(self):
        """Handle DELETE requests"""
        path = urlparse(self.path).path
        
        # Auth check
        if not check_auth(self.headers):
            return self.send_json(401, {"error": "Unauthorized — API key required"})
        
        if path.startswith("/api/sessions/"):
            sid = path.rsplit("/", 1)[-1]
            ok = delete(sid)
            return self.send_json(200 if ok else 404, {"ok": ok})
        
        self.send_error(404)


def check_auth(headers):
    """Check API key authentication"""
    if not API_KEY:
        return True  # No key configured = open (not recommended)
    
    auth = headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        return secrets.compare_digest(token, API_KEY)
    return False


# ============================================================================
# CLEANUP ON EXIT
# ============================================================================

def cleanup():
    """Clean up all sessions on exit"""
    log("Shutting down - cleaning up sessions...")
    with LOCK:
        for sid in list(PROCS.keys()):
            try:
                delete(sid)
            except Exception:
                pass


atexit.register(cleanup)


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    # Print awesome banner
    banner = """
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║     ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗ ██████╗ ███████╗        ║
║     ██╔══██╗██║   ██║██╔══██╗████╗  ██║██╔════╝ ██╔════╝        ║
║     ██████╔╝██║   ██║███████║██╔██╗ ██║██║  ███╗█████╗          ║
║     ██╔══██╗██║   ██║██╔══██║██║╚██╗██║██║   ██║██╔══╝          ║
║     ██████╔╝╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝███████╗        ║
║     ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝        ║
║                                                                   ║
║                    ★ v3.0 MASTERPIECE ★                          ║
║         Network Isolation • Port Security • Full Internet        ║
╚═══════════════════════════════════════════════════════════════════╝
"""
    print(banner)
    
    # Log startup info
    if API_KEY:
        log("API key authentication ENABLED")
    else:
        log("WARNING: API key authentication DISABLED — anyone can access the API")
    
    # Log system info
    sys_info = DETECTOR.get_info_dict()
    log(f"System: {sys_info['os_name']} ({sys_info['architecture']})")
    log(f"Isolation: {sys_info['isolation_method']}")
    log(f"Universal Mode: {'Yes' if UNIVERSAL_MODE else 'No'}")
    log(f"Network: {'OUTBOUND ENABLED' if NETWORK_CONFIG['enable_outbound'] else 'DISABLED'}")
    log(f"Port Isolation: Yes (base port: {NETWORK_CONFIG['base_port']})")
    
    # Check if system is supported
    supported, message = DETECTOR.is_supported()
    if not supported:
        log(f"FATAL: {message}")
        sys.exit(1)
    elif "warning" in message.lower() or "reduced" in message.lower():
        log(f"WARNING: {message}")
    
    log(f"Listening on {CFGDATA['host']}:{CFGDATA['port']}")
    log("")
    log("★ DARKSSH v3.0 Masterpiece is ready! ★")
    log("")
    
    # Start server
    try:
        server = ThreadingHTTPServer(
            (CFGDATA["host"], int(CFGDATA["port"])),
            H
        )
        server.serve_forever()
    except KeyboardInterrupt:
        log("Server shutting down...")
        cleanup()
        sys.exit(0)
    except Exception as e:
        log(f"Server error: {e}")
        sys.exit(1)
