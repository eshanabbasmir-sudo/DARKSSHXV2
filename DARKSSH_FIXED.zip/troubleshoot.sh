#!/usr/bin/env bash
set -u
APP="$(cd "$(dirname "$0")" && pwd)"
cd "$APP" || exit 1
printf '\n[DARKSSH] Automatic diagnostic\n'
printf 'Directory: %s\n' "$APP"
printf 'OS: '; . /etc/os-release 2>/dev/null && printf '%s %s\n' "${PRETTY_NAME:-unknown}" "${VERSION_ID:-}" || printf 'unknown\n'
printf 'Kernel: '; uname -a
printf 'Arch: '; uname -m
printf 'Python: '; python3 --version 2>&1 || true
printf 'PRoot: '; proot --version 2>&1 || "$APP/bin/proot" --version 2>&1 || true
printf 'unshare: '; unshare --version 2>&1 || true
printf 'slirp4netns: '; slirp4netns --version 2>&1 || true
printf '\nBase directories:\n'; ls -ld data data/ubuntu-base data/ubuntu-base.new 2>/dev/null || true
printf '\nSSHX in base:\n'; proot -0 -r data/ubuntu-base -w / /usr/local/bin/sshx --version 2>&1 || true
printf '\nHealth check (if server is running):\n'; curl -fsS "http://127.0.0.1:${DARKSSH_PORT:-5000}/api/health" 2>/dev/null || true
