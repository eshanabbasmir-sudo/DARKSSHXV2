#!/usr/bin/env bash
# ============================================================================
# DARKSSH Universal Setup Script v2.0
# ============================================================================
# Works on: Linux (all distros), macOS, Windows (WSL/Git Bash),
#           Containers, VPS, VDS, Dedicated Servers, Cloud VMs
#
# Features:
# - Auto OS/Distro Detection
# - Auto Package Manager Detection  
# - Non-interactive mode (for automation)
# - System requirement checks
# - Graceful error handling
# - Cross-platform compatibility
# ============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# ============================================================================
# GLOBAL VARIABLES
# ============================================================================
APP="$(cd "$(dirname "$0")" && pwd)"
CONFIG_FILE="$APP/config.json"
NON_INTERACTIVE=false
FORCE_INSTALL=false
VERBOSE=false

# Default values
DEFAULT_PORT=4545
DEFAULT_IDLE=15
DEFAULT_MAX_SESSIONS=25

# Detected values
DETECTED_OS=""
DETECTED_DISTRO=""
DETECTED_PACKAGE_MANAGER=""
DETECTED_ARCH=""

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_debug() {
    if [ "$VERBOSE" = true ]; then
        echo -e "${CYAN}[DEBUG]${NC} $1"
    fi
}

show_banner() {
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║                                                      ║"
    echo "║   ${BOLD}DARKSSH — Universal Setup v2.0${NC}                  "
    echo "║                                                      ║"
    echo "║   ${GREEN}Cross-Platform Hardened SSHX Workspace${NC}          "
    echo "║                                                      ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -p, --port PORT         Set server port (default: $DEFAULT_PORT)"
    echo "  -i, --idle MINUTES      Set idle timeout in minutes (default: $DEFAULT_IDLE)"
    echo "  -n, --non-interactive   Run non-interactively (use defaults or env vars)"
    echo "  -f, --force             Force installation even if checks fail"
    echo "  -v, --verbose           Enable verbose output"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Environment Variables (for non-interactive mode):"
    echo "  DARKSSH_PORT            Server port"
    echo "  DARKSSH_IDLE_TIMEOUT    Idle timeout in minutes"
    echo "  DARKSSH_API_KEY         Pre-generated API key (optional)"
    echo "  DARKSSH_MAX_SESSIONS    Maximum concurrent sessions"
    echo ""
    echo "Examples:"
    echo "  $0                                    # Interactive setup"
    echo "  $0 -p 8080 -i 30                      # Custom port and timeout"
    echo "  $0 --non-interactive                  # Fully automatic"
    echo "  DARKSSH_PORT=9090 $0 -n               # Using environment variable"
}

# ============================================================================
# OS DETECTION FUNCTIONS
# ============================================================================

detect_os() {
    log_info "Detecting operating system..."
    
    # Detect broad OS type
    case "$(uname -s)" in
        Linux*)     DETECTED_OS="linux" ;;
        Darwin*)    DETECTED_OS="macos" ;;
        CYGWIN*|MINGW*|MSYS*) DETECTED_OS="windows" ;;
        FreeBSD*|OpenBSD*|NetBSD*) DETECTED_OS="bsd" ;;
        *)          DETECTED_OS="unknown" ;;
    esac
    
    # Detect specific distribution (Linux only)
    if [ "$DETECTED_OS" = "linux" ]; then
        detect_linux_distro
    fi
    
    # Detect architecture
    DETECTED_ARCH="$(uname -m)"
    
    # Detect package manager
    detect_package_manager
    
    log_success "OS Detected: $DETECTED_DISTRO ($DETECTED_ARCH)"
    log_debug "Package Manager: $DETECTED_PACKAGE_MANAGER"
    log_debug "OS Type: $DETECTED_OS"
}

detect_linux_distro() {
    # Try /etc/os-release first (most reliable)
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DETECTED_DISTRO="${ID:-unknown-linux}"
        
        # Normalize distro names
        case "$DETECTED_DISTRO" in
            ubuntu|debian) DETECTED_DISTRO="$ID" ;;
            centos|rhel|fedora|rocky|alma) 
                if [ "$DETECTED_DISTRO" = "centos" ] || [ "$DETECTED_DISTRO" = "rhel" ]; then
                    DETECTED_DISTRO="centos"
                elif [ "$DETECTED_DISTRO" = "fedora" ]; then
                    DETECTED_DISTRO="fedora"
                else
                    DETECTED_DISTRO="centos"
                fi
                ;;
            alpine) DETECTED_DISTRO="alpine" ;;
            arch|manjaro) DETECTED_DISTRO="arch" ;;
            opensuse|suse) DETECTED_DISTRO="opensuse" ;;
            amzn|amazon-linux) DETECTED_DISTRO="amazon-linux" ;;
            *) DETECTED_DISTRO="${ID:-unknown-linux}" ;;
        esac
        return
    fi
    
    # Fallback: Check for distribution-specific files
    if [ -f /etc/debian_version ]; then
        DETECTED_DISTRO="debian"
    elif [ -f /etc/redhat-release ]; then
        DETECTED_DISTRO="centos"
    elif [ -f /etc/alpine-release ]; then
        DETECTED_DISTRO="alpine"
    elif [ -f /etc/arch-release ]; then
        DETECTED_DISTRO="arch"
    elif [ -f /etc/gentoo-release ]; then
        DETECTED_DISTRO="gentoo"
    else
        DETECTED_DISTRO="unknown-linux"
    fi
}

detect_package_manager() {
    # Check for package managers in order of preference
    if command -v apt-get >/dev/null 2>&1 || command -v apt >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="apt"
    elif command -v dnf >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="dnf"
    elif command -v yum >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="yum"
    elif command -v apk >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="apk"
    elif command -v pacman >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="pacman"
    elif command -v zypper >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="zypper"
    elif command -v brew >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="brew"
    elif command -v choco >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="choco"
    elif command -v pkg >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="pkg"  # BSD
    elif command -v opkg >/dev/null 2>&1; then
        DETECTED_PACKAGE_MANAGER="opkg"  # OpenWrt
    else
        DETECTED_PACKAGE_MANAGER="unknown"
    fi
}

# ============================================================================
# SYSTEM CHECK FUNCTIONS
# ============================================================================

check_requirements() {
    log_info "Checking system requirements..."
    
    local errors=0
    local warnings=0
    
    # Check Python 3
    if command -v python3 >/dev/null 2>&1; then
        local py_version=$(python3 --version 2>&1 | awk '{print $2}')
        local py_major=$(echo "$py_version" | cut -d. -f1)
        local py_minor=$(echo "$py_version" | cut -d. -f2)
        
        if [ "$py_major" -ge 3 ] && [ "$py_minor" -ge 7 ]; then
            log_success "Python: $py_version ✓"
        elif [ "$py_major" -ge 3 ] && [ "$py_minor" -ge 6 ]; then
            log_warning "Python: $py_version (3.7+ recommended) ⚠"
            ((warnings++)) || true
        else
            log_error "Python: $py_version (need 3.6+) ✗"
            ((errors++)) || true
        fi
    else
        log_error "Python 3 not found ✗"
        ((errors++)) || true
    fi
    
    # Check disk space (need at least 500MB free)
    local free_disk
    if [ "$DETECTED_OS" = "macos" ]; then
        free_disk=$(df -k . | tail -1 | awk '{print int($4/1024)}')
    else
        free_disk=$(df -B1 . | tail -1 | awk '{print int($4/1048576)}')
    fi
    
    if [ "$free_disk" -ge 500 ] 2>/dev/null; then
        log_success "Disk Space: ${free_disk}MB free ✓"
    elif [ "$free_disk" -ge 200 ] 2>/dev/null; then
        log_warning "Disk Space: ${free_disk}MB (500MB recommended) ⚠"
        ((warnings++)) || true
    else
        log_error "Disk Space: Only ${free_disk}MB free (need 200MB minimum) ✗"
        ((errors++)) || true
    fi
    
    # Check memory
    local total_mem
    if [ "$DETECTED_OS" = "linux" ] && [ -f /proc/meminfo ]; then
        total_mem=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
    elif [ "$DETECTED_OS" = "macos" ]; then
        total_mem=$(sysctl hw.memsize 2>/dev/null | awk '{print int($2/1048576)}')
    else
        total_mem=0
    fi
    
    if [ "$total_mem" -ge 512 ] 2>/dev/null; then
        log_success "Memory: ${total_mem}MB total ✓"
    elif [ "$total_mem" -gt 0 ] 2>/dev/null; then
        log_warning "Memory: ${total_mem}MB (512MB recommended) ⚠"
        ((warnings++)) || true
    else
        log_info "Memory: Unable to determine (continuing...) •"
    fi
    
    # Check if running as root (or can use sudo)
    if [ "$(id -u)" -eq 0 ]; then
        log_success "Permissions: Running as root ✓"
    elif command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
        log_success "Permissions: Has sudo access ✓"
    else
        log_warning "Permissions: Limited (some features may not work) ⚠"
        ((warnings++)) || true
    fi
    
    # Check network connectivity
    if curl -s --connect-timeout 5 https://shulker.in >/dev/null 2>&1 || \
       wget -q --timeout=5 https://shulker.in -O /dev/null 2>&1; then
        log_success "Network: Connected ✓"
    else
        log_warning "Network: Cannot reach external servers ⚠"
        ((warnings++)) || true
    fi
    
    # Platform-specific checks
    if [ "$DETECTED_OS" = "linux" ]; then
        check_linux_specific
    elif [ "$DETECTED_OS" = "macos" ]; then
        check_macos_specific
    elif [ "$DETECTED_OS" = "windows" ]; then
        check_windows_specific
    fi
    
    echo ""
    if [ "$errors" -gt 0 ]; then
        if [ "$FORCE_INSTALL" = true ]; then
            log_warning "Found $errors error(s) and $warnings warning(s) (forcing install)..."
            return 0
        else
            log_error "Found $errors error(s) and $warnings warning(s). Use --force to override."
            return 1
        fi
    else
        if [ "$warnings" -gt 0 ]; then
            log_warning "System check passed with $warnings warning(s)..."
        else
            log_success "All system checks passed! ✓"
        fi
        return 0
    fi
}

check_linux_specific() {
    # Check for PRoot or ability to install it
    if command -v proot >/dev/null 2>&1; then
        log_success "PRoot: Already installed ✓"
    elif [ "$DETECTED_PACKAGE_MANAGER" != "unknown" ]; then
        log_info "PRoot: Will auto-install via $DETECTED_PACKAGE_MANAGER •"
    else
        log_warning "PRoot: Cannot auto-install (no package manager) ⚠"
    fi
    
    # Check architecture support
    case "$DETECTED_ARCH" in
        x86_64|amd64)
            log_success "Architecture: x86_64 (fully supported) ✓" ;;
        aarch64|arm64)
            log_success "Architecture: ARM64 (fully supported) ✓" ;;
        armv7l|armhf)
            log_success "Architecture: ARMv7 (supported) ✓" ;;
        ppc64le)
            log_success "Architecture: POWER64 (supported) ✓" ;;
        riscv64)
            log_success "Architecture: RISC-V (experimental) ✓" ;;
        s390x)
            log_success "Architecture: s390x (supported) ✓" ;;
        *)
            log_warning "Architecture: $DETECTED_ARCH (may not be supported) ⚠" ;;
    esac
}

check_macos_specific() {
    log_info "Platform: macOS (using alternative to PRoot) •"
    
    # Check if Homebrew is available
    if command -v brew >/dev/null 2>&1; then
        log_success "Homebrew: Available ✓"
    else
        log_info "Homebrew: Not installed (not required) •"
    fi
}

check_windows_specific() {
    log_info "Platform: Windows (WSL/Git Bash detected) •"
    
    # Check if WSL
    if uname -r | grep -qi microsoft; then
        log_success "Environment: WSL (good compatibility) ✓"
    else
        log_warning "Environment: Native Windows (limited support) ⚠"
    fi
}

# ============================================================================
# PACKAGE INSTALLATION FUNCTIONS
# ============================================================================

install_dependencies() {
    log_info "Installing required dependencies..."
    
    case "$DETECTED_PACKAGE_MANAGER" in
        apt)
            install_apt_packages
            ;;
        dnf|yum)
            install_rpm_packages
            ;;
        apk)
            install_alpine_packages
            ;;
        pacman)
            install_arch_packages
            ;;
        zypper)
            install_suse_packages
            ;;
        brew)
            install_brew_packages
            ;;
        *)
            log_warning "Unknown package manager. Please install manually:"
            echo "  - Python 3.6+"
            echo "  - curl or wget"
            echo "  - tar"
            echo "  - PRoot (Linux only)"
            ;;
    esac
    
    # Ensure pip is available
    ensure_pip
    
    # Install Python dependencies
    install_python_packages
    
    log_success "Dependencies installation complete!"
}

install_apt_packages() {
    log_info "Using APT to install packages..."
    
    local packages="curl wget tar python3 python3-pip"
    
    # Add proot for Linux (except some restricted environments)
    if [ "$DETECTED_OS" = "linux" ] && [ "$(id -u)" -eq 0 ]; then
        packages="$packages proot"
    elif [ "$DETECTED_OS" = "linux" ] && sudo -n true 2>/dev/null; then
        packages="$packages proot"
    fi
    
    if [ "$(id -u)" -eq 0 ]; then
        apt-get update -qq && apt-get install -y -qq $packages
    elif command -v sudo >/dev/null 2>&1; then
        sudo apt-get update -qq && sudo apt-get install -y -qq $packages
    else
        log_warning "Cannot install system packages without root/sudo"
    fi
}

install_rpm_packages() {
    log_info "Using $DETECTED_PACKAGE_MANAGER to install packages..."
    
    local packages="curl wget tar python3 python3-pip"
    
    if [ "$DETECTED_OS" = "linux" ] && [ "$(id -u)" -eq 0 ]; then
        if [ "$DETECTED_PACKAGE_MANAGER" = "dnf" ]; then
            dnf install -y $packages
        else
            yum install -y $packages
        fi
    elif command -v sudo >/dev/null 2>&1; then
        if [ "$DETECTED_PACKAGE_MANAGER" = "dnf" ]; then
            sudo dnf install -y $packages
        else
            sudo yum install -y $packages
        fi
    else
        log_warning "Cannot install system packages without root/sudo"
    fi
}

install_alpine_packages() {
    log_info "Using APK to install packages..."
    
    local packages="curl wget tar python3 py3-pip"
    
    if [ "$(id -u)" -eq 0 ]; then
        apk add --no-cache $packages
    elif command -v sudo >/dev/null 2>&1; then
        sudo apk add --no-cache $packages
    else
        log_warning "Cannot install system packages without root/sudo"
    fi
}

install_arch_packages() {
    log_info "Using Pacman to install packages..."
    
    local packages="curl wget tar python python-pip"
    
    if [ "$(id -u)" -eq 0 ]; then
        pacman -S --noconfirm $packages
    elif command -v sudo >/dev/null 2>&1; then
        sudo pacman -S --noconfirm $packages
    else
        log_warning "Cannot install system packages without root/sudo"
    fi
}

install_suse_packages() {
    log_info "Using Zypper to install packages..."
    
    local packages="curl wget tar python3 python3-pip"
    
    if [ "$(id -u)" -eq 0 ]; then
        zypper install -y $packages
    elif command -v sudo >/dev/null 2>&1; then
        sudo zypper install -y $packages
    else
        log_warning "Cannot install system packages without root/sudo"
    fi
}

install_brew_packages() {
    log_info "Using Homebrew to install packages..."
    
    local packages="curl wget python3"
    
    brew install $packages 2>/dev/null || true
}

ensure_pip() {
    if ! python3 -m pip --version >/dev/null 2>&1; then
        log_info "Installing pip..."
        
        if [ "$(id -u)" -eq 0 ]; then
            python3 -m ensurepip --upgrade 2>/dev/null || true
        elif command -v sudo >/dev/null 2>&1; then
            sudo python3 -m ensurepip --upgrade 2>/dev/null || true
        fi
        
        # Fallback: get-pip.py
        if ! python3 -m pip --version >/dev/null 2>&1; then
            curl -sS https://bootstrap.pypa.io/get-pip.py | python3 2>/dev/null || \
            wget -qO- https://bootstrap.pypa.io/get-pip.py | python3 2>/dev/null || true
        fi
    fi
}

install_python_packages() {
    log_info "Installing Python packages..."
    
    # No additional Python packages required for basic functionality
    # The server.py uses only standard library modules
    log_success "Python dependencies satisfied (using standard library)"
}

# ============================================================================
# CONFIGURATION FUNCTIONS
# ============================================================================

get_user_input() {
    local prompt="$1"
    local default="$2"
    local var_name="$3"
    local value=""
    
    if [ "$NON_INTERACTIVE" = true ]; then
        # Check environment variable first, then use default
        eval value="\$$var_name"
        if [ -z "$value" ]; then
            value="$default"
        fi
        echo "$value"
        return
    fi
    
    # Interactive mode
    read -r -p "$prompt [$default]: " value
    value="${value:-$default}"
    echo "$value"
}

generate_config() {
    log_info "Generating configuration..."
    
    # Get port
    PORT="$(get_user_input "Website port" "$DEFAULT_PORT" "DARKSSH_PORT")"
    
    # Validate port
    case "$PORT" in
        ''|*[!0-9]*) 
            log_error "Invalid port number"
            exit 1 
            ;;
    esac
    if [ "$PORT" -lt 1 ] || [ "$PORT" -gt 65535 ]; then
        log_error "Port must be between 1 and 65535"
        exit 1
    fi
    
    # Check if port is already in use
    if command -v lsof >/dev/null 2>&1; then
        if lsof -i :"$PORT" >/dev/null 2>&1; then
            log_warning "Port $PORT is already in use!"
            if [ "$NON_INTERACTIVE" != true ]; then
                read -r -p "Choose different port? [y/N]: " change_port
                if [ "$change_port" = "y" ] || [ "$change_port" = "Y" ]; then
                    read -r -p "New port [$(($PORT + 1))]: " NEW_PORT
                    PORT="${NEW_PORT:-$((PORT + 1))}"
                fi
            fi
        fi
    fi
    
    # Get idle timeout
    IDLE="$(get_user_input "Kill session after inactivity in minutes" "$DEFAULT_IDLE" "DARKSSH_IDLE_TIMEOUT")"
    
    # Validate idle
    case "$IDLE" in
        ''|*[!0-9]*) 
            log_error "Invalid timeout value"
            exit 1 
            ;;
    esac
    if [ "$IDLE" -lt 1 ]; then
        log_error "Timeout must be at least 1 minute"
        exit 1
    fi
    
    # Get max sessions
    MAX_SESSIONS="$(get_user_input "Maximum concurrent sessions" "$DEFAULT_MAX_SESSIONS" "DARKSSH_MAX_SESSIONS")"
    
    # Generate API key (or use provided one)
    API_KEY="${DARKSSH_API_KEY:-$(head -c 32 /dev/urandom 2>/dev/null | base64 | tr -d '/+=' | head -c 40 || openssl rand -hex 20 2>/dev/null || date +%s%N | sha256sum | head -c 40)}"
    
    # Create data directories
    mkdir -p "$APP/data/sessions" "$APP/data/images"
    
    # Write config file
    cat > "$CONFIG_FILE" << EOF
{
  "host": "0.0.0.0",
  "port": $PORT,
  "idle_minutes": $IDLE,
  "max_sessions": $MAX_SESSIONS,
  "api_key": "$API_KEY",
  "detected_os": "$DETECTED_OS",
  "detected_distro": "$DETECTED_DISTRO",
  "detected_arch": "$DETECTED_ARCH",
  "package_manager": "$DETECTED_PACKAGE_MANAGER",
  "installed_at": "$(date -Iseconds 2>/dev/null || date)",
  "universal_mode": true
}
EOF
    
    log_success "Configuration saved to $CONFIG_FILE"
    
    # Display summary
    echo ""
    echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║   SETUP COMPLETE                          ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  Server port:     ${BOLD}$PORT${NC}"
    echo -e "  Idle timeout:    ${BOLD}$IDLE${NC} minutes"
    echo -e "  Max sessions:   ${BOLD}$MAX_SESSIONS${NC}"
    echo ""
    echo -e "  ${BOLD}API KEY (save this):${NC}"
    echo -e "  ${GREEN}$API_KEY${NC}"
    echo ""
    echo -e "  To configure in DARK CLOUD admin panel:"
    echo "    1. Login to /admin/login.php"
    echo "    2. Go to VM APIs → Add provider"
    echo "    3. Auth Type: Bearer Token"
    echo "    4. API URL: http://YOUR_SERVER_IP:$PORT"
    echo "    5. API Key: $API_KEY"
    echo ""
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    show_banner
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -p|--port)
                export DARKSSH_PORT="$2"
                shift 2
                ;;
            -i|--idle)
                export DARKSSH_IDLE_TIMEOUT="$2"
                shift 2
                ;;
            -n|--non-interactive)
                NON_INTERACTIVE=true
                shift
                ;;
            -f|--force)
                FORCE_INSTALL=true
                shift
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                usage
                exit 1
                ;;
        esac
    done
    
    # Step 1: Detect OS
    echo -e "\n${BOLD}[Step 1/4] Operating System Detection${NC}"
    echo "-------------------------------------------"
    detect_os
    echo ""
    
    # Step 2: Check requirements
    echo -e "${BOLD}[Step 2/4] System Requirements Check${NC}"
    echo "-------------------------------------------"
    if ! check_requirements; then
        exit 1
    fi
    echo ""
    
    # Step 3: Install dependencies
    echo -e "${BOLD}[Step 3/4] Installing Dependencies${NC}"
    echo "-------------------------------------------"
    install_dependencies
    echo ""
    
    # Step 4: Generate configuration
    echo -e "${BOLD}[Step 4/4] Configuration${NC}"
    echo "-------------------------------------------"
    generate_config
    
    # Start server
    echo -e "${CYAN}Starting DARKSSH server...${NC}"
    echo ""
    
    exec python3 "$APP/server.py"
}

# Run main function
main "$@"
