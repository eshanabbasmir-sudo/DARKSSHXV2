#!/usr/bin/env bash
# DARKSSH diagnostic — prints everything needed to debug a broken install.
set -u
APP="$(cd "$(dirname "$0")" && pwd)"
cd "$APP" || exit 1
PORT="${DARKSSH_PORT:-5000}"

line(){ printf '\n── %s ──────────────────────────────────────────\n' "$*"; }

line "Identity"
printf 'User: %s (uid=%s, gid=%s)\n' "$(whoami 2>/dev/null || echo ?)" "$(id -u)" "$(id -g)"
printf 'Sudo: '; command -v sudo >/dev/null 2>&1 && echo yes || echo no
printf 'Doas: '; command -v doas >/dev/null 2>&1 && echo yes || echo no

line "Operating system"
if [ -r /etc/os-release ]; then
  . /etc/os-release 2>/dev/null
  printf 'Name       : %s\n' "${PRETTY_NAME:-unknown}"
  printf 'ID         : %s\n' "${ID:-unknown}"
  printf 'Version    : %s\n' "${VERSION_ID:-unknown}"
else
  printf 'Unknown (no /etc/os-release)\n'
fi
printf 'Kernel     : %s\n' "$(uname -a)"

line "Architecture & CPU"
printf 'Machine: %s\n' "$(uname -m)"
printf 'CPU    : %s\n' "$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | xargs || echo ?)"

line "Memory & disk"
printf 'Memory:\n'; free -h 2>/dev/null || cat /proc/meminfo 2>/dev/null | head -5
printf '\nDisk (project dir):\n'; df -h "$APP" 2>/dev/null || true
printf '\nDisk (/tmp):\n'; df -h /tmp 2>/dev/null || true

line "Container detection"
if [ -f /.dockerenv ]; then printf '  /.dockerenv present (Docker)\n'; fi
if [ -f /run/.containerenv ]; then printf '  /run/.containerenv present (Podman)\n'; fi
if [ -r /proc/1/cgroup ]; then
  printf '  /proc/1/cgroup:\n'
  sed 's/^/    /' /proc/1/cgroup 2>/dev/null | head -10
fi

line "Package manager"
for pm in apt-get apk dnf yum pacman zypper pkg xbps-install swupd eopkg; do
  command -v "$pm" >/dev/null 2>&1 && printf '  %s: %s\n' "$pm" "$(command -v "$pm")"
done

line "Python"
command -v python3 >/dev/null 2>&1 && python3 --version 2>&1 || printf '  python3 NOT FOUND\n'
printf '  sys.executable: '
python3 -c 'import sys;print(sys.executable)' 2>/dev/null || echo ?

line "Required host tools"
for tool in curl wget tar gzip proot slirp4netns unshare sshx; do
  if command -v "$tool" >/dev/null 2>&1; then
    printf '  %-12s : %s\n' "$tool" "$(command -v "$tool")"
  else
    printf '  %-12s : MISSING\n' "$tool"
  fi
done

line "Namespace support"
printf '  unshare -Urn /bin/true: '
if command -v unshare >/dev/null 2>&1; then
  unshare -Urn -- /bin/true 2>/dev/null && echo OK || echo "FAILED (host blocks user/net namespaces)"
else
  echo "unshare not installed"
fi

line "DARKSSH project layout"
ls -la "$APP" 2>/dev/null
printf '\n'
ls -ld "$APP/data" "$APP/data/sessions" "$APP/data/images" "$APP/data/ubuntu-base" "$APP/data/ubuntu-base.new" "$APP/bin" "$APP/static" 2>/dev/null || true

line "Config file"
if [ -f "$APP/config.json" ]; then
  sed 's/"api_key": *"[^"]*"/"api_key": "<redacted>"/' "$APP/config.json"
else
  echo "  (none — will be created on first start)"
fi

line "State file"
if [ -f "$APP/data/state.json" ]; then
  python3 -c 'import json;d=json.load(open("'"$APP"'/data/state.json"));print(f"  Sessions: {len(d.get(\"sessions\",{}))}");[print(f"  - {s[\"id\"][:8]} status={s.get(\"status\")} progress={s.get(\"progress\")} isolation={s.get(\"isolation\",\"?\")}") for s in d.get("sessions",{}).values()]' 2>/dev/null || cat "$APP/data/state.json" | head -50
else
  echo "  (none — no sessions yet)"
fi

line "SSHX inside Ubuntu base"
if [ -x "$APP/data/ubuntu-base/usr/local/bin/sshx" ]; then
  proot -0 -r "$APP/data/ubuntu-base" -w / /usr/local/bin/sshx --version 2>&1 | head -5 || echo "  (proot failed)"
else
  echo "  SSHX not yet installed in base"
fi

line "Health check (if server is running)"
curl -fsS "http://127.0.0.1:${PORT}/api/health" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "  Server not responding on port ${PORT}"

line "Recent log"
if [ -f "$APP/darkssh.log" ]; then
  tail -40 "$APP/darkssh.log"
else
  echo "  (no log file — start the server with: ./start.sh 2>&1 | tee darkssh.log)"
fi

line "Done"
echo "If you need help, share the full output above with the DARKSSH maintainer."
