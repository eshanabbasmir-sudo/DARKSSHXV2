# DARKSSH — Hardened SSHX Workspace Server

Creates isolated Ubuntu workspaces using PRoot, each with its own SSHX terminal session.

## What's hardened in this version

### 1. API Key Authentication
- All `/api/` endpoints require an `Authorization: Bearer <key>` header
- The API key is auto-generated on first run (stored in `config.json`)
- Without the key, the API returns `401 Unauthorized`

### 2. PRoot Environment Hardening
Each workspace is hardened so users **cannot** see, check, or stop server ports:

**Hidden `/proc/net`:**
- `/proc/net/tcp` → bind-mounted to `/dev/null` (shows no TCP connections)
- `/proc/net/udp` → bind-mounted to `/dev/null` (shows no UDP connections)
- `/proc/net/tcp6` → bind-mounted to `/dev/null`
- `/proc/net/udp6` → bind-mounted to `/dev/null`
- `/proc/net/unix` → bind-mounted to `/dev/null`

**Hidden `/proc/1`:**
- `/proc/1/cmdline` → bind-mounted to `/dev/null` (hides the server process command)
- `/proc/1/environ` → bind-mounted to `/dev/null` (hides server env vars)

**Removed network tools:**
- `netstat`, `ss`, `lsof`, `nmap`, `tcpdump`, `iptables`, `ip6tables`, `ip` — all removed
- Replaced with fake stubs that return "command not available in sandbox"

**Restricted `/etc/hosts`:**
- Each workspace gets a minimal `/etc/hosts` with only `localhost` — no server hostnames

### 3. Session Isolation
- Each session gets its own PRoot rootfs (full filesystem copy)
- Sessions cannot see each other's processes, files, or network state
- The `public()` function only returns safe fields: `id`, `name`, `status`, `progress`, `stage`, `message`, `sshx_url`, timestamps
- NEVER exposes: IPs, ports, PIDs, internal paths, server credentials

### 4. SSHX URL Privacy
The SSHX URL (`https://sshx.io/s/XXX#YYY`) is:
- A token-based URL handled entirely by sshx.io's servers
- Does NOT expose the server's local IP
- Does NOT expose the server's listening port
- The `#fragment` part is never sent to the server (stays client-side)

## Installation

### Requirements
- Linux (Ubuntu, Debian, Alpine, Fedora/RHEL, Arch, Termux/Android Linux environments, etc.)
- Python 3.8+
- PRoot (auto-installed when the detected package manager supports it)
- Network access from the host and from the Ubuntu workspace

### Cross-OS behavior
The host OS is detected automatically for PRoot installation. The actual user
workspace is always an Ubuntu rootfs, so the host distribution does not need to
be Ubuntu. The SSHX client is downloaded inside each workspace using the
official `download` installer mode rather than assuming `/usr/local/bin` exists.
The official SSHX project documents Linux x86_64, ARM64, ARMv6 and ARMv7 support.


### Quick start
```bash
chmod +x start.sh
./start.sh
```

The script will:
1. Ask for a port (default: 4545)
2. Ask for an idle timeout (default: 15 minutes)
3. Auto-generate an API key
4. Save configuration to `config.json`
5. Start the server

### First run
The server will:
1. Download Ubuntu 24.04.5 base image (~80 MB, cached after first download)
2. Install PRoot if missing
3. Install `curl` and `ca-certificates` in the base image
4. Remove network diagnostic tools from the base image
5. Start listening on the configured port

## API

All endpoints require the `Authorization: Bearer <API_KEY>` header.

### Create a session
```bash
curl -X POST http://HOST:PORT/api/sessions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"my-workspace"}'
```

By default, this **waits** until the SSHX URL is ready (synchronous mode).
To get immediate response with live polling, add `?wait=false`:
```bash
curl -X POST "http://HOST:PORT/api/sessions?wait=false" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"my-workspace"}'
```

Response (synchronous):
```json
{
  "ok": true,
  "ready": true,
  "session": {
    "id": "abc123...",
    "name": "my-workspace",
    "status": "running",
    "progress": 100,
    "sshx_url": "https://sshx.io/s/XXX#YYY"
  }
}
```

### List sessions
```bash
curl http://HOST:PORT/api/sessions \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Get session status
```bash
curl http://HOST:PORT/api/sessions/SESSION_ID \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Delete a session
```bash
curl -X DELETE http://HOST:PORT/api/sessions/SESSION_ID \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Heartbeat (keep session alive)
```bash
curl -X POST http://HOST:PORT/api/sessions/SESSION_ID/heartbeat \
  -H "Authorization: Bearer YOUR_API_KEY"
```

## Connecting to DARK CLOUD

In your DARK CLOUD admin panel:
1. Go to **VM APIs → Add provider**
2. **Auth Type:** Bearer Token
3. **API URL:** `http://YOUR_SERVER_IP:PORT`
4. **API Key:** (the auto-generated key from start.sh)

## Security notes

- Each session runs in its own PRoot rootfs — fully isolated filesystem
- Network diagnostic tools are removed/stubbed — users can't see server ports
- `/proc/net` is hidden — no TCP/UDP connection visibility
- The API key protects the API from unauthorized access
- SSHX URLs don't expose local IPs or ports — they're token-based

**IMPORTANT:** PRoot is NOT a kernel-level container. It provides filesystem isolation
but not kernel-level sandboxing. For production with untrusted users, use Docker or LXC.
