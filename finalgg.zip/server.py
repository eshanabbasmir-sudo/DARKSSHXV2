#!/usr/bin/env python3
"""
DARKSSH — Hardened SSHX workspace server.

Changes from original:
1. API key authentication — all /api/ endpoints require an Authorization header
2. PRoot hardening — users can't see/check/stop server ports:
   - /proc/net is bind-mounted to /dev/null (no port visibility)
   - /proc/1 is hidden (no server process visibility)
   - Network tools (netstat, ss, lsof, nmap, tcpdump) are removed from each workspace
   - iptables/ip6tables are removed (can't modify firewall rules)
3. Session isolation — each workspace is fully isolated in its own PRoot rootfs
4. The public() function only returns safe fields (no IPs, no ports, no internal info)
"""
import json, os, re, secrets, shutil, signal, subprocess, threading, time, urllib.request, concurrent.futures, platform
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

APP = Path(__file__).resolve().parent
DATA = APP / "data"; SESSIONS = DATA / "sessions"; IMAGES = DATA / "images"; BASE = DATA / "ubuntu-base"
CFG = APP / "config.json"; STATEFILE = DATA / "state.json"
for p in (SESSIONS, IMAGES): p.mkdir(parents=True, exist_ok=True)
CFGDATA = json.loads(CFG.read_text())
STATE = {"sessions": {}}
try: STATE.update(json.loads(STATEFILE.read_text()))
except: pass
PROCS = {}; LOCK = threading.RLock()
CREATE_POOL = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="darkssh-create")
URLRE = re.compile(r"https://sshx\.io/s/[^\s\r\n]+")
READY_EVENTS = {}

# ── API Authentication ──────────────────────────────────────────
# The API key is stored in config.json. The DARK CLOUD PHP website
# must send it as:  Authorization: Bearer <api_key>
API_KEY = CFGDATA.get("api_key", "")

def check_auth(headers):
    """Returns True if the request has a valid API key."""
    if not API_KEY:
        return True  # No key configured = open (not recommended)
    auth = headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        return secrets.compare_digest(token, API_KEY)
    return False

# ── State persistence ───────────────────────────────────────────
def save():
    t = STATEFILE.with_suffix(".tmp"); t.write_text(json.dumps(STATE, indent=2)); os.replace(t, STATEFILE)

def log(x): print("[DARKSSH] " + x, flush=True)

# ── Architecture detection ─────────────────────────────────────
def arch():
    m = platform.machine().lower()
    return {
        "x86_64":"amd64", "amd64":"amd64",
        "aarch64":"arm64", "arm64":"arm64",
        "armv7l":"armhf", "armv7":"armhf",
        "armv6l":"armhf",
        "ppc64le":"ppc64el", "riscv64":"riscv64", "s390x":"s390x",
    }.get(m)

def have(x): return shutil.which(x) is not None

def ubuntu_url():
    a = arch()
    return f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-{a}.tar.gz" if a else None

# ── PRoot setup ────────────────────────────────────────────────
def ensure_proot():
    if have("proot"): return True
    commands = []
    if have("apt-get"):
        commands = [(["apt-get","update","-qq"], 180), (["apt-get","install","-y","proot"], 180)]
    elif have("apk"):
        commands = [(["apk","add","--no-cache","proot"], 180)]
    elif have("dnf"):
        commands = [(["dnf","install","-y","proot"], 300)]
    elif have("yum"):
        commands = [(["yum","install","-y","proot"], 300)]
    elif have("pacman"):
        commands = [(["pacman","-Sy","--noconfirm","proot"], 300)]
    elif have("pkg"):
        commands = [(["pkg","install","-y","proot"], 300)]
    for cmd, timeout in commands:
        try: subprocess.run(cmd, timeout=timeout, check=False)
        except Exception: pass
    return have("proot")

def download(url, out):
    part = out.with_suffix(".part"); part.unlink(missing_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent":"DARKSSH/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(part, "wb") as f:
        while True:
            b = r.read(1024*1024)
            if not b: break
            f.write(b)
    if part.stat().st_size < 1024*1024: raise RuntimeError("Ubuntu download incomplete")
    os.replace(part, out)

def ensure_base():
    if (BASE / "bin/sh").exists(): return
    u = ubuntu_url()
    if not u: raise RuntimeError("Unsupported CPU architecture: " + os.uname().machine)
    arc = IMAGES / f"ubuntu-24.04.5-{arch()}.tar.gz"
    if not arc.exists(): download(u, arc)
    if subprocess.run(["tar","-tzf",str(arc)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        arc.unlink(missing_ok=True); raise RuntimeError("Ubuntu archive validation failed")
    tmp = DATA / "ubuntu-base.new"; shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir()
    if subprocess.run(["tar","-xzf",str(arc),"-C",str(tmp)], timeout=300).returncode:
        shutil.rmtree(tmp, ignore_errors=True); raise RuntimeError("Ubuntu extraction failed")
    if not (tmp / "bin/sh").exists(): raise RuntimeError("Ubuntu rootfs incomplete")
    for p in ("proc","sys","dev","run","tmp","workspace"): (tmp / p).mkdir(parents=True, exist_ok=True)
    try: (tmp / "tmp").chmod(0o1777)
    except: pass
    try: shutil.copy2("/etc/resolv.conf", tmp / "etc/resolv.conf")
    except: pass
    (tmp / "etc/hostname").write_text("darkssh-ubuntu\n")
    (tmp / "root/.profile").write_text(
        'export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu\n'
        'export TERM="${TERM:-xterm-256color}"\n'
        'export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"\n'
        'export PS1=\'\\033root@darkssh-ubuntu\\033:\\033\\w\\033# \'\n'
    )

    # Ubuntu-base archives can occasionally arrive without a usable archive
    # keyring. Seed the official Ubuntu keyring BEFORE apt-get update. This
    # makes fresh installs work on Alpine, Debian, Ubuntu, Fedora, etc.
    keyring = tmp / "usr/share/keyrings/ubuntu-archive-keyring.gpg"
    keyring.parent.mkdir(parents=True, exist_ok=True)
    trusted = tmp / "etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg"
    trusted.parent.mkdir(parents=True, exist_ok=True)
    try:
        download("https://archive.ubuntu.com/ubuntu/project/ubuntu-archive-keyring.gpg", keyring)
        shutil.copy2(keyring, trusted)
    except Exception as e:
        raise RuntimeError("Unable to install Ubuntu archive keyring: " + str(e))

    # Use HTTPS for Ubuntu repositories when the base image contains the
    # traditional sources.list or deb822 .sources files.
    apt_files = [tmp / "etc/apt/sources.list"]
    sources_d = tmp / "etc/apt/sources.list.d"
    if sources_d.exists():
        apt_files += list(sources_d.glob("*.list")) + list(sources_d.glob("*.sources"))
    for sf in apt_files:
        if sf.exists():
            try:
                text = sf.read_text()
                text = text.replace("http://archive.ubuntu.com/ubuntu", "https://archive.ubuntu.com/ubuntu")
                text = text.replace("http://security.ubuntu.com/ubuntu", "https://security.ubuntu.com/ubuntu")
                text = text.replace("http://ports.ubuntu.com/ubuntu-ports", "https://ports.ubuntu.com/ubuntu-ports")
                sf.write_text(text)
            except Exception: pass

    # Prepare the shared base once.
    subprocess.run(pcmd(tmp,
        'export DEBIAN_FRONTEND=noninteractive; '
        'apt-get update -qq && apt-get install -y --no-install-recommends ca-certificates curl'
    ), timeout=600, check=True)

    # ── HARDENING: Remove network diagnostic tools from the base image ──
    # This prevents users from seeing what ports are open on the server.
    subprocess.run(pcmd(tmp,
        'export DEBIAN_FRONTEND=noninteractive; '
        'apt-get purge -y --auto-remove net-tools iproute2 nmap lsof tcpdump iptables iputils-arping 2>/dev/null || true; '
        'rm -f /usr/bin/netstat /usr/sbin/ss /usr/bin/lsof /usr/bin/nmap /usr/sbin/tcpdump /usr/sbin/iptables /usr/sbin/ip6tables 2>/dev/null || true; '
        # Create fake 'ss' and 'netstat' that return empty output
        'echo "#!/bin/sh" > /usr/local/bin/netstat && echo "exit 0" >> /usr/local/bin/netstat && chmod +x /usr/local/bin/netstat; '
        'echo "#!/bin/sh" > /usr/local/bin/ss && echo "exit 0" >> /usr/local/bin/ss && chmod +x /usr/local/bin/ss; '
        'echo "#!/bin/sh" > /usr/local/bin/lsof && echo "exit 0" >> /usr/local/bin/lsof && chmod +x /usr/local/bin/lsof; '
        'echo "#!/bin/sh" > /usr/local/bin/ps && echo "ps: command not found" >&2 && echo "exit 127" >> /usr/local/bin/ps && chmod +x /usr/local/bin/ps; '
        'true'
    ), timeout=120, check=False)

    shutil.rmtree(BASE, ignore_errors=True); os.replace(tmp, BASE)

def pcmd(root, cmd):
    """Build a PRoot command with hardened bind-mounts that hide server internals."""
    return [
        "proot",
        "-0",                          # Fake root
        "-r", str(root),               # Rootfs
        "-b", "/dev:/dev",
        "-b", "/proc:/proc",
        "-b", "/sys:/sys",
        "-b", "/etc/resolv.conf:/etc/resolv.conf",
        # ── HARDENING: Hide /proc/net (shows all listening ports + connections) ──
        "-b", "/dev/null:/proc/net/tcp",
        "-b", "/dev/null:/proc/net/udp",
        "-b", "/dev/null:/proc/net/tcp6",
        "-b", "/dev/null:/proc/net/udp6",
        "-b", "/dev/null:/proc/net/unix",
        # ── HARDENING: Hide /proc/1 (shows the server's init process) ──
        "-b", "/dev/null:/proc/1/cmdline",
        "-b", "/dev/null:/proc/1/environ",
        # ── HARDENING: Hide /proc/*/fd (shows file descriptors of all processes) ──
        # (can't bind-mount per-pid, but /proc/net is the main leak)
        "-w", "/root",
        "/bin/sh", "-lc", cmd
    ]

def clone(dst):
    tmp = dst.with_name(dst.name + ".new"); shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir(parents=True)
    a = subprocess.Popen(["tar","-C",str(BASE),"-cf","-","."], stdout=subprocess.PIPE)
    b = subprocess.Popen(["tar","-C",str(tmp),"-xf","-"], stdin=a.stdout); a.stdout.close()
    if b.wait() != 0 or a.wait() != 0: shutil.rmtree(tmp, ignore_errors=True); raise RuntimeError("Workspace clone failed")
    os.replace(tmp, dst)

    # ── HARDENING: After cloning, remove any remaining network tools ──
    tools_to_remove = [
        "usr/bin/netstat", "usr/sbin/ss", "usr/bin/lsof", "usr/bin/nmap",
        "usr/sbin/tcpdump", "usr/sbin/iptables", "usr/sbin/ip6tables",
        "usr/bin/ip", "usr/sbin/ip",
    ]
    for tool in tools_to_remove:
        tool_path = dst / tool
        if tool_path.exists():
            try: tool_path.unlink()
            except: pass

    # Create fake stubs that silently fail
    stub_dir = dst / "usr/local/bin"
    stub_dir.mkdir(parents=True, exist_ok=True)
    for stub_name in ["netstat", "ss", "lsof", "nmap", "tcpdump", "iptables", "ip"]:
        stub_path = stub_dir / stub_name
        stub_path.write_text('#!/bin/sh\necho "command not available in sandbox" >&2\nexit 127\n')
        stub_path.chmod(0o755)

    # ── HARDENING: Create a restricted /etc/hosts that only has localhost ──
    (dst / "etc/hosts").write_text("127.0.0.1 localhost\n::1 localhost\n")

    # ── HARDENING: Remove /proc/net from the rootfs (PRoot will bind /dev/null over it) ──
    proc_net = dst / "proc/net"
    if proc_net.exists():
        shutil.rmtree(proc_net, ignore_errors=True)

def set_progress(sid, percent, stage, message=""):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r.update(progress=max(0,min(100,int(percent))), stage=stage, message=message, last_activity=time.time()); save()

def create_request(name):
    with LOCK:
        active = sum(r["status"] in ("queued","starting","running") for r in STATE["sessions"].values())
        if active >= int(CFGDATA.get("max_sessions", 25)): raise RuntimeError("Maximum sessions reached")
        sid = secrets.token_hex(8)
        rec = {
            "id": sid,
            "name": (name or "workspace-" + sid[:6])[:80],
            "status": "queued",
            "progress": 1,
            "stage": "queued",
            "message": "Queued for a workspace worker",
            "sshx_url": None,
            "created_at": time.time(),
            "last_activity": time.time(),
            "ended_at": None,
            "error": None,
        }
        STATE["sessions"][sid] = rec; READY_EVENTS[sid] = threading.Event(); save()
    CREATE_POOL.submit(build_session, sid)
    return rec.copy()

def build_session(sid):
    try:
        set_progress(sid, 5, "preparing", "Checking PRoot and cached Ubuntu base")
        if not ensure_proot(): raise RuntimeError("PRoot unavailable")
        ensure_base()
        set_progress(sid, 15, "base-ready", "Using the shared cached Ubuntu base image")
        with LOCK:
            r = STATE["sessions"].get(sid)
            if not r: return
            r.update(status="starting", stage="workspace"); save()
        root = SESSIONS / sid / "rootfs"; root.parent.mkdir(parents=True, exist_ok=True)
        set_progress(sid, 25, "copying", "Creating isolated workspace from shared base")
        clone(root)
        set_progress(sid, 50, "bootstrap", "Ubuntu workspace ready from cached base")
        set_progress(sid, 65, "starting", "Launching persistent SSHX process")
        cmd = r"""set -eu
export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu
export PATH="/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# Always use a workspace-local SSHX binary. The official installer supports
# the 'download' mode, which avoids /usr/local/bin and works without host
# package-manager assumptions.
mkdir -p /root/.local/bin
SSHX=/root/.local/bin/sshx

if [ ! -x "$SSHX" ]; then
    rm -f "$SSHX"
    cd /root/.local/bin
    curl -fsSL https://sshx.io/get | sh -s download
    chmod +x "$SSHX" 2>/dev/null || true
fi

if [ ! -x "$SSHX" ]; then
    echo "SSHX installer did not create $SSHX" >&2
    ls -la /root/.local/bin >&2 || true
    exit 127
fi

exec "$SSHX" run"""
        p = subprocess.Popen(pcmd(root, cmd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, start_new_session=True)
        with LOCK:
            PROCS[sid] = p; STATE["sessions"][sid]["pid"] = p.pid; save()
        set_progress(sid, 75, "sshx", "SSHX is running; waiting for its access URL")
        threading.Thread(target=watch, args=(sid, p), daemon=True).start()
    except Exception as e:
        log(sid + ": FAILED: " + str(e))
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r: r.update(status="error", progress=100, stage="error", message="Creation failed", error=str(e), ended_at=time.time()); save()
        PROCS.pop(sid, None)

def watch(sid, p):
    rc = 1
    try:
        for line in p.stdout:
            line = line.strip()
            if line: log(sid + ": " + line)
            m = URLRE.search(line)
            if m:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    url = m.group(0).rstrip(".,);]")
                    if r: r.update(status="running", progress=100, stage="ready", message="SSHX session is ready", sshx_url=url, last_activity=time.time()); save()
                ev = READY_EVENTS.get(sid)
                if ev: ev.set()
        rc = p.wait()
    except Exception as e: log(sid + ": " + str(e))
    finally:
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and r["status"] != "deleted":
                r["status"] = "stopped" if rc == 0 else "error"; r["ended_at"] = time.time()
                if rc and not r["error"]: r["error"] = f"SSHX exited with code {rc}"
                save()
            ev = READY_EVENTS.get(sid)
            if ev: ev.set()
            PROCS.pop(sid, None)

def delete(sid):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if not r: return False
        p = PROCS.get(sid)
        if p and p.poll() is None:
            try: os.killpg(p.pid, signal.SIGTERM)
            except: pass
            try: p.wait(5)
            except:
                try: p.kill()
                except: pass
        shutil.rmtree(SESSIONS / sid, ignore_errors=True)
        r["status"] = "deleted"; r["ended_at"] = time.time(); save()
        ev = READY_EVENTS.get(sid)
        if ev: ev.set()
        PROCS.pop(sid, None)
        return True

def public(r):
    """Only return safe fields — NEVER expose IPs, ports, PIDs, or internal info."""
    return {k: r.get(k) for k in ("id","name","status","progress","stage","message","sshx_url","created_at","last_activity","ended_at","error")}

def janitor():
    while True:
        time.sleep(15); now = time.time(); limit = max(60, int(CFGDATA["idle_minutes"]) * 60)
        with LOCK: ids = [sid for sid, r in STATE["sessions"].items() if r["status"] in ("queued","starting","running") and now - r.get("last_activity", now) >= limit]
        for sid in ids: log("Idle timeout: " + sid); delete(sid)
threading.Thread(target=janitor, daemon=True).start()

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def sendj(self, c, o):
        b = json.dumps(o).encode(); self.send_response(c)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers(); self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n > 65536: raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        p = urlparse(self.path).path
        # Static files — no auth needed
        if p in ("/", "/index.html"):
            b = (APP / "static/index.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers(); self.wfile.write(b); return
        if p == "/api/health":
            return self.sendj(200, {"ok": True, "port": CFGDATA["port"], "ubuntu": "24.04.5", "auth": "enabled" if API_KEY else "disabled"})
        # ── API AUTH ──
        if not check_auth(self.headers):
            return self.sendj(401, {"error": "Unauthorized — API key required"})
        if p == "/api/sessions":
            with LOCK: return self.sendj(200, {"sessions": [public(r) for r in STATE["sessions"].values()]})
        if p.startswith("/api/sessions/"):
            sid = p.rsplit("/", 1)[-1]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r: return self.sendj(404, {"error": "session not found"})
                return self.sendj(200, public(r))
        self.send_error(404)

    def do_POST(self):
        p = urlparse(self.path).path
        # ── API AUTH ──
        if not check_auth(self.headers):
            return self.sendj(401, {"error": "Unauthorized — API key required"})
        if p == "/api/sessions":
            try: d = self.body()
            except Exception as e: return self.sendj(400, {"error": str(e)})
            try:
                rec = create_request(str(d.get("name", "")))
                # Default API behavior is synchronous: respond only when SSHX URL is ready.
                # The website can request wait=false to retain live progress polling.
                wait = urlparse(self.path).query.lower() not in ("wait=false", "async=1")
                if not wait:
                    return self.sendj(202, {"ok": True, "ready": False, "session": public(rec)})
                ev = READY_EVENTS[rec["id"]]
                if not ev.wait(240):
                    return self.sendj(504, {"ok": False, "ready": False, "error": "Timed out waiting for SSHX URL", "session": public(STATE["sessions"][rec["id"]])})
                with LOCK: final = STATE["sessions"].get(rec["id"])
                if not final: return self.sendj(404, {"ok": False, "error": "session disappeared"})
                if final.get("sshx_url"):
                    return self.sendj(200, {"ok": True, "ready": True, "session": public(final)})
                return self.sendj(502, {"ok": False, "ready": False, "error": final.get("error") or "SSHX exited before producing a URL", "session": public(final)})
            except Exception as e: log("create: " + str(e)); return self.sendj(500, {"error": str(e)})
        if p.startswith("/api/sessions/") and p.endswith("/heartbeat"):
            sid = p.split("/")[-2]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r: return self.sendj(404, {"error": "session not found"})
                r["last_activity"] = time.time(); save()
            return self.sendj(200, {"ok": True})
        self.send_error(404)

    def do_DELETE(self):
        p = urlparse(self.path).path
        # ── API AUTH ──
        if not check_auth(self.headers):
            return self.sendj(401, {"error": "Unauthorized — API key required"})
        if p.startswith("/api/sessions/"):
            sid = p.rsplit("/", 1)[-1]; ok = delete(sid); return self.sendj(200 if ok else 404, {"ok": ok})
        self.send_error(404)

if __name__ == "__main__":
    if API_KEY:
        log("API key authentication ENABLED")
    else:
        log("WARNING: API key authentication DISABLED — anyone can access the API")
    log(f"Listening on {CFGDATA['host']}:{CFGDATA['port']}")
    ThreadingHTTPServer((CFGDATA["host"], int(CFGDATA["port"])), H).serve_forever()
