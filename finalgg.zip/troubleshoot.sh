#!/bin/sh
# DARKSSH automatic troubleshooting script
# Run: chmod +x troubleshoot.sh && ./troubleshoot.sh
set -u

DARKSSH_DIR="${DARKSSH_DIR:-/root/DARKSSH}"
BASE_DIR="${BASE_DIR:-$DARKSSH_DIR/data/ubuntu-base}"
KEYRING_URL="https://archive.ubuntu.com/ubuntu/project/ubuntu-archive-keyring.gpg"

log(){ printf '\n[DARKSSH] %s\n' "$*"; }
ok(){ printf '[OK] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*" >&2; }
die(){ printf '[ERROR] %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Run this script as root."
[ -d "$DARKSSH_DIR" ] || die "DARKSSH directory not found: $DARKSSH_DIR"
[ -d "$BASE_DIR" ] || die "Ubuntu base not found: $BASE_DIR"

# Detect host OS and package manager
HOST_OS="unknown"
[ -r /etc/os-release ] && . /etc/os-release && HOST_OS="${PRETTY_NAME:-${NAME:-unknown}}"
log "Detected host OS: $HOST_OS"

if command -v apt-get >/dev/null 2>&1; then
    PM=apt
elif command -v apk >/dev/null 2>&1; then
    PM=apk
elif command -v dnf >/dev/null 2>&1; then
    PM=dnf
elif command -v yum >/dev/null 2>&1; then
    PM=yum
else
    PM=none
fi
log "Detected package manager: $PM"

# Install host tools according to the detected OS
case "$PM" in
  apt)
    apt-get update || warn "Host apt update failed; continuing."
    apt-get install -y ca-certificates curl wget gnupg ubuntu-keyring proot util-linux iproute2 procps slirp4netns unzip || warn "Some host packages failed."
    ;;
  apk)
    apk update || warn "Host apk update failed; continuing."
    apk add --no-cache ca-certificates curl wget gnupg proot util-linux iproute2 procps slirp4netns unzip || warn "Some host packages failed."
    ;;
  dnf)
    dnf install -y ca-certificates curl wget gnupg2 proot util-linux iproute procps-ng slirp4netns unzip || warn "Some host packages failed."
    ;;
  yum)
    yum install -y ca-certificates curl wget gnupg2 proot util-linux iproute procps-ng unzip || warn "Some host packages failed."
    ;;
  *)
    warn "No supported package manager detected. Continuing with existing commands."
    ;;
esac

mkdir -p "$BASE_DIR/usr/share/keyrings" "$BASE_DIR/etc/apt/trusted.gpg.d"

# Put the official Ubuntu archive keyring into the Ubuntu base.
DEST="$BASE_DIR/usr/share/keyrings/ubuntu-archive-keyring.gpg"
HOST_KEY=""
for f in /usr/share/keyrings/ubuntu-archive-keyring.gpg /etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg; do
    if [ -s "$f" ]; then HOST_KEY="$f"; break; fi
done

if [ -n "$HOST_KEY" ]; then
    log "Copying host Ubuntu archive keyring: $HOST_KEY"
    cp -f "$HOST_KEY" "$DEST"
else
    log "Downloading official Ubuntu archive keyring..."
    if command -v curl >/dev/null 2>&1; then
        curl -fL --retry 3 --connect-timeout 15 "$KEYRING_URL" -o "$DEST" || die "Could not download Ubuntu archive keyring."
    elif command -v wget >/dev/null 2>&1; then
        wget -O "$DEST" "$KEYRING_URL" || die "Could not download Ubuntu archive keyring."
    else
        die "curl/wget is required to download the Ubuntu archive keyring."
    fi
fi

chmod 0644 "$DEST"
cp -f "$DEST" "$BASE_DIR/etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg"
ok "Ubuntu archive keyring installed."

# Fix common Ubuntu repository URLs, including deb822 .sources files.
fix_file(){
    f="$1"
    [ -f "$f" ] || return 0
    sed -i       -e 's|http://archive.ubuntu.com/ubuntu|https://archive.ubuntu.com/ubuntu|g'       -e 's|http://security.ubuntu.com/ubuntu|https://security.ubuntu.com/ubuntu|g'       -e 's|http://ports.ubuntu.com/ubuntu-ports|https://ports.ubuntu.com/ubuntu-ports|g'       "$f"
    ok "Updated APT source: $f"
}

fix_file "$BASE_DIR/etc/apt/sources.list"
if [ -d "$BASE_DIR/etc/apt/sources.list.d" ]; then
    for f in "$BASE_DIR"/etc/apt/sources.list.d/*.list "$BASE_DIR"/etc/apt/sources.list.d/*.sources; do
        [ -f "$f" ] && fix_file "$f"
    done
fi

log "Ubuntu base release:"
if [ -f "$BASE_DIR/etc/os-release" ]; then
    grep -E '^(PRETTY_NAME|VERSION_ID|VERSION_CODENAME)=' "$BASE_DIR/etc/os-release" || true
fi

log "Testing apt-get update inside Ubuntu base..."
proot -0 -r "$BASE_DIR" /bin/sh -c 'export DEBIAN_FRONTEND=noninteractive; apt-get update' || die "Ubuntu base apt-get update failed."

log "Installing required packages inside Ubuntu base..."
proot -0 -r "$BASE_DIR" /bin/sh -c 'export DEBIAN_FRONTEND=noninteractive; apt-get install -y --no-install-recommends ca-certificates curl' || die "Ubuntu base package installation failed."

ok "DARKSSH Ubuntu base is repaired."

# Start DARKSSH unless NO_START=1 was supplied.
if [ "${NO_START:-0}" = "1" ]; then
    log "NO_START=1: repair complete; DARKSSH was not started."
    exit 0
fi

cd "$DARKSSH_DIR" || die "Cannot enter $DARKSSH_DIR"
[ -f start.sh ] || die "start.sh not found in $DARKSSH_DIR"

log "Starting DARKSSH..."
exec sh start.sh
