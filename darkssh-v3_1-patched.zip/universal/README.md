# DARKSSH v3.0 MASTERPIECE — Ultimate Secure SSHX Workspace

```
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║     ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗ ██████╗ ███████╗        ║
║     ██╔══██╗██║   ██║██╔══██╗████╗  ██║██╔════╝ ██╔════╝        ║
║     ██████╔╝██║   ██║███████║██╔██╗ ██║██║  ███╗█████╗          ║
║     ██╔══██╗██║   ██║██╔══██║██║╚██╗██║██║   ██║██╔══╝          ║
║     ██████╔╝╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝███████╗        ║
║     ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝        ║
║                                                                   ║
║                    ★ v3.0 MASTERPIECE ★                          ║
║         Network Isolation • Port Security • Full Internet        ║
╚═══════════════════════════════════════════════════════════════════╝
```

## 🌟 What's New in v3.0 MASTERPIECE

### 🔥 **MAJOR NEW FEATURES:**

#### 1. **🌐 FULL OUTBOUND INTERNET ACCESS**
- ✅ All users can now access the internet
- ✅ curl, wget, git, npm, pip - all work!
- ✅ Download files, clone repos, install packages
- ✅ DNS properly configured (Google DNS + Cloudflare)

#### 2. **🔒 PORT ISOLATION PER USER**
- ✅ Each session gets **private, isolated ports**
- ✅ User A cannot access User B's ports
- ✅ No one can access main system ports
- ✅ Automatic port allocation (base: 10000, 10 ports per session)
- ✅ Ports released when session ends

#### 3. **🛡️ ENHANCED SECURITY**
- ✅ Users CANNOT see other sessions
- ✅ Users CANNOT access system processes
- ✅ Users CANNOT terminate other sessions
- ✅ Dangerous tools removed (sudo, strace, gdb)
- ✅ Network tools KEPT (for outbound internet)

#### 4. **🖥️ TERMINAL FIXES (No More Errors!)**
- ✅ **FIXED**: `tput error` messages
- ✅ **FIXED**: `ptrace(PEEKDATA)` warnings
- ✅ **FIXED**: Terminal escape sequence issues
- ✅ Uses `dumb` terminal for PRoot compatibility
- ✅ Custom tput/resize/stty stubs

---

### 🌍 **Works EVERYWHERE:**
- ✅ **Linux**: All distributions (Debian, Ubuntu, CentOS, Alpine, Arch, etc.)
- ✅ **macOS**: With Docker or direct mode
- ✅ **Windows**: WSL2, Git Bash, native (with Docker)
- ✅ **Containers**: Docker, LXC, OpenVZ, systemd-nspawn
- ✅ **Cloud VPS/VDS**: AWS, GCP, Azure, DigitalOcean, Vultr, etc.

---

## 🚀 Quick Start

### Option 1: Interactive Setup
```bash
chmod +x start.sh server.py
./start.sh
python3 server.py
```

### Option 2: Non-Interactive (Automation/CI-CD)
```bash
./start.sh --non-interactive
python3 server.py
```

### Option 3: Create Session via API
```bash
# Create a new workspace with full internet access
curl -X POST http://localhost:4545/api/sessions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"my-workspace"}'

# Response includes:
# - sshx_url: Your private terminal URL
# - ports: Your allocated private ports
# - network_enabled: true
```

---

## ⚙️ Configuration (config.json)

```json
{
  "host": "0.0.0.0",
  "port": 4545,
  "idle_minutes": 15,
  "max_sessions": 25,
  "api_key": "your-api-key-here",
  
  "universal_mode": true,
  "debug": true,
  
  "base_port": 10000,
  "ports_per_session": 10,
  "enable_outbound": true,
  "allow_port_access": false
}
```

### New v3.0 Config Options:
| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `base_port` | int | 10000 | Starting port for allocation |
| `ports_per_session` | int | 10 | Number of ports per session |
| `enable_outbound` | bool | true | Allow internet access |
| `allow_port_access` | bool | false | Allow cross-session port access |

---

## 🔌 API Endpoints

### Health Check (No Auth Required)
```bash
curl http://localhost:4545/api/health
# Returns:
{
  "version": "3.0.0",
  "network": {
    "outbound_enabled": true,
    "port_isolation": true,
    "base_port": 10000,
    "ports_per_session": 10
  },
  "active_sessions": 3
}
```

### Create Session
```bash
curl -X POST http://localhost:4545/api/sessions \
  -H "Authorization: Bearer KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"workspace"}'
```

### List Sessions
```bash
curl http://localhost:4545/api/sessions \
  -H "Authorization: Bearer KEY"
```

### Delete Session
```bash
curl -X DELETE http://localhost:4545/api/sessions/SESSION_ID \
  -H "Authorization: Bearer KEY"
```

---

## 🛡️ Security Model (v3.0)

### What Users CAN Do:
- ✅ Full outbound internet access
- ✅ Install packages (apt, npm, pip, etc.)
- ✅ Use their allocated private ports
- ✅ Run most development tools
- ✅ Access their own workspace files

### What Users CANNOT Do:
- ❌ See other users' sessions
- ❌ Access other users' ports
- ❌ Access system ports (< 10000)
- ❌ Run sudo or escalate privileges
- ❌ See system processes (/proc/1)
- ❌ Use dangerous debugging tools (strace, gdb)
- ❌ Terminate other sessions
- ❌ Access main system files

### Isolation Layers:
1. **Filesystem Isolation** (PRoot/Docker/Chroot)
2. **Network Isolation** (Private ports per user)
3. **Process Isolation** (Hidden /proc entries)
4. **Tool Restrictions** (Dangerous commands removed)
5. **API Authentication** (Bearer token required)

---

## 🐛 Troubleshooting

### "tput error" or "ptrace warning"
**FIXED in v3.0!** These errors are now handled automatically:
- Terminal set to `dumb` mode
- Custom stubs for tput, resize, stty
- PRoot warnings filtered from logs

If you still see them, they're harmless - just debug info.

### "Port already in use"
```bash
# Change base port in config.json:
"base_port": 20000
```

### "No internet access in session"
```bash
# Ensure outbound is enabled:
"enable_outbound": true

# Check DNS is working in session:
cat /etc/resolv.conf
# Should show: nameserver 8.8.8.8
```

### Install PRoot manually (if auto-install fails)
```bash
# Debian/Ubuntu:
sudo apt-get install proot

# Fedora:
sudo dnf install proot

# Alpine:
sudo apk add proot
```

---

## 📊 Version History

### v3.0.0 (MASTERPIECE) - Current
- ✅ Full outbound internet for all users
- ✅ Port isolation per session
- ✅ Fixed tput/ptrace terminal errors
- ✅ Enhanced security hardening
- ✅ CORS support for browser access
- ✅ Improved logging and error handling

### v2.2 - Bug Fix Release
- ✅ Fixed `log_warning` undefined error
- ✅ Fixed GPG key errors

### v2.0 - Universal Version
- ✅ Cross-platform support
- ✅ Multiple package managers
- ✅ Non-interactive mode
- ✅ Download retry/resume

---

## 📝 License & Credits

- **Original Project**: DARKSSH Hardened
- **v3.0 Masterpiece**: Prime Automation
- **License**: Same as original project

---

**Made with ❤️ by Prime Automation**

*Network Isolation • Port Security • Full Internet • Works Everywhere*
