#!/usr/bin/env bash
set -e

# DARKSSH requires a POSIX-capable shell plus Python 3. Bash is preferred,
# but the server itself is portable across Linux distributions.
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 is required. Install python3 with your OS package manager." >&2
  exit 1
fi
APP="$(cd "$(dirname "$0")" && pwd)"

echo "╔══════════════════════════════════════════╗"
echo "║   DARKSSH — Hardened Setup               ║"
echo "╚══════════════════════════════════════════╝"
echo ""

read -r -p "Website port [4545]: " PORT
PORT="${PORT:-4545}"
read -r -p "Kill session after inactivity in minutes [15]: " IDLE
IDLE="${IDLE:-15}"

case "$PORT" in ''|*[!0-9]*) echo "Invalid port"; exit 1;; esac
case "$IDLE" in ''|*[!0-9]*) echo "Invalid timeout"; exit 1;; esac
[ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ] || exit 1
[ "$IDLE" -ge 1 ] || exit 1

# Generate a random API key for authentication
API_KEY=$(head -c 32 /dev/urandom | base64 | tr -d '/+=' | head -c 40)

mkdir -p "$APP/data/sessions" "$APP/data/images"

cat > "$APP/config.json" << EOF
{
  "host": "0.0.0.0",
  "port": $PORT,
  "idle_minutes": $IDLE,
  "max_sessions": 25,
  "api_key": "$API_KEY"
}
EOF

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   SETUP COMPLETE                          ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "Server port:     $PORT"
echo "Idle timeout:    $IDLE minutes"
echo ""
echo "API KEY (save this — needed by DARK CLOUD website):"
echo "  $API_KEY"
echo ""
echo "To configure in DARK CLOUD admin panel:"
echo "  1. Login to /admin/login.php"
echo "  2. Go to VM APIs → Add provider"
echo "  3. Auth Type: Bearer Token"
echo "  4. API URL: http://YOUR_SERVER_IP:$PORT"
echo "  5. API Key: $API_KEY"
echo ""
echo "Starting server..."
echo ""
exec python3 "$APP/server.py"
