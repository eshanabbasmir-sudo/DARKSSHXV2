# DARKSSH — Automatic Ubuntu + SSHX Workspace Server

DARKSSH creates isolated Ubuntu workspaces and launches the official SSHX client.
It is designed to adapt to Ubuntu/Debian, Alpine, Fedora/RHEL, Arch, openSUSE,
Termux-like Linux environments, VPSs and Linux containers.

## What is automatic

On startup DARKSSH detects:

- host OS and package manager
- CPU architecture
- Python availability
- PRoot availability
- user/network namespace support
- `slirp4netns` availability
- existing `ubuntu-base` / `ubuntu-base.new`
- broken Ubuntu APT keyrings and repository URLs
- missing `curl` / CA certificates
- missing SSHX inside the Ubuntu base

It repairs the cached Ubuntu base before creating sessions. SSHX is installed
inside the Ubuntu workspace, so the host's `/usr/local/bin/sshx` is never
required.

The official SSHX project documents the `download` installer mode and states
that Linux binaries are statically linked: https://github.com/ekzhang/sshx

## Isolation modes

DARKSSH chooses the strongest mode the host actually permits:

1. **namespace+slirp** — private user/PID/network namespace when `unshare` and
   `slirp4netns` are available and user namespaces are permitted.
2. **proot-fallback** — filesystem isolation without binding the host `/proc`
   or `/sys` when the hosting provider blocks namespaces.

The fallback is intentionally reported rather than falsely advertised as
kernel-level isolation. A container/VPS can prevent namespace creation, ptrace,
network configuration, or package installation; no user-space program can
re-enable capabilities removed by the host.

## Start

```bash
chmod +x start.sh
./start.sh
```

No questions are required. Defaults:

- API port: `5000`
- idle timeout: `60` minutes
- maximum concurrent sessions: `25`

For unattended deployment:

```bash
DARKSSH_PORT=5000 DARKSSH_IDLE_MINUTES=60 DARKSSH_MAX_SESSIONS=25 ./start.sh
```

## API

All session creation requests require the generated Bearer API key.
Creation returns a per-session `owner_token`. The owner token can be used in
`X-Session-Token` for status, heartbeat and delete operations without exposing
other sessions.

```bash
curl -X POST http://HOST:5000/api/sessions \
  -H 'Authorization: Bearer API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{"name":"my-workspace"}'
```

Health/capability information is public:

```bash
curl http://HOST:5000/api/health
```

## Important limitation

"Every VPS/container" cannot literally mean every Linux environment. A host
can disable user namespaces, ptrace, networking, outbound HTTPS, package
installation, or execution of binaries. DARKSSH detects these restrictions and
uses its fallback where possible; otherwise it returns a precise error instead
of pretending the isolation is stronger than it is.

For genuinely untrusted multi-tenant workloads, use a kernel-level container
runtime/VM with provider-controlled namespaces and seccomp. PRoot is a user-space
compatibility layer, not a replacement for a VM or container runtime.
