# DARKSSH Universal v2.0 — Cross-Platform Hardened SSHX Workspace

## ✨ What's New in Universal Version

### 🌍 **Works EVERYWHERE Now:**
- ✅ **Linux**: All distributions (Debian, Ubuntu, CentOS, Alpine, Arch, Fedora, openSUSE, Amazon Linux, etc.)
- ✅ **macOS**: With Docker or direct mode
- ✅ **Windows**: WSL2, Git Bash, native (with Docker)
- ✅ **Containers**: Docker, LXC, OpenVZ, systemd-nspawn
- ✅ **Cloud VPS/VDS**: AWS, GCP, Azure, DigitalOcean, Vultr, Hetzner, etc.
- ✅ **Embedded**: Raspberry Pi, ARM devices, NAS systems

### 🔧 **New Features:**

#### 1. **Universal OS Detection**
```
Auto-detects:
• OS Type (Linux/macOS/Windows/BSD)
• Distribution (Ubuntu/Debian/CentOS/Alpine/Arch/etc.)
• Architecture (x86_64/ARM64/ARMhf/PPC64/RISC-V/s390x)
• Package Manager (apt/yum/dnf/apk/pacman/zypper/brew/choco)
• Container Detection (Docker/LXC/OpenVZ/Kubernetes)
• Root/Sudo Access
```

#### 2. **Smart Package Installation**
```bash
# Automatically detects and uses the right package manager:
apt (Debian/Ubuntu/Linux Mint)
dnf (Fedora/RHEL 8+)
yum (CentOS/RHEL 7/Amazon Linux)
apk (Alpine Linux)
pacman (Arch Linux/Manjaro)
zypper (openSUSE)
brew (macOS)
choco (Windows)
pkg (BSD)
```

#### 3. **Non-Interactive Mode** (Perfect for Automation!)
```bash
# Fully automatic - no user input needed
./start.sh --non-interactive

# With environment variables
DARKSSH_PORT=8080 DARKSSH_IDLE_TIMEOUT=30 ./start.sh -n

# For CI/CD, scripts, cron jobs, etc.
```

#### 4. **Robust Download System**
- ✅ **Retry Mechanism**: 3 automatic retries with exponential backoff
- ✅ **Resume Support**: Continues interrupted downloads
- ✅ **Multiple Mirrors**: Falls back to alternative mirrors if primary fails
- ✅ **Progress Reporting**: Shows download progress
- ✅ **Validation**: Verifies downloaded files integrity

#### 5. **Comprehensive System Checks**
```
✓ Python version (3.6+ required)
✓ Disk space (500MB recommended, 200MB minimum)
✓ RAM (512MB recommended)
✓ Network connectivity
✓ Root/sudo permissions
✓ Port availability
✓ Architecture support
✓ Isolation capability (PRoot/Docker/Chroot)
```

#### 6. **Graceful Degradation**
If full isolation isn't available:
1. **PRoot** (best) → Full filesystem isolation + security hardening
2. **Docker** (good) → Container-based isolation
3. **Chroot** (basic) → Filesystem isolation (requires root)
4. **None** (fallback) → Runs directly with reduced security

#### 7. **Enhanced Security**
All original hardening features PLUS:
- Automatic stub creation for network tools
- Restricted `/etc/hosts` per workspace
- Process hiding from users
- API key authentication
- Session isolation

---

## 🚀 Quick Start

### Option 1: Interactive Setup (Recommended for First Time)
```bash
chmod +x start.sh
./start.sh
```

### Option 2: Non-Interactive (Automation/CI-CD)
```bash
# Use all defaults
./start.sh --non-interactive

# Custom settings via environment variables
export DARKSSH_PORT=9090
export DARKSSH_IDLE_TIMEOUT=30
export DARKSSH_MAX_SESSIONS=50
./start.sh --non-interactive

# Or via command line
./start.sh -p 9090 -i 30 -n
```

### Option 3: Force Install (Skip Checks)
```bash
./start.sh --force
```

---

## 📋 Requirements

### Minimum Requirements:
- **Python**: 3.6+ (3.7+ recommended)
- **Disk Space**: 200MB minimum (500MB recommended for multiple sessions)
- **RAM**: 256MB minimum (512MB recommended)
- **Network**: Internet access (for Ubuntu image + SSHX)

### Platform-Specific:

| Platform | Additional Requirements |
|----------|------------------------|
| **Linux** | PRoot (auto-installed), or root access |
| **macOS** | Docker (optional, for better isolation) |
| **Windows** | WSL2 or Docker Desktop |
| **BSD** | Basic Unix tools |

---

## 🔌 API Usage

All endpoints require `Authorization: Bearer <API_KEY>` header.

### Create Session
```bash
# Synchronous (waits for SSHX URL)
curl -X POST http://localhost:4545/api/sessions \
  -H "Authorization: Bearer YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"my-workspace"}'

# Asynchronous (returns immediately)
curl -X POST "http://localhost:4545/api/sessions?wait=false" \
  -H "Authorization: Bearer YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"my-workspace"}'
```

### List Sessions
```bash
curl http://localhost:4545/api/sessions \
  -H "Authorization: Bearer YOUR_KEY"
```

### Get Session Status
```bash
curl http://localhost:4545/api/sessions/SESSION_ID \
  -H "Authorization: Bearer YOUR_KEY"
```

### Delete Session
```bash
curl -X DELETE http://localhost:4545/api/sessions/SESSION_ID \
  -H "Authorization: Bearer YOUR_KEY"
```

### Heartbeat (Keep Alive)
```bash
curl -X POST http://localhost:4545/api/sessions/SESSION_ID/heartbeat \
  -H "Authorization: Bearer YOUR_KEY"
```

### Health Check
```bash
curl http://localhost:4545/api/health
```

---

## ⚙️ Configuration

Configuration is stored in `config.json`:

```json
{
  "host": "0.0.0.0",
  "port": 4545,
  "idle_minutes": 15,
  "max_sessions": 25,
  "api_key": "your-generated-key",
  "detected_os": "linux",
  "detected_distro": "ubuntu",
  "detected_arch": "amd64",
  "package_manager": "apt",
  "universal_mode": true
}
```

### Environment Variables (for non-interactive mode):
| Variable | Description | Default |
|----------|-------------|---------|
| `DARKSSH_PORT` | Server port | 4545 |
| `DARKSSH_IDLE_TIMEOUT` | Idle timeout in minutes | 15 |
| `DARKSSH_API_KEY` | Pre-generated API key | Auto-generated |
| `DARKSSH_MAX_SESSIONS` | Maximum concurrent sessions | 25 |

---

## 🛡️ Security Features

### Original Hardening (Preserved):
- ✅ API Key Authentication
- ✅ PRoot Filesystem Isolation
- ✅ `/proc/net` Hidden (no port visibility)
- ✅ `/proc/1` Hidden (no server process visibility)
- ✅ Network Tools Removed (netstat, ss, lsof, nmap, tcpdump)
- ✅ Fake Stubs for Removed Commands
- ✅ Restricted `/etc/hosts`
- ✅ Session Isolation
- ✅ SSHX URL Privacy (no IP/port exposure)

### New in Universal Version:
- ✅ Cross-Platform Compatibility
- ✅ Multiple Isolation Methods
- ✅ Graceful Security Degradation
- ✅ Enhanced Error Handling
- ✅ System Capability Detection

---

## 🐛 Troubleshooting

### Common Issues:

**1. "PRoot unavailable" on Linux**
```bash
# Install manually:
sudo apt-get install proot          # Debian/Ubuntu
sudo dnf install proot              # Fedora
sudo apk add proot                  # Alpine
```

**2. "Port already in use"**
```bash
# Use different port:
./start.sh -p 8080

# Or kill existing process:
lsof -i :4545 | grep LISTEN | awk '{print $2}' | xargs kill
```

**3. "Download failed"**
```bash
# Check network:
curl -I https://cdimage.ubuntu.com

# Manual download:
wget https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-amd64.tar.gz
mv ubuntu-base-24.04.5-base-amd64.tar.gz data/images/
```

**4. "Permission denied"**
```bash
# Need root/sudo for PRoot installation
sudo ./start.sh

# Or run non-root (limited features):
./start.sh --non-interactive
```

**5. Low disk space**
```bash
# Clear cache:
rm -rf data/ubuntu-base.new/
rm -f data/images/*.tar.gz.part

# Check space:
df -h .
```

---

## 📊 Supported Platforms Matrix

| Platform | PRoot | Docker | Chroot | Direct | Status |
|----------|-------|--------|--------|--------|--------|
| Ubuntu 20.04+ | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| Debian 10+ | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| CentOS 7+/RHEL 8+ | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| Fedora 34+ | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| Alpine 3.14+ | ✅ | ✅ | ❌ | ✅ | ✅ Full |
| Arch Linux | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| macOS (Intel) | ❌ | ✅ | ❌ | ✅ | ⚠️ Limited |
| macOS (Apple Silicon) | ❌ | ✅ | ❌ | ✅ | ⚠️ Limited |
| Windows (WSL2) | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| Windows (Native) | ❌ | ✅ | ❌ | ✅ | ⚠️ Limited |
| FreeBSD | ❌ | ✅ | ✅ | ✅ | ⚠️ Limited |
| Raspberry Pi (ARM) | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| ARM Servers (aarch64) | ✅ | ✅ | ✅ | ✅ | ✅ Full |
| RISC-V | ⚠️ Exp | ❌ | ✅ | ✅ | ⚠️ Experimental |
| s390x (IBM Z) | ✅ | ✅ | ✅ | ✅ | ✅ Full |

Legend:
- ✅ Full = All features work perfectly
- ⚠️ Limited = Works with reduced functionality
- ❌ Not Available = Feature not supported on this platform
- ⚠️ Exp = Experimental/May have issues

---

## 🔄 Migration from v1.x

If you're upgrading from the original version:

1. **Backup your data** (if any):
   ```bash
   cp -r data/ data-backup/
   ```

2. **Replace files**:
   ```bash
   # Remove old files (keep data/)
   rm start.sh server.py static/index.html
   
   # Copy new universal versions
   cp universal/start.sh .
   cp universal/server.py .
   cp universal/static/index.html static/
   
   chmod +x start.sh
   ```

3. **Run new setup**:
   ```bash
   ./start.sh
   ```

Your existing sessions and configuration will be preserved!

---

## 📝 License & Credits

- **Original Project**: DARKSSH Hardened
- **Universal Version**: Prime Automation v2.0
- **License**: Same as original project

---

## 🆘 Support

Having issues? Check:
1. Run `./start.sh --verbose` for detailed output
2. Check `/api/health` endpoint for system info
3. Review logs above for error messages
4. Ensure minimum requirements are met

---

**Made with ❤️ by Prime Automation**

*Works Everywhere. Everytime. For Everyone.* 
