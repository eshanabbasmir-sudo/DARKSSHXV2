#!/usr/bin/env python3
"""DARKSSH - automatic, adaptive Ubuntu + SSHX workspace server.

The host is treated as untrusted infrastructure. DARKSSH detects the host
platform, package manager and namespace capabilities at runtime, repairs or
creates its Ubuntu base, installs a workspace-local SSHX client, and chooses
an isolation mode that the host can actually support.

Important: no Linux application can guarantee kernel-level isolation inside
an arbitrary VPS/container. If the host blocks user/network namespaces or
ptrace, DARKSSH falls back to PRoot filesystem isolation and reports the
reduced capability in /api/health instead of pretending it has stronger
isolation.
"""
import concurrent.futures
import json
import os
import platform
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP = Path(__file__).resolve().parent
DATA = APP / "data"
SESSIONS = DATA / "sessions"
IMAGES = DATA / "images"
CFG = APP / "config.json"
STATEFILE = DATA / "state.json"
BASE = DATA / "ubuntu-base"
BASE_NEW = DATA / "ubuntu-base.new"
LOCAL_BIN = APP / "bin"
PROOT_LOCAL = LOCAL_BIN / "proot"

for p in (SESSIONS, IMAGES, LOCAL_BIN):
    p.mkdir(parents=True, exist_ok=True)

DEFAULT_CFG = {
    "host": "0.0.0.0",
    "port": 5000,
    "idle_minutes": 60,
    "max_sessions": 25,
    "api_key": "",
}

try:
    CFGDATA = {**DEFAULT_CFG, **json.loads(CFG.read_text())}
except Exception:
    CFGDATA = DEFAULT_CFG.copy()

STATE = {"sessions": {}}
try:
    loaded = json.loads(STATEFILE.read_text())
    if isinstance(loaded, dict) and isinstance(loaded.get("sessions"), dict):
        STATE.update(loaded)
except Exception:
    pass

PROCS = {}
NETPROCS = {}
LOCK = threading.RLock()
CREATE_POOL = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="darkssh-create")
READY_EVENTS = {}
URLRE = re.compile(r"https://sshx\.io/s/[^\s\r\n]+")


def log(msg):
    print("[DARKSSH] " + str(msg), flush=True)


def save():
    tmp = STATEFILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(STATE, indent=2))
    os.replace(tmp, STATEFILE)


def have(name):
    return shutil.which(name) is not None


def run(cmd, *, timeout=120, check=False, env=None, capture=False):
    return subprocess.run(
        cmd,
        timeout=timeout,
        check=check,
        env=env,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
        text=True if capture else False,
    )


def root_runner():
    if os.geteuid() == 0:
        return []
    for x in ("sudo", "doas"):
        if have(x):
            return [x]
    return None


def detect_host():
    info = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                info[k] = v.strip().strip('"')
    except Exception:
        pass
    return {
        "os": info.get("PRETTY_NAME") or info.get("NAME") or platform.system(),
        "id": info.get("ID", "unknown"),
        "version": info.get("VERSION_ID", ""),
        "arch": platform.machine().lower(),
        "python": platform.python_version(),
        "container": detect_container(),
    }


def detect_container():
    try:
        text = Path("/proc/1/cgroup").read_text(errors="ignore").lower()
        if any(x in text for x in ("docker", "kubepods", "containerd", "podman", "lxc")):
            return True
        if Path("/.dockerenv").exists() or Path("/run/.containerenv").exists():
            return True
    except Exception:
        pass
    return False


def package_manager():
    for name in ("apt-get", "apk", "dnf", "yum", "pacman", "zypper", "pkg"):
        if have(name):
            return name
    return None


def install_host_packages():
    """Best-effort host bootstrap. Never claims success unless tools exist."""
    pm = package_manager()
    if not pm:
        return
    prefix = root_runner()
    if prefix is None and os.geteuid() != 0:
        log("No root/sudo/doas available; cannot install missing host packages automatically")
        return

    commands = {
        "apt-get": ["apt-get", "update", "-qq"],
        "apk": ["apk", "update"],
        "dnf": ["dnf", "makecache", "-q"],
        "yum": ["yum", "makecache", "-q"],
        "pacman": ["pacman", "-Sy", "--noconfirm"],
        "zypper": ["zypper", "--non-interactive", "refresh"],
        "pkg": ["pkg", "update", "-f"],
    }
    packages = {
        "apt-get": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot"],
        "apk": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "dnf": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "yum": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot"],
        "pacman": ["python", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot", "slirp4netns"],
        "zypper": ["python3", "ca-certificates", "curl", "wget", "tar", "gzip", "util-linux", "proot"],
        "pkg": ["python", "curl", "wget", "tar", "gzip", "proot"],
    }
    try:
        run(prefix + commands[pm], timeout=180, check=False)
    except Exception:
        pass
    try:
        if pm == "apt-get": cmd = ["apt-get", "install", "-y", "--no-install-recommends"] + packages[pm]
        elif pm == "apk": cmd = ["apk", "add", "--no-cache"] + packages[pm]
        elif pm in ("dnf", "yum"): cmd = [pm, "install", "-y"] + packages[pm]
        elif pm == "pacman": cmd = ["pacman", "-S", "--noconfirm"] + packages[pm]
        elif pm == "zypper": cmd = ["zypper", "--non-interactive", "install", "--no-recommends"] + packages[pm]
        else: cmd = ["pkg", "install", "-y"] + packages[pm]
        run(prefix + cmd, timeout=600, check=False)
    except Exception:
        pass


def arch_name():
    m = platform.machine().lower()
    return {
        "x86_64": "amd64", "amd64": "amd64",
        "aarch64": "arm64", "arm64": "arm64",
        "armv7l": "armhf", "armv7": "armhf", "armv6l": "armhf",
    }.get(m)


def ubuntu_url():
    a = arch_name()
    return f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-{a}.tar.gz" if a else None


def fetch(url, out, min_bytes=1, attempts=3):
    """Download with curl/wget/urllib fallback and atomic replacement."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    part = out.with_name(out.name + ".part")
    last = None
    for attempt in range(1, attempts + 1):
        part.unlink(missing_ok=True)
        try:
            if have("curl"):
                cp = run(["curl", "-fL", "--retry", "2", "--connect-timeout", "20", "--max-time", "600", "-A", "DARKSSH/2", "-o", str(part), url], timeout=650, capture=True)
                if cp.returncode != 0:
                    raise RuntimeError((cp.stderr or "curl failed").strip())
            elif have("wget"):
                cp = run(["wget", "-q", "--timeout=30", "--tries=3", "-O", str(part), url], timeout=650, capture=True)
                if cp.returncode != 0:
                    raise RuntimeError((cp.stderr or "wget failed").strip())
            else:
                req = urllib.request.Request(url, headers={"User-Agent": "DARKSSH/2"})
                with urllib.request.urlopen(req, timeout=60) as r, open(part, "wb") as f:
                    while True:
                        b = r.read(1024 * 1024)
                        if not b:
                            break
                        f.write(b)
            if part.stat().st_size < min_bytes:
                raise RuntimeError(f"download too small ({part.stat().st_size} bytes)")
            os.replace(part, out)
            return
        except Exception as e:
            last = e
            time.sleep(attempt)
    raise RuntimeError(f"download failed: {url}: {last}")


def migrate_base():
    """Use the user's existing ubuntu-base.new if it is complete."""
    if (BASE / "bin/sh").exists():
        return
    if (BASE_NEW / "bin/sh").exists():
        log("Found existing ubuntu-base.new; promoting it to ubuntu-base")
        shutil.rmtree(BASE, ignore_errors=True)
        os.replace(BASE_NEW, BASE)


def repair_sources(root):
    root = Path(root)
    files = [root / "etc/apt/sources.list"]
    sd = root / "etc/apt/sources.list.d"
    if sd.exists():
        files += list(sd.glob("*.list")) + list(sd.glob("*.sources"))
    replacements = {
        "http://archive.ubuntu.com/ubuntu": "https://archive.ubuntu.com/ubuntu",
        "http://security.ubuntu.com/ubuntu": "https://security.ubuntu.com/ubuntu",
        "http://ports.ubuntu.com/ubuntu-ports": "https://ports.ubuntu.com/ubuntu-ports",
        "http://security.ubuntu.com/ubuntu-ports": "https://ports.ubuntu.com/ubuntu-ports",
    }
    for f in files:
        if not f.exists():
            continue
        try:
            s = f.read_text()
            for a, b in replacements.items():
                s = s.replace(a, b)
            f.write_text(s)
        except Exception:
            pass


def seed_keyring(root):
    root = Path(root)
    candidates = [
        Path("/usr/share/keyrings/ubuntu-archive-keyring.gpg"),
        Path("/etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg"),
        root / "usr/share/keyrings/ubuntu-archive-keyring.gpg",
    ]
    dest = root / "usr/share/keyrings/ubuntu-archive-keyring.gpg"
    trusted = root / "etc/apt/trusted.gpg.d/ubuntu-archive-keyring.gpg"
    dest.parent.mkdir(parents=True, exist_ok=True)
    trusted.parent.mkdir(parents=True, exist_ok=True)
    for src in candidates:
        try:
            if src.exists() and src.stat().st_size > 1000:
                shutil.copy2(src, dest)
                shutil.copy2(src, trusted)
                return
        except Exception:
            pass
    urls = [
        "https://archive.ubuntu.com/ubuntu/project/ubuntu-archive-keyring.gpg",
        "https://mirror.hetzner.com/ubuntu/ubuntu/project/ubuntu-archive-keyring.gpg",
    ]
    last = None
    for url in urls:
        try:
            fetch(url, dest, min_bytes=10000)
            shutil.copy2(dest, trusted)
            return
        except Exception as e:
            last = e
    raise RuntimeError("Unable to obtain the official Ubuntu archive keyring: " + str(last))


def pcmd(root, command):
    """Safe PRoot command: never bind the host /proc or /sys."""
    root = str(root)
    return [
        proot_binary(), "-0", "-r", root,
        "-b", "/dev/null:/dev/null",
        "-b", "/dev/zero:/dev/zero",
        "-b", "/dev/random:/dev/random",
        "-b", "/dev/urandom:/dev/urandom",
        "-b", "/dev/tty:/dev/tty",
        "-b", "/dev/pts:/dev/pts",
        "-b", "/etc/resolv.conf:/etc/resolv.conf",
        "-w", "/root",
        "/bin/sh", "-lc", command,
    ]


def proot_binary():
    if have("proot"):
        return shutil.which("proot")
    if PROOT_LOCAL.exists() and os.access(PROOT_LOCAL, os.X_OK):
        return str(PROOT_LOCAL)
    return str(PROOT_LOCAL)


def ensure_proot():
    if have("proot"):
        return True
    install_host_packages()
    if have("proot"):
        return True
    # Official PRoot docs provide a current static x86_64 binary. This is a
    # useful final fallback when a container has no usable package manager.
    if platform.machine().lower() in ("x86_64", "amd64"):
        try:
            fetch("https://proot.gitlab.io/proot/bin/proot", PROOT_LOCAL, min_bytes=100000)
            PROOT_LOCAL.chmod(0o755)
            return PROOT_LOCAL.exists() and os.access(PROOT_LOCAL, os.X_OK)
        except Exception as e:
            log("Static PRoot download failed: " + str(e))
    return False


def test_user_namespace():
    if not have("unshare"):
        return False
    try:
        cp = run(["unshare", "-Urn", "--", "/bin/true"], timeout=10, capture=True)
        return cp.returncode == 0
    except Exception:
        return False


def capabilities():
    netns = test_user_namespace()
    slirp = have("slirp4netns")
    return {
        "proot": ensure_proot(),
        "user_network_namespace": netns,
        "slirp4netns": slirp,
        "private_network": bool(netns and slirp),
        "mode": "namespace+slirp" if netns and slirp else "proot-fallback",
    }


CAPS = None


def ensure_base():
    global CAPS
    migrate_base()
    if not (BASE / "bin/sh").exists():
        u = ubuntu_url()
        if not u:
            raise RuntimeError("Unsupported CPU architecture for Ubuntu base: " + platform.machine())
        arc = IMAGES / f"ubuntu-24.04.5-{arch_name()}.tar.gz"
        if not arc.exists():
            log("Downloading Ubuntu 24.04.5 base for " + arch_name())
            fetch(u, arc, min_bytes=1024 * 1024)
        if run(["tar", "-tzf", str(arc)], timeout=120).returncode != 0:
            arc.unlink(missing_ok=True)
            raise RuntimeError("Ubuntu archive validation failed")
        shutil.rmtree(BASE_NEW, ignore_errors=True)
        BASE_NEW.mkdir(parents=True, exist_ok=True)
        cp = run(["tar", "-xzf", str(arc), "-C", str(BASE_NEW)], timeout=600, capture=True)
        if cp.returncode != 0:
            shutil.rmtree(BASE_NEW, ignore_errors=True)
            raise RuntimeError("Ubuntu extraction failed: " + (cp.stderr or ""))
        if not (BASE_NEW / "bin/sh").exists():
            raise RuntimeError("Ubuntu rootfs incomplete")
        os.replace(BASE_NEW, BASE)

    for p in ("proc", "sys", "dev", "dev/pts", "run", "tmp", "workspace"):
        (BASE / p).mkdir(parents=True, exist_ok=True)
    try:
        (BASE / "tmp").chmod(0o1777)
    except Exception:
        pass
    try:
        shutil.copy2("/etc/resolv.conf", BASE / "etc/resolv.conf")
    except Exception:
        pass
    (BASE / "etc/hostname").write_text("darkssh-ubuntu\n")
    seed_keyring(BASE)
    repair_sources(BASE)

    # Repair an existing cached base too; old project versions could leave a
    # broken keyring, missing curl, or a missing SSHX client.
    apt_cmd = "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y --no-install-recommends ca-certificates curl"
    cp = run(pcmd(BASE, apt_cmd), timeout=900, capture=True)
    if cp.returncode != 0:
        msg = (cp.stdout or "") + "\n" + (cp.stderr or "")
        raise RuntimeError("Ubuntu base APT repair failed:\n" + msg[-5000:])

    # SSHX official installer supports a download mode which does not require
    # /usr/local/bin. The official project documents this mode and Linux
    # binaries are statically linked. We place it directly in the shared base.
    sshx = BASE / "usr/local/bin/sshx"
    sshx.parent.mkdir(parents=True, exist_ok=True)
    if not sshx.exists() or not os.access(sshx, os.X_OK):
        cmd = "set -eu; cd /usr/local/bin; rm -f sshx; curl -fsSL https://sshx.io/get | sh -s download; test -x ./sshx"
        cp = run(pcmd(BASE, cmd), timeout=180, capture=True)
        if cp.returncode != 0:
            raise RuntimeError("SSHX installation failed:\n" + ((cp.stdout or "") + "\n" + (cp.stderr or ""))[-5000:])
    try:
        sshx.chmod(0o755)
    except Exception:
        pass
    check = run(pcmd(BASE, "/usr/local/bin/sshx --version"), timeout=30, capture=True)
    if check.returncode != 0:
        raise RuntimeError("Workspace SSHX verification failed: " + ((check.stdout or "") + (check.stderr or ""))[-1000:])

    # Hide diagnostic tools in the workspace. We do not remove iproute2 from
    # the host; only the guest copy is affected.
    harden = r'''set +e
for f in /usr/bin/ss /usr/sbin/ss /usr/bin/netstat /usr/bin/lsof /usr/bin/nmap /usr/sbin/tcpdump /usr/sbin/iptables /usr/sbin/ip6tables /usr/bin/ip /usr/sbin/ip; do rm -f "$f"; done
for n in ss netstat lsof nmap tcpdump iptables ip6tables ip; do printf '#!/bin/sh\necho "command unavailable in DARKSSH workspace" >&2\nexit 127\n' > "/usr/local/bin/$n"; chmod 755 "/usr/local/bin/$n"; done
'''
    run(pcmd(BASE, harden), timeout=120, check=False)
    CAPS = capabilities()


def clone(dst):
    tmp = dst.with_name(dst.name + ".new")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    a = subprocess.Popen(["tar", "-C", str(BASE), "-cf", "-", "."], stdout=subprocess.PIPE)
    b = subprocess.Popen(["tar", "-C", str(tmp), "-xf", "-"], stdin=a.stdout)
    a.stdout.close()
    brc = b.wait()
    arc = a.wait()
    if brc != 0 or arc != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Workspace clone failed")
    os.replace(tmp, dst)
    (dst / "etc/hosts").write_text("127.0.0.1 localhost\n::1 localhost\n")
    (dst / "etc/hostname").write_text("darkssh-" + dst.parent.name[:12] + "\n")


def set_progress(sid, percent, stage, message=""):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r.update(progress=max(0, min(100, int(percent))), stage=stage, message=message, last_activity=time.time())
            save()


def create_request(name):
    with LOCK:
        active = sum(r.get("status") in ("queued", "starting", "running") for r in STATE["sessions"].values())
        if active >= int(CFGDATA.get("max_sessions", 25)):
            raise RuntimeError("Maximum sessions reached")
        sid = secrets.token_hex(8)
        owner = secrets.token_urlsafe(32)
        rec = {
            "id": sid,
            "name": (name or "workspace-" + sid[:6])[:80],
            "status": "queued",
            "progress": 1,
            "stage": "queued",
            "message": "Queued for workspace worker",
            "sshx_url": None,
            "created_at": time.time(),
            "last_activity": time.time(),
            "ended_at": None,
            "error": None,
            "owner_token": owner,
        }
        STATE["sessions"][sid] = rec
        READY_EVENTS[sid] = threading.Event()
        save()
    CREATE_POOL.submit(build_session, sid)
    return rec.copy()


def namespace_command(root, command):
    """Return (Popen args, slirp-needed).

    namespace+slirp mode gives the guest a private network namespace. If the
    host blocks user/network namespaces, we deliberately fall back to PRoot
    without binding the host /proc or /sys.
    """
    base = pcmd(root, command)
    if CAPS and CAPS.get("private_network"):
        return ["unshare", "-Urnpf", "--mount-proc=/proc", "--kill-child=SIGKILL", "--"] + base, True
    return base, False


def start_slirp(pid):
    if not (CAPS and CAPS.get("private_network") and have("slirp4netns")):
        return None
    try:
        p = subprocess.Popen(["slirp4netns", "--configure", "--mtu=65520", str(pid), "tap0"], stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT, start_new_session=True)
        time.sleep(0.5)
        if p.poll() is not None:
            return None
        return p
    except Exception as e:
        log("slirp4netns failed; continuing with host-network fallback: " + str(e))
        return None


def build_session(sid):
    try:
        set_progress(sid, 5, "checking", "Detecting host OS, architecture and isolation capabilities")
        if not ensure_proot():
            raise RuntimeError("PRoot is unavailable and could not be installed automatically")
        ensure_base()
        set_progress(sid, 20, "base-ready", "Ubuntu base verified and SSHX installed automatically")
        with LOCK:
            if sid not in STATE["sessions"]:
                return
            STATE["sessions"][sid].update(status="starting", stage="workspace")
            save()
        root = SESSIONS / sid / "rootfs"
        root.parent.mkdir(parents=True, exist_ok=True)
        set_progress(sid, 30, "copying", "Creating a private workspace filesystem")
        clone(root)
        set_progress(sid, 55, "isolating", "Selecting the strongest isolation supported by this host")
        cmd = """set -eu
export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
cd /root
exec /usr/local/bin/sshx run
"""
        args, needs_slirp = namespace_command(root, cmd)
        set_progress(sid, 65, "starting", "Launching SSHX")
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, start_new_session=True)
        with LOCK:
            PROCS[sid] = p
            STATE["sessions"][sid]["pid"] = p.pid
            STATE["sessions"][sid]["isolation"] = "private-network" if needs_slirp else "proot-filesystem"
            save()
        if needs_slirp:
            sp = start_slirp(p.pid)
            if sp:
                NETPROCS[sid] = sp
                set_progress(sid, 70, "network", "Private network namespace configured")
            else:
                set_progress(sid, 70, "network-fallback", "Host blocks private networking; using filesystem-isolated fallback")
        else:
            set_progress(sid, 70, "network-fallback", "Private network namespace unavailable on this host; using filesystem-isolated fallback")
        set_progress(sid, 75, "sshx", "SSHX is running; waiting for its access URL")
        threading.Thread(target=watch, args=(sid, p), daemon=True).start()
    except Exception as e:
        log(sid + ": FAILED: " + str(e))
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                r.update(status="error", progress=100, stage="error", message="Creation failed", error=str(e), ended_at=time.time())
                save()
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
        PROCS.pop(sid, None)


def watch(sid, p):
    rc = 1
    try:
        for line in p.stdout:
            line = line.strip()
            if line:
                log(sid + ": " + line)
            m = URLRE.search(line)
            if m:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    if r:
                        url = m.group(0).rstrip(".,);]")
                        r.update(status="running", progress=100, stage="ready", message="SSHX session is ready", sshx_url=url, last_activity=time.time())
                        save()
                ev = READY_EVENTS.get(sid)
                if ev:
                    ev.set()
        rc = p.wait()
    except Exception as e:
        log(sid + ": watcher: " + str(e))
    finally:
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and r.get("status") != "deleted":
                r["status"] = "stopped" if rc == 0 else "error"
                r["ended_at"] = time.time()
                if rc and not r.get("error"):
                    r["error"] = f"SSHX exited with code {rc}"
                save()
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
            PROCS.pop(sid, None)
        sp = NETPROCS.pop(sid, None)
        if sp and sp.poll() is None:
            try:
                sp.terminate()
            except Exception:
                pass


def delete(sid):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if not r:
            return False
        p = PROCS.get(sid)
        if p and p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGTERM)
            except Exception:
                pass
            try:
                p.wait(5)
            except Exception:
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except Exception:
                    pass
        sp = NETPROCS.pop(sid, None)
        if sp and sp.poll() is None:
            try:
                sp.terminate()
            except Exception:
                pass
        shutil.rmtree(SESSIONS / sid, ignore_errors=True)
        r["status"] = "deleted"
        r["ended_at"] = time.time()
        save()
        ev = READY_EVENTS.get(sid)
        if ev:
            ev.set()
        PROCS.pop(sid, None)
        return True


def public(r, secret=False):
    fields = ("id", "name", "status", "progress", "stage", "message", "sshx_url", "created_at", "last_activity", "ended_at", "error", "isolation")
    out = {k: r.get(k) for k in fields}
    if secret:
        out["owner_token"] = r.get("owner_token")
    return out


def authorized(headers, sid=None, allow_api=True):
    auth = headers.get("Authorization", "")
    if allow_api and CFGDATA.get("api_key") and auth.startswith("Bearer "):
        try:
            if secrets.compare_digest(auth[7:], CFGDATA["api_key"]):
                return "api"
        except Exception:
            pass
    if sid:
        token = headers.get("X-Session-Token", "")
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and token and secrets.compare_digest(token, r.get("owner_token", "")):
                return "owner"
    return None


def janitor():
    while True:
        time.sleep(15)
        now = time.time()
        limit = max(60, int(CFGDATA.get("idle_minutes", 60)) * 60)
        with LOCK:
            ids = [sid for sid, r in STATE["sessions"].items() if r.get("status") in ("queued", "starting", "running") and now - r.get("last_activity", now) >= limit]
        for sid in ids:
            log("Idle timeout: " + sid)
            delete(sid)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def sendj(self, code, obj):
        b = json.dumps(obj, separators=(",", ":")).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n > 65536:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Session-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"):
            b = (APP / "static/index.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)
            return
        if p == "/api/health":
            global CAPS
            if CAPS is None:
                CAPS = capabilities()
            return self.sendj(200, {"ok": True, "service": "DARKSSH", "ubuntu": "24.04.5", "host": detect_host(), "capabilities": CAPS, "auth": "enabled" if CFGDATA.get("api_key") else "disabled"})
        if p == "/api/sessions":
            mode = authorized(self.headers)
            if mode != "api":
                return self.sendj(401, {"error": "API key required"})
            with LOCK:
                return self.sendj(200, {"sessions": [public(r) for r in STATE["sessions"].values()]})
        if p.startswith("/api/sessions/"):
            sid = p.rsplit("/", 1)[-1]
            mode = authorized(self.headers, sid)
            if not mode:
                return self.sendj(401, {"error": "API key or session token required"})
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.sendj(404, {"error": "session not found"})
                return self.sendj(200, {"session": public(r)})
        self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        p = parsed.path
        if p == "/api/sessions":
            if authorized(self.headers) != "api":
                return self.sendj(401, {"error": "API key required"})
            try:
                d = self.body()
            except Exception as e:
                return self.sendj(400, {"error": str(e)})
            try:
                rec = create_request(str(d.get("name", "")))
                qs = parse_qs(parsed.query)
                async_mode = qs.get("wait", ["true"])[0].lower() == "false" or qs.get("async", ["0"])[0] == "1"
                if async_mode:
                    return self.sendj(202, {"ok": True, "ready": False, "session": public(rec, secret=True)})
                ev = READY_EVENTS[rec["id"]]
                if not ev.wait(300):
                    with LOCK:
                        current = STATE["sessions"].get(rec["id"], rec)
                    return self.sendj(504, {"ok": False, "ready": False, "error": "Timed out waiting for SSHX URL", "session": public(current, secret=True)})
                with LOCK:
                    final = STATE["sessions"].get(rec["id"])
                if not final:
                    return self.sendj(404, {"ok": False, "error": "session disappeared"})
                if final.get("sshx_url"):
                    return self.sendj(200, {"ok": True, "ready": True, "session": public(final, secret=True)})
                return self.sendj(502, {"ok": False, "ready": False, "error": final.get("error") or "SSHX exited before producing a URL", "session": public(final, secret=True)})
            except Exception as e:
                log("create: " + str(e))
                return self.sendj(500, {"error": str(e)})
        if p.startswith("/api/sessions/") and p.endswith("/heartbeat"):
            sid = p.split("/")[-2]
            if not authorized(self.headers, sid):
                return self.sendj(401, {"error": "API key or session token required"})
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.sendj(404, {"error": "session not found"})
                r["last_activity"] = time.time()
                save()
            return self.sendj(200, {"ok": True})
        self.send_error(404)

    def do_DELETE(self):
        p = urlparse(self.path).path
        if p.startswith("/api/sessions/"):
            sid = p.rsplit("/", 1)[-1]
            if not authorized(self.headers, sid):
                return self.sendj(401, {"error": "API key or session token required"})
            ok = delete(sid)
            return self.sendj(200 if ok else 404, {"ok": ok})
        self.send_error(404)


def main():
    global CAPS
    CAPS = capabilities()
    if not CFGDATA.get("api_key"):
        CFGDATA["api_key"] = secrets.token_urlsafe(32)
        CFG.write_text(json.dumps(CFGDATA, indent=2))
    log("Host: " + json.dumps(detect_host(), separators=(",", ":")))
    log("Capabilities: " + json.dumps(CAPS, separators=(",", ":")))
    log("API key authentication ENABLED")
    log(f"Listening on {CFGDATA['host']}:{int(CFGDATA['port'])}")
    threading.Thread(target=janitor, daemon=True).start()
    ThreadingHTTPServer((CFGDATA["host"], int(CFGDATA["port"])), Handler).serve_forever()


if __name__ == "__main__":
    main()
